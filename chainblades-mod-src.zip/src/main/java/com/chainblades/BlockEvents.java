package com.chainblades;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Sparks and an X flash when a frontal hit is blocked with the crossed blades (damage itself is blocked by vanilla shield logic). */
@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID)
public class BlockEvents {
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (!sp.isBlocking() || !(sp.getUseItem().getItem() instanceof ChainBladesItem)) return;
        Vec3 src = e.getSource().getSourcePosition();
        if (src == null) return;
        Vec3 view = sp.getViewVector(1.0F);
        Vec3 to = src.vectorTo(sp.position());
        to = new Vec3(to.x, 0, to.z).normalize();
        if (to.dot(view) >= 0) return;
        ServerLevel l = sp.serverLevel();
        Vec3 c = sp.getEyePosition().add(view.scale(0.8)).add(0, -0.4, 0);
        Vec3 right = Util.right(view);
        Vec3 up = new Vec3(0, 1, 0);
        FX.sound(l, c, SoundEvents.CHAIN_HIT, 1.2F, 0.6F);
        FX.sound(l, c, SoundEvents.AMETHYST_CLUSTER_BREAK, 1F, 0.6F);
        FX.sound(l, c, SoundEvents.ANVIL_LAND, 0.4F, 1.8F);
        FX.p(l, ParticleTypes.CRIT, c, 8, 0.3, 0.4);
        FX.p(l, ParticleTypes.END_ROD, c, 5, 0.3, 0.15);
        FX.ribbon(l, FX.straight(c.add(right.scale(-0.9)).add(up.scale(-0.7)), c.add(right.scale(0.9)).add(up.scale(0.7)), 6), 0.14F, 6, 2, 1, 0);
        FX.ribbon(l, FX.straight(c.add(right.scale(-0.9)).add(up.scale(0.7)), c.add(right.scale(0.9)).add(up.scale(-0.7)), 6), 0.14F, 6, 2, 1, 0);
    }
}
