package com.chainblades;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class Util {
    public static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || e instanceof ArmorStand || e.isSpectator()) return false;
        if (e instanceof Player other && !p.canHarmPlayer(other)) return false;
        return !e.isAlliedTo(p);
    }

    public static Vec3 center(LivingEntity e) {
        return e.position().add(0, e.getBbHeight() * 0.5, 0);
    }

    public static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : f.normalize();
    }

    public static Vec3 right(Vec3 look) {
        Vec3 r = look.cross(new Vec3(0, 1, 0));
        return r.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : r.normalize();
    }

    /** Entities within radius of the player. */
    public static List<LivingEntity> around(ServerPlayer p, double r) {
        return p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                e -> valid(p, e) && e.distanceTo(p) <= r + e.getBbWidth() * 0.5);
    }

    /** Entities within a point radius. */
    public static List<LivingEntity> aoe(ServerPlayer p, Vec3 pt, double r) {
        return p.level().getEntitiesOfClass(LivingEntity.class, new AABB(pt, pt).inflate(r),
                e -> valid(p, e) && center(e).distanceTo(pt) <= r + e.getBbWidth() * 0.5);
    }

    /** Entities in a cone in front of the player. */
    public static List<LivingEntity> cone(ServerPlayer p, double range, double minDot) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        return p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(range), e -> {
            if (!valid(p, e)) return false;
            Vec3 to = center(e).subtract(eye);
            double d = to.length();
            if (d > range + e.getBbWidth() * 0.5) return false;
            if (d < 0.01) return true;
            return to.scale(1.0 / d).dot(look) >= minDot;
        });
    }

    public static LivingEntity findTarget(ServerPlayer p, double range) {
        Vec3 look = p.getLookAngle();
        Vec3 eye = p.getEyePosition();
        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (LivingEntity e : around(p, range)) {
            Vec3 to = center(e).subtract(eye);
            double d = to.length();
            double dot = d < 0.01 ? 1 : to.scale(1.0 / d).dot(look);
            double score = d + (dot > 0.3 ? 0 : 100);
            if (score < bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    public static void hit(ServerPlayer p, LivingEntity e, float dmg, float knock) {
        e.invulnerableTime = 0;
        e.hurt(p.damageSources().playerAttack(p), dmg);
        if (knock > 0) e.knockback(knock, p.getX() - e.getX(), p.getZ() - e.getZ());
        if (p.level() instanceof ServerLevel l) {
            Vec3 c = center(e);
            l.sendParticles(ParticleTypes.CRIT, c.x, c.y, c.z, 8, 0.3, 0.4, 0.3, 0.3);
            l.sendParticles(FX.PURPLE, c.x, c.y, c.z, 10, 0.4, 0.5, 0.4, 0);
        }
    }

    public static double distToSegment(Vec3 pt, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        if (len2 < 1.0E-6) return pt.distanceTo(a);
        double t = Math.max(0, Math.min(1, pt.subtract(a).dot(ab) / len2));
        return pt.distanceTo(a.add(ab.scale(t)));
    }

    public static void lunge(ServerPlayer p, double power) {
        Vec3 f = flat(p.getLookAngle());
        p.setDeltaMovement(p.getDeltaMovement().add(f.x * power, 0.05, f.z * power));
        p.hurtMarked = true;
    }
}
