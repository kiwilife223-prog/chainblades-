package com.chainblades;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public class FX {
    public static final DustParticleOptions PURPLE = new DustParticleOptions(new Vector3f(0.55F, 0.12F, 0.95F), 1.3F);
    public static final DustParticleOptions VIOLET = new DustParticleOptions(new Vector3f(0.22F, 0.03F, 0.38F), 1.6F);
    public static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.03F, 0.0F, 0.06F), 1.8F);

    public static void p(ServerLevel l, ParticleOptions o, Vec3 v, int n, double spread, double speed) {
        l.sendParticles(o, v.x, v.y, v.z, Math.max(1, n), spread, spread, spread, speed);
    }

    public static void sound(ServerLevel l, Vec3 pos, SoundEvent s, float vol, float pitch) {
        l.playSound(null, pos.x, pos.y, pos.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    public static void line(ServerLevel l, Vec3 a, Vec3 b, double step, ParticleOptions... opts) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 dir = d.scale(1.0 / len);
        int n = (int) (len / step);
        for (int i = 0; i <= n; i++) {
            Vec3 pt = a.add(dir.scale(i * step));
            p(l, opts[i % opts.length], pt, 1, 0, 0);
        }
    }

    /** A chain: dark/violet links from the hand to the blade, with a blade burst on the end. */
    public static void chain(ServerLevel l, Vec3 hand, Vec3 end) {
        line(l, hand, end, 0.3, BLACK, PURPLE, VIOLET);
        blade(l, end);
    }

    public static void blade(ServerLevel l, Vec3 e) {
        p(l, ParticleTypes.SWEEP_ATTACK, e, 1, 0, 0);
        p(l, ParticleTypes.CRIT, e, 6, 0.25, 0.3);
        p(l, ParticleTypes.SOUL_FIRE_FLAME, e, 3, 0.15, 0.02);
        p(l, PURPLE, e, 6, 0.3, 0);
    }

    /** Dense black streak with violet edge (used for speed trails). */
    public static void streak(ServerLevel l, Vec3 a, Vec3 b) {
        line(l, a, b, 0.15, BLACK, BLACK, PURPLE, ParticleTypes.CRIT);
        line(l, a.add(0, 0.4, 0), b.add(0, 0.4, 0), 0.3, VIOLET);
        line(l, a.add(0, -0.4, 0), b.add(0, -0.4, 0), 0.3, VIOLET);
    }

    /** Horizontal sweep arc around the player (angles in degrees relative to look direction). */
    public static void arc(ServerLevel l, Vec3 center, Vec3 look, double radius, double from, double to, double tilt) {
        Vec3 flat = Util.flat(look);
        int n = Math.max(2, (int) (Math.abs(to - from) / 5));
        for (int i = 0; i <= n; i++) {
            double a = from + (to - from) * i / n;
            Vec3 d = flat.yRot((float) Math.toRadians(a));
            Vec3 pt = center.add(d.scale(radius)).add(0, tilt * (a / 90.0), 0);
            p(l, (i % 2 == 0) ? BLACK : PURPLE, pt, 1, 0, 0);
            if (i % 3 == 0) p(l, ParticleTypes.CRIT, pt, 1, 0.05, 0.1);
            if (i % 4 == 0) p(l, ParticleTypes.END_ROD, pt, 1, 0.02, 0.01);
        }
    }

    public static void ring(ServerLevel l, Vec3 c, double r, int pts, ParticleOptions o) {
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts;
            p(l, o, c.add(Math.cos(a) * r, 0, Math.sin(a) * r), 1, 0, 0);
        }
    }

    /** Large vertical-ish crescent wave facing 'dir'. */
    public static void crescent(ServerLevel l, Vec3 c, Vec3 dir, double radius, double tilt) {
        Vec3 right = Util.right(dir);
        for (int layer = 0; layer < 3; layer++) {
            double rr = radius - layer * 0.5;
            ParticleOptions o = layer == 0 ? ParticleTypes.END_ROD : (layer == 1 ? PURPLE : BLACK);
            for (int a = -85; a <= 85; a += 7) {
                double rad = Math.toRadians(a);
                double lat = Math.sin(rad) * rr;
                double back = -(rr - Math.cos(rad) * rr) * 1.1 - layer * 0.3;
                Vec3 pt = c.add(right.scale(lat)).add(dir.scale(back)).add(0, lat * tilt, 0);
                p(l, o, pt, 1, 0, 0);
            }
        }
    }
}
