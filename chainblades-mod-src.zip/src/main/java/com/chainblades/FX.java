package com.chainblades;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

public class FX {
    public static final DustParticleOptions PURPLE = new DustParticleOptions(new Vector3f(0.55F, 0.12F, 0.95F), 0.9F);
    public static final DustParticleOptions VIOLET = new DustParticleOptions(new Vector3f(0.22F, 0.03F, 0.38F), 0.9F);
    public static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.03F, 0.0F, 0.06F), 0.9F);

    public static void p(ServerLevel l, ParticleOptions o, Vec3 v, int n, double spread, double speed) {
        l.sendParticles(o, v.x, v.y, v.z, Math.max(1, n), spread, spread, spread, speed);
    }

    public static void sound(ServerLevel l, Vec3 pos, SoundEvent s, float vol, float pitch) {
        l.playSound(null, pos.x, pos.y, pos.z, s, SoundSource.PLAYERS, vol, pitch);
    }

    public static void line(ServerLevel l, Vec3 a, Vec3 b, double step, ParticleOptions... opts) {
        Vec3 d = b.subtract(a);
        double len = d.length();
        if (len < 0.01) return;
        Vec3 dir = d.scale(1.0 / len);
        int n = (int) (len / step);
        for (int i = 0; i <= n; i++) {
            Vec3 pt = a.add(dir.scale(i * step));
            p(l, opts[i % opts.length], pt, 1, 0, 0);
        }
    }

    /** A chain: dark/violet links from the hand to the blade, with a blade burst on the end. */
    public static void chain(ServerLevel l, Vec3 hand, Vec3 end) {
        // the chain itself is rendered on the client; here only the impact burst
        blade(l, end);
    }

    public static void blade(ServerLevel l, Vec3 e) {
        p(l, ParticleTypes.SWEEP_ATTACK, e, 1, 0, 0);
        p(l, ParticleTypes.CRIT, e, 4, 0.2, 0.3);
        p(l, ParticleTypes.END_ROD, e, 3, 0.15, 0.08);
        p(l, ParticleTypes.REVERSE_PORTAL, e, 4, 0.2, 0.15);
    }

    /** Dense black streak with violet edge (used for speed trails). */
    public static void streak(ServerLevel l, Vec3 a, Vec3 b) {
        ribbon(l, straight(a, b, 6), 0.3F, 10, 0, 1, 0);
        ribbon(l, straight(a.add(0, 0.3, 0), b.add(0, 0.3, 0), 6), 0.12F, 8, 0, 0, 0);
        line(l, a, b, 0.7, ParticleTypes.END_ROD, ParticleTypes.CRIT);
    }

    /** Horizontal sweep arc around the player (angles in degrees relative to look direction). */
    public static void arc(ServerLevel l, Vec3 center, Vec3 look, double radius, double from, double to, double tilt) {
        ribbon(l, arcPts(center, look, radius, from, to, tilt), 0.2F, 7, 2, 1, 0);
    }

    public static void ring(ServerLevel l, Vec3 c, double r, int pts, ParticleOptions o) {
        List<Vec3> out = new ArrayList<>();
        int n = Math.max(12, Math.min(40, pts));
        for (int i = 0; i <= n; i++) {
            double a = Math.PI * 2 * i / n;
            out.add(c.add(Math.cos(a) * r, 0.1, Math.sin(a) * r));
        }
        ribbon(l, out, 0.25F, 9, 4, o == BLACK ? 0 : 1, 0);
    }

    /** Large vertical-ish crescent wave facing 'dir'. */
    public static void crescent(ServerLevel l, Vec3 c, Vec3 dir, double radius, double tilt) {
        ribbon(l, crescentPts(c, dir, radius, tilt), 0.55F, 9, 0, 1, 0);
        ribbon(l, crescentPts(c, dir, radius * 0.8, tilt), 0.3F, 9, 0, 0, 0);
    }

    // ---------- client-rendered effects ----------
    public static void send(ServerLevel l, Vec3 pos, Object msg) {
        Network.CH.send(PacketDistributor.NEAR.with(() ->
                new PacketDistributor.TargetPoint(pos.x, pos.y, pos.z, 96, l.dimension())), msg);
    }

    public static void ribbon(ServerLevel l, List<Vec3> pts, float width, int life, int grow, int style, int delay) {
        if (pts.size() < 2) return;
        send(l, pts.get(0), new Network.RibbonPacket(style, life, grow, delay, width, pts.toArray(new Vec3[0])));
    }

    public static List<Vec3> arcPts(Vec3 center, Vec3 look, double radius, double from, double to, double tilt) {
        Vec3 flat = Util.flat(look);
        List<Vec3> out = new ArrayList<>();
        int n = 10;
        for (int i = 0; i <= n; i++) {
            double a = from + (to - from) * i / n;
            Vec3 d = flat.yRot((float) Math.toRadians(a));
            out.add(center.add(d.scale(radius)).add(0, tilt * (a / 90.0), 0));
        }
        return out;
    }

    public static List<Vec3> crescentPts(Vec3 c, Vec3 dir, double radius, double tilt) {
        Vec3 right = Util.right(dir);
        List<Vec3> out = new ArrayList<>();
        for (int a = -85; a <= 85; a += 10) {
            double rad = Math.toRadians(a);
            double lat = Math.sin(rad) * radius;
            double back = -(radius - Math.cos(rad) * radius) * 1.1;
            out.add(c.add(right.scale(lat)).add(dir.scale(back)).add(0, lat * tilt, 0));
        }
        return out;
    }

    public static List<Vec3> straight(Vec3 a, Vec3 b, int n) {
        List<Vec3> out = new ArrayList<>();
        for (int i = 0; i <= n; i++) out.add(a.lerp(b, (double) i / n));
        return out;
    }

    /** A chain flying along a bezier curve and holding there, then retracting. */
    public static void whip(ServerLevel l, ServerPlayer o, boolean right, Vec3 p0, Vec3 ctrl, Vec3 p1,
                            int delay, int life, int hold, int retract) {
        send(l, o.position(), new Network.WhipPacket(0, o.getId(), right, p0, ctrl, p1, 0, 0, 0, 0, delay, life, hold, retract));
    }

    /** A chain whirling around the owner. Angles in radians. */
    public static void orbit(ServerLevel l, ServerPlayer o, boolean right, double radius, double a0, double a1,
                             double height, int delay, int life, int retract) {
        Vec3 z = Vec3.ZERO;
        send(l, o.position(), new Network.WhipPacket(1, o.getId(), right, z, z, z, radius, a0, a1, height, delay, life, 0, retract));
    }
}
