package com.chainblades;

/**
 * Keyframe animations (angles in radians, time in ticks), authored with a tiny text DSL:
 *   "RAX 0:-.9 3:-2.3 5:-1.35o 12:-.9"   (time:value[ease])
 * ease suffix applies to the segment that ENDS at that key: o = fast-out, i = accelerate, l = linear, b = overshoot, none = smooth.
 * Arm convention: x negative = raised forward, y positive = swing to the player's right, z positive (right arm) = outward.
 * RGR/LGR: 1 = dagger held by its handle, 0 = hand holds the chain end and the dagger flies on the chain. WR = wrist angle of the held dagger. HY/HX = head yaw/pitch.
 * Chain channels: LEN = chain length in blocks, TEN = tension (0 = loose and hanging, 1 = taut/straight).
 */
public class Anim {
    public static final int N = 27;
    public static final int RAX = 0, RAY = 1, RAZ = 2, LAX = 3, LAY = 4, LAZ = 5, BY = 6, BX = 7, LEAN = 8, MV = 9, SPIN = 10,
            RLX = 11, LLX = 12, RLY = 13, LLY = 14, RLEN = 15, RTEN = 16, LLEN = 17, LTEN = 18, JUMP = 19, CSP = 20, CAM = 21,
            RGR = 22, LGR = 23, WR = 24, HY = 25, HX = 26;
    private static final String[] NAMES = {"RAX", "RAY", "RAZ", "LAX", "LAY", "LAZ", "BY", "BX", "LEAN", "MV", "SPIN",
            "RLX", "LLX", "RLY", "LLY", "RLEN", "RTEN", "LLEN", "LTEN", "JUMP", "CSP", "CAM", "RGR", "LGR", "WR", "HY", "HX"};
    private static final int[] PARTNER = {3, 4, 5, 0, 1, 2, 6, 7, 8, 9, 10, 12, 11, 14, 13, 17, 18, 15, 16, 19, 20, 21, 23, 22, 24, 25, 26};
    private static final float[] SIGN = {1, -1, -1, 1, -1, -1, -1, 1, 1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, -1, 1};

    /** Relaxed stance: arms slightly apart, daggers gripped by the handles (RGR/LGR = 1), chains hanging from the pommel rings. */
    public static final float[] IDLE = {-0.3F, -0.12F, 0.2F, -0.3F, 0.12F, -0.2F, 0F, 0F, 0F, 0F, 0F,
            -0.1F, 0.1F, 0F, 0F, 0.5F, 0.3F, 0.5F, 0.3F, 0F, 0F, 0F,
            1F, 1F, 1.1F, 0F, 0F};

    public final int length;
    private final float[][] times = new float[N][];
    private final float[][] vals = new float[N][];
    private final byte[][] ease = new byte[N][];

    private Anim(int length) { this.length = length; }

    private static int index(String name) {
        for (int i = 0; i < N; i++) if (NAMES[i].equals(name)) return i;
        throw new IllegalArgumentException("Unknown channel " + name);
    }

    private static Anim make(int length, String... lines) {
        Anim a = new Anim(length);
        for (String line : lines) {
            String[] tk = line.trim().split("\\s+");
            int ch = index(tk[0]);
            int n = tk.length - 1;
            a.times[ch] = new float[n];
            a.vals[ch] = new float[n];
            a.ease[ch] = new byte[n];
            for (int i = 0; i < n; i++) {
                String s = tk[i + 1];
                int c = s.indexOf(':');
                a.times[ch][i] = Float.parseFloat(s.substring(0, c));
                String vs = s.substring(c + 1);
                char last = vs.charAt(vs.length() - 1);
                byte e = 0;
                if (Character.isLetter(last)) {
                    e = (byte) (last == 'o' ? 1 : last == 'i' ? 2 : last == 'l' ? 3 : last == 'b' ? 4 : 0);
                    vs = vs.substring(0, vs.length() - 1);
                }
                a.vals[ch][i] = Float.parseFloat(vs);
                a.ease[ch][i] = e;
            }
        }
        return a;
    }

    private static float ease(int type, float s) {
        switch (type) {
            case 1: { float u = 1 - s; return 1 - u * u * u; }
            case 2: return s * s * s;
            case 3: return s;
            case 4: { float u = s - 1; return 1 + 2.2F * u * u * u + 1.2F * u * u; }
            default: return s * s * (3 - 2 * s);
        }
    }

    public void sample(float time, float[] out) {
        for (int ch = 0; ch < N; ch++) {
            float[] ts = times[ch];
            if (ts == null) { out[ch] = IDLE[ch]; continue; }
            float[] vs = vals[ch];
            int n = ts.length;
            if (time <= ts[0]) { out[ch] = vs[0]; continue; }
            if (time >= ts[n - 1]) { out[ch] = vs[n - 1]; continue; }
            int i = 0;
            while (i < n - 2 && time > ts[i + 1]) i++;
            float s = (time - ts[i]) / (ts[i + 1] - ts[i]);
            s = ease(ease[ch][i + 1], s);
            out[ch] = vs[i] + (vs[i + 1] - vs[i]) * s;
        }
    }

    public Anim mirrored() {
        Anim m = new Anim(length);
        for (int dst = 0; dst < N; dst++) {
            int src = PARTNER[dst];
            if (times[src] == null) continue;
            m.times[dst] = times[src].clone();
            m.ease[dst] = ease[src].clone();
            m.vals[dst] = new float[vals[src].length];
            for (int i = 0; i < vals[src].length; i++) m.vals[dst][i] = vals[src][i] * SIGN[dst];
        }
        return m;
    }

    /** 0-4 combo, 5 tornado, 6 front-flip slam, 7 Z, 8 X, 9 C, 10 idle chain-spin, 12 backflip. (11 = block, handled in ClientAnim) */
    public static final Anim[] ALL = new Anim[13];

    static {
        // ---- 1. diagonal slash, dagger gripped by the handle. Anticipation -> snap -> overshoot -> settle; torso leads, arms follow, head tracks.
        Anim slashR = make(14,
                "RAX 0:-.3 4:-2.3 6:-1.2b 9:-1.1 14:-.3",
                "RAY 0:-.12 4:1.0 6:-1.15b 9:-1.2 14:-.12",
                "RAZ 0:.2 4:.55 6:-.3o 14:.2",
                "LAX 0:-.3 5:-1.6 7:-1.1b 10:-1.0 14:-.3",
                "LAY 0:.12 5:.7 7:-.7 10:-.75 14:.12",
                "LAZ 0:-.2 5:-.35 7:-.1 14:-.2",
                "BY 0:0 4:.65 6:-.8b 9:-.7 14:0",
                "LEAN 0:0 4:-.08 6:.2o 9:.12 14:0",
                "MV 0:0 4:0 6:.35o 14:0",
                "HY 0:0 4:.2 6:-.35o 10:-.2 14:0",
                "RLX 0:0 4:.25 6:-.75o 10:-.5 14:0",
                "LLX 0:0 4:-.2 6:.55o 10:.4 14:0",
                "WR 0:1.1 4:1.2 6:.55o 10:.8 14:1.1");
        ALL[0] = slashR;
        ALL[1] = slashR.mirrored();

        // ---- 2. cross: two quick opposite cuts
        ALL[2] = make(18,
                "RAX 0:-.3 2:-2.0 4:-1.2b 6:-1.8 9:-1.2b 11:-1.1 18:-.3",
                "RAY 0:-.12 2:.9 4:-1.1b 6:-.8 9:1.0b 11:1.05 18:-.12",
                "RAZ 0:.2 2:.5 4:-.2 6:-.3 9:.3 18:.2",
                "LAX 0:-.3 3:-1.6 5:-1.2b 7:-1.7 10:-1.2b 12:-1.1 18:-.3",
                "LAY 0:.12 3:.7 5:-.8b 7:-.6 10:.9b 12:.95 18:.12",
                "LAZ 0:-.2 5:-.3 10:-.1 18:-.2",
                "BY 0:0 2:.6 4:-.75b 6:-.6 9:.85b 11:.8 18:0",
                "LEAN 0:0 4:.15 9:.22 18:0",
                "MV 0:0 4:.25o 9:.5o 18:0",
                "HY 0:0 2:.2 4:-.35 9:.4 18:0",
                "RLX 0:0 4:-.6o 9:.3 18:0", "LLX 0:0 4:.4o 9:-.5 18:0",
                "WR 0:1.1 2:1.2 4:.55o 6:1.0 9:.55o 12:1.1 18:1.1");

        // ---- 3. chain whip: pull the dagger back, let go of the handle, grab the chain, throw
        Anim lashR = make(16,
                "RAX 0:-.3 2:-1.0 4:-2.6 5:-1.55o 10:-1.55 16:-.3",
                "RAY 0:-.12 2:.4 4:1.0 5:-.2o 10:-.2 16:-.12",
                "RAZ 0:.2 4:.9 5:0o 16:.2",
                "LAX 0:-.3 4:-.6 6:-.5 11:-.6 16:-.3",
                "LAY 0:.12 4:.7 6:.45 11:.45 16:.12",
                "LAZ 0:-.2 4:-.3 6:-.2 16:-.2",
                "BY 0:0 2:.3 4:1.0 5:-.5b 10:-.4 16:0",
                "LEAN 0:0 4:-.14 5:.25o 10:.2 16:0",
                "MV 0:0 4:0 5:.55o 10:.55 16:0",
                "HY 0:0 4:.3 5:-.2 11:-.1 16:0",
                "RLX 0:0 4:.3 5:-.8o 12:-.4 16:0", "LLX 0:0 4:-.2 5:.6o 12:.3 16:0",
                "WR 0:1.1 4:1.3 5:.6 16:1.1",
                "RGR 0:1 3:1 5:0o 12:0 14:1 16:1",
                "RLEN 0:.5 4:1.0 5:8o 10:8 13:1.2 16:.5",
                "RTEN 0:0 4:0 5:1o 10:.7 13:0 16:0");
        ALL[3] = lashR;
        ALL[4] = lashR.mirrored();

        // ---- 5. tornado: jump, drop both daggers on their chains and spin
        ALL[5] = make(22,
                "RAX 0:-.3 3:-.9 15:-.9 21:-.3",
                "RAY 0:-.12 3:0 15:0 21:-.12",
                "RAZ 0:.2 3:1.0 15:1.0 21:.2",
                "LAX 0:-.3 3:-.9 15:-.9 21:-.3",
                "LAY 0:.12 3:0 15:0 21:.12",
                "LAZ 0:-.2 3:-1.0 15:-1.0 21:-.2",
                "SPIN 0:0 3:0 15:-12.566l 20:-12.566",
                "JUMP 0:0 3:0 7:.9o 13:.9 19:0i 21:0",
                "RLX 0:0 5:-.9 14:-.9 19:0", "LLX 0:0 5:-.9 14:-.9 19:0",
                "LEAN 0:0 3:.1 15:.1 21:0",
                "RGR 0:1 3:1 5:0o 16:0 20:1", "LGR 0:1 3:1 5:0o 16:0 20:1",
                "RLEN 0:.5 3:.5 5:6o 15:6 19:.4", "RTEN 0:0 4:0 5:1o 15:1 19:0",
                "LLEN 0:.5 3:.5 5:6o 15:6 19:.4", "LTEN 0:0 4:0 5:1o 15:1 19:0");

        // ---- 6. front flip + chain slam finisher
        ALL[6] = make(26,
                "RAX 0:-.3 5:-3.0 16:-3.0 18:-.7o 22:-.7 26:-.3",
                "RAY 0:-.12 5:-.15 18:-.2 26:-.12",
                "LAX 0:-.3 5:-3.0 16:-3.0 18:-.7o 22:-.7 26:-.3",
                "LAY 0:.12 5:.15 18:.2 26:.12",
                "JUMP 0:0 3:0 7:.8o 12:1.2 17:.3i 18:0 26:0",
                "LEAN 0:0 3:-.2 6:-.1 8:.2 17:6.283 26:6.283",
                "RLX 0:0 6:-1.2 16:-1.2 18:-.9o 22:-.9 26:0",
                "LLX 0:0 6:-1.2 16:-1.2 18:.5 22:.5 26:0",
                "RGR 0:1 15:1 18:0o 23:0 26:1", "LGR 0:1 15:1 18:0o 23:0 26:1",
                "RLEN 0:.5 14:.5 18:7o 23:7 26:.4", "RTEN 0:0 16:0 18:1o 23:.8 26:0",
                "LLEN 0:.5 14:.5 18:7o 23:7 26:.4", "LTEN 0:0 16:0 18:1o 23:.8 26:0");

        // ---- Z: rapid alternating strikes with both chains, torso twisting, legs stepping, head following
        ALL[7] = make(42,
                "RAX 0:-.3 3:-1.75o 5:-0.75o 7:-1.75o 9:-0.75o 11:-1.75o 13:-0.75o 15:-1.75o 17:-0.75o 19:-1.75o 21:-0.75o 23:-1.75o 25:-0.75o 27:-1.75o 29:-0.75o 31:-1.75o 33:-0.75o 35:-1.75o 37:-0.75o 42:-.3",
                "RAY 0:-.12 3:-0.45o 5:0.55o 7:-0.45o 9:0.55o 11:-0.45o 13:0.55o 15:-0.45o 17:0.55o 19:-0.45o 21:0.55o 23:-0.45o 25:0.55o 27:-0.45o 29:0.55o 31:-0.45o 33:0.55o 35:-0.45o 37:0.55o 42:-.12",
                "RAZ 0:.2 3:0.5 5:0.2 7:0.5 9:0.2 11:0.5 13:0.2 15:0.5 17:0.2 19:0.5 21:0.2 23:0.5 25:0.2 27:0.5 29:0.2 31:0.5 33:0.2 35:0.5 37:0.2 42:.2",
                "LAX 0:-.3 3:-0.75o 5:-1.75o 7:-0.75o 9:-1.75o 11:-0.75o 13:-1.75o 15:-0.75o 17:-1.75o 19:-0.75o 21:-1.75o 23:-0.75o 25:-1.75o 27:-0.75o 29:-1.75o 31:-0.75o 33:-1.75o 35:-0.75o 37:-1.75o 42:-.3",
                "LAY 0:.12 3:0.45o 5:-0.55o 7:0.45o 9:-0.55o 11:0.45o 13:-0.55o 15:0.45o 17:-0.55o 19:0.45o 21:-0.55o 23:0.45o 25:-0.55o 27:0.45o 29:-0.55o 31:0.45o 33:-0.55o 35:0.45o 37:-0.55o 42:.12",
                "LAZ 0:-.2 3:-0.2 5:-0.5 7:-0.2 9:-0.5 11:-0.2 13:-0.5 15:-0.2 17:-0.5 19:-0.2 21:-0.5 23:-0.2 25:-0.5 27:-0.2 29:-0.5 31:-0.2 33:-0.5 35:-0.2 37:-0.5 42:-.2",
                "BY 0:0 3:0.28 5:-0.28 7:0.28 9:-0.28 11:0.28 13:-0.28 15:0.28 17:-0.28 19:0.28 21:-0.28 23:0.28 25:-0.28 27:0.28 29:-0.28 31:0.28 33:-0.28 35:0.28 37:-0.28 42:0",
                "HY 0:0 3:-0.22 5:0.22 7:-0.22 9:0.22 11:-0.22 13:0.22 15:-0.22 17:0.22 19:-0.22 21:0.22 23:-0.22 25:0.22 27:-0.22 29:0.22 31:-0.22 33:0.22 35:-0.22 37:0.22 42:0",
                "RLX 0:0 3:-0.35 7:0.35 11:-0.35 15:0.35 19:-0.35 23:0.35 27:-0.35 31:0.35 35:-0.35 42:0",
                "LLX 0:0 3:0.35 7:-0.35 11:0.35 15:-0.35 19:0.35 23:-0.35 27:0.35 31:-0.35 35:0.35 42:0",
                "LEAN 0:0 3:.14 38:.14 42:0",
                "RGR 0:1 2:1 4:0o 39:0 42:1", "LGR 0:1 2:1 4:0o 39:0 42:1",
                "RLEN 0:.5 3:5o 38:6 42:.4", "RTEN 0:0 3:.85 38:.85 42:0",
                "LLEN 0:.5 3:5o 38:6 42:.4", "LTEN 0:0 3:.85 38:.85 42:0");

        // ---- X: shadow step, 6 cross cuts with the daggers in hand, return to the start point
        ALL[8] = make(24,
                "RAX 0:-.3 2:-1.4 17:-1.4 23:-.3",
                "RAY 0:-.12 2:.8o 5:-1.0o 8:.8o 11:-1.0o 14:.8o 17:-1.0o 23:-.12",
                "LAX 0:-.3 2:-1.4 17:-1.4 23:-.3",
                "LAY 0:.12 2:-.8o 5:1.0o 8:-.8o 11:1.0o 14:-.8o 17:1.0o 23:.12",
                "BY 0:0 2:-.6o 5:.7o 8:-.6o 11:.7o 14:-.6o 17:.7o 22:0",
                "HY 0:0 2:.3 5:-.3 8:.3 11:-.3 14:.3 17:-.3 22:0",
                "LEAN 0:0 2:.45 17:.45 22:0",
                "MV 0:0 2:.3 17:.3 20:0",
                "RLX 0:0 2:-.8 17:-.8 22:0", "LLX 0:0 2:.6 17:.6 22:0",
                "WR 0:1.1 2:.6 20:.6 24:1.1");

        // ---- C: draw across the body, then two quick crossing cuts (the X)
        ALL[9] = make(40,
                "RAX 0:-.3 10:-.8 12:-1.5o 13:-1.55 15:-1.1o 17:-1.1 28:-1.3 40:-.3",
                "RAY 0:-.12 10:1.0 12:-1.25o 13:-1.3 15:.9o 17:.95 28:.6 40:-.12",
                "RAZ 0:.2 10:.4 12:-.3o 15:.3o 28:0 40:.2",
                "LAX 0:-.3 10:-.9 12:-1.5o 13:-1.5 15:-1.1o 17:-1.1 28:-1.3 40:-.3",
                "LAY 0:.12 10:1.2 12:-.7o 13:-.75 15:1.0o 17:1.05 28:.6 40:.12",
                "BY 0:0 10:.9 12:-.85o 13:-.9 15:.8o 17:.85 28:.3 40:0",
                "HY 0:0 10:.3 12:-.3 15:.3 28:0 40:0",
                "LEAN 0:0 10:-.12 12:.3o 15:.3 28:.2 40:0",
                "MV 0:0 10:0 12:.6o 28:.6 36:0",
                "RLX 0:0 10:.5 12:-.8o 28:-.8 40:0", "LLX 0:0 10:-.4 12:.6o 28:.6 40:0",
                "WR 0:1.1 10:1.3 12:.5o 17:.5 24:.9 40:1.1");

        // ---- idle show: after standing still, lets go of the handles and whirls the daggers on the chains in vertical circles
        ALL[10] = make(90,
                "RAX 0:-0.45l 3:-0.379l 6:-0.35l 9:-0.379l 12:-0.45l 15:-0.521l 18:-0.55l 21:-0.521l 24:-0.45l 27:-0.379l 30:-0.35l 33:-0.379l 36:-0.45l 39:-0.521l 42:-0.55l 45:-0.521l 48:-0.45l 51:-0.379l 54:-0.35l 57:-0.379l 60:-0.45l 63:-0.521l 66:-0.55l 69:-0.521l 72:-0.45l 75:-0.379l 78:-0.35l 81:-0.379l 84:-0.45l 87:-0.521l 90:-.3",
                "LAX 0:-0.45l 3:-0.521l 6:-0.55l 9:-0.521l 12:-0.45l 15:-0.379l 18:-0.35l 21:-0.379l 24:-0.45l 27:-0.521l 30:-0.55l 33:-0.521l 36:-0.45l 39:-0.379l 42:-0.35l 45:-0.379l 48:-0.45l 51:-0.521l 54:-0.55l 57:-0.521l 60:-0.45l 63:-0.379l 66:-0.35l 69:-0.379l 72:-0.45l 75:-0.521l 78:-0.55l 81:-0.521l 84:-0.45l 87:-0.379l 90:-.3",
                "BY 0:0l 3:0.085l 6:0.12l 9:0.085l 12:0l 15:-0.085l 18:-0.12l 21:-0.085l 24:0l 27:0.085l 30:0.12l 33:0.085l 36:0l 39:-0.085l 42:-0.12l 45:-0.085l 48:0l 51:0.085l 54:0.12l 57:0.085l 60:0l 63:-0.085l 66:-0.12l 69:-0.085l 72:0l 75:0.085l 78:0.12l 81:0.085l 84:0l 87:-0.085l 90:0",
                "RAY 0:-.12 8:-.25 82:-.25 90:-.12", "LAY 0:.12 8:.25 82:.25 90:.12",
                "RAZ 0:.2 8:.3 82:.3 90:.2", "LAZ 0:-.2 8:-.3 82:-.3 90:-.2",
                "CSP 0:0 10:0 80:60l 90:60",
                "CAM 0:0 8:1 82:1 90:0",
                "RGR 0:1 4:1 8:0 82:0 88:1 90:1", "LGR 0:1 4:1 8:0 82:0 88:1 90:1",
                "RLEN 0:.5 8:2.6 82:2.6 90:.5", "RTEN 0:.3 8:.95 82:.95 90:.3",
                "LLEN 0:.5 8:2.6 82:2.6 90:.5", "LTEN 0:.3 8:.95 82:.95 90:.3");

        // ---- 12. backflip: daggers in hand through the flip, whip the chains on landing
        ALL[12] = make(24,
                "JUMP 0:0 3:0 8:1.3o 14:1.3 19:0i 24:0",
                "LEAN 0:0 3:-.25 6:-.25 17:-6.283 24:-6.283",
                "RAX 0:-.3 4:-2.6 15:-2.6 18:-1.55o 22:-.3",
                "RAY 0:-.12 4:.2 15:.2 18:-.1o 24:-.12",
                "LAX 0:-.3 4:-2.6 15:-2.6 18:-.6 22:-.3",
                "LAY 0:.12 4:-.2 15:-.2 18:.4 24:.12",
                "RLX 0:0 4:-1.1 15:-1.1 19:0", "LLX 0:0 4:-1.1 15:-1.1 19:0",
                "RGR 0:1 16:1 18:0o 21:0 24:1",
                "RLEN 0:.5 15:.5 18:7o 21:7 24:.4", "RTEN 0:0 16:0 18:1o 21:.7 24:0");
    }
}
