package com.chainblades;

/**
 * Keyframe animations (angles in radians, time in ticks), authored with a tiny text DSL:
 *   "RAX 0:-.9 3:-2.3 5:-1.35o 12:-.9"   (time:value[ease])
 * ease suffix applies to the segment that ENDS at that key: o = fast-out, i = accelerate, l = linear, b = overshoot, none = smooth.
 * Arm convention: x negative = raised forward, y positive = swing to the player's right, z positive (right arm) = outward.
 * Chain channels: LEN = chain length in blocks, TEN = tension (0 = loose and hanging, 1 = taut/straight).
 */
public class Anim {
    public static final int N = 22;
    public static final int RAX = 0, RAY = 1, RAZ = 2, LAX = 3, LAY = 4, LAZ = 5, BY = 6, BX = 7, LEAN = 8, MV = 9, SPIN = 10,
            RLX = 11, LLX = 12, RLY = 13, LLY = 14, RLEN = 15, RTEN = 16, LLEN = 17, LTEN = 18, JUMP = 19, CSP = 20, CAM = 21;
    private static final String[] NAMES = {"RAX", "RAY", "RAZ", "LAX", "LAY", "LAZ", "BY", "BX", "LEAN", "MV", "SPIN",
            "RLX", "LLX", "RLY", "LLY", "RLEN", "RTEN", "LLEN", "LTEN", "JUMP", "CSP", "CAM"};
    private static final int[] PARTNER = {3, 4, 5, 0, 1, 2, 6, 7, 8, 9, 10, 12, 11, 14, 13, 17, 18, 15, 16, 19, 20, 21};
    private static final float[] SIGN = {1, -1, -1, 1, -1, -1, -1, 1, 1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1, 1, 1, 1};

    /** Relaxed stance: arms slightly apart, blades dangling on short chains. */
    public static final float[] IDLE = {-0.3F, -0.12F, 0.2F, -0.3F, 0.12F, -0.2F, 0F, 0F, 0F, 0F, 0F,
            -0.1F, 0.1F, 0F, 0F, 0.25F, 0F, 0.25F, 0F, 0F, 0F, 0F};

    public final int length;
    private final float[][] times = new float[N][];
    private final float[][] vals = new float[N][];
    private final byte[][] ease = new byte[N][];

    private Anim(int length) { this.length = length; }

    private static int index(String name) {
        for (int i = 0; i < N; i++) if (NAMES[i].equals(name)) return i;
        throw new IllegalArgumentException("Unknown channel " + name);
    }

    private static Anim make(int length, String... lines) {
        Anim a = new Anim(length);
        for (String line : lines) {
            String[] tk = line.trim().split("\\s+");
            int ch = index(tk[0]);
            int n = tk.length - 1;
            a.times[ch] = new float[n];
            a.vals[ch] = new float[n];
            a.ease[ch] = new byte[n];
            for (int i = 0; i < n; i++) {
                String s = tk[i + 1];
                int c = s.indexOf(':');
                a.times[ch][i] = Float.parseFloat(s.substring(0, c));
                String vs = s.substring(c + 1);
                char last = vs.charAt(vs.length() - 1);
                byte e = 0;
                if (Character.isLetter(last)) {
                    e = (byte) (last == 'o' ? 1 : last == 'i' ? 2 : last == 'l' ? 3 : last == 'b' ? 4 : 0);
                    vs = vs.substring(0, vs.length() - 1);
                }
                a.vals[ch][i] = Float.parseFloat(vs);
                a.ease[ch][i] = e;
            }
        }
        return a;
    }

    private static float ease(int type, float s) {
        switch (type) {
            case 1: { float u = 1 - s; return 1 - u * u * u; }
            case 2: return s * s * s;
            case 3: return s;
            case 4: { float u = s - 1; return 1 + 2.2F * u * u * u + 1.2F * u * u; }
            default: return s * s * (3 - 2 * s);
        }
    }

    public void sample(float time, float[] out) {
        for (int ch = 0; ch < N; ch++) {
            float[] ts = times[ch];
            if (ts == null) { out[ch] = IDLE[ch]; continue; }
            float[] vs = vals[ch];
            int n = ts.length;
            if (time <= ts[0]) { out[ch] = vs[0]; continue; }
            if (time >= ts[n - 1]) { out[ch] = vs[n - 1]; continue; }
            int i = 0;
            while (i < n - 2 && time > ts[i + 1]) i++;
            float s = (time - ts[i]) / (ts[i + 1] - ts[i]);
            s = ease(ease[ch][i + 1], s);
            out[ch] = vs[i] + (vs[i + 1] - vs[i]) * s;
        }
    }

    public Anim mirrored() {
        Anim m = new Anim(length);
        for (int dst = 0; dst < N; dst++) {
            int src = PARTNER[dst];
            if (times[src] == null) continue;
            m.times[dst] = times[src].clone();
            m.ease[dst] = ease[src].clone();
            m.vals[dst] = new float[vals[src].length];
            for (int i = 0; i < vals[src].length; i++) m.vals[dst][i] = vals[src][i] * SIGN[dst];
        }
        return m;
    }

    /** 0-4 combo, 5 tornado, 6 front-flip slam, 7 Z, 8 X, 9 C, 10 idle chain-spin, 12 backflip. (11 = block, handled in ClientAnim) */
    public static final Anim[] ALL = new Anim[13];

    static {
        Anim slashR = make(12,
                "RAX 0:-.9 3:-2.3 5:-1.35o 7:-1.3 12:-.9",
                "RAY 0:-.25 3:.95 5:-1.1o 7:-1.15 12:-.25",
                "RAZ 0:0 3:.5 5:-.25o 12:0",
                "LAX 0:-.9 3:-1.7 5:-1.3o 7:-1.25 12:-.9",
                "LAY 0:.25 3:.75 5:-.9o 7:-.95 12:.25",
                "LAZ 0:0 3:.3 5:0 12:0",
                "BY 0:0 3:.6 5:-.7o 7:-.75 12:0",
                "LEAN 0:0 3:-.06 5:.18o 12:0",
                "MV 0:0 3:0 5:.3o 12:0",
                "RLX 0:0 3:.2 5:-.7o 12:0",
                "LLX 0:0 3:-.15 5:.5o 12:0",
                "RLEN 0:.5 2:.6 10:.6 12:.4", "RTEN 0:0 3:1 8:1 12:0",
                "LLEN 0:.5 2:.6 10:.6 12:.4", "LTEN 0:0 3:1 8:1 12:0");
        ALL[0] = slashR;
        ALL[1] = slashR.mirrored();

        ALL[2] = make(17,
                "RAX 0:-.9 2:-2.2 4:-1.3o 6:-2.0 9:-1.25o 11:-1.2 17:-.9",
                "RAY 0:-.25 2:.9 4:-1.1o 6:-.9 9:1.0o 11:1.05 17:-.25",
                "RAZ 0:0 2:.5 4:-.2o 6:-.4 9:.3o 17:0",
                "LAX 0:-.9 2:-1.6 4:-1.3o 6:-1.8 9:-1.3o 17:-.9",
                "LAY 0:.25 2:.7 4:-.9o 6:-.7 9:.9o 11:.95 17:.25",
                "BY 0:0 2:.6 4:-.7o 6:-.75 9:.8o 11:.85 17:0",
                "LEAN 0:0 4:.15 9:.2 17:0",
                "MV 0:0 4:.25o 9:.5o 17:0",
                "RLX 0:0 4:-.6o 9:.3 17:0",
                "LLX 0:0 4:.4o 9:-.5 17:0",
                "RLEN 0:.5 2:.6 15:.6 17:.4", "RTEN 0:0 2:1 15:1 17:0",
                "LLEN 0:.5 2:.6 15:.6 17:.4", "LTEN 0:0 2:1 15:1 17:0");

        Anim lashR = make(15,
                "RAX 0:-.9 3:-2.6 5:-1.55o 9:-1.55 15:-.9",
                "RAY 0:-.25 3:.9 5:-.2o 9:-.2 15:-.25",
                "RAZ 0:0 3:.9 5:0o 15:0",
                "LAX 0:-.9 3:-.5 5:-.4 9:-.5 15:-.9",
                "LAY 0:.25 3:.8 5:.5 9:.5 15:.25",
                "LAZ 0:0 3:.3 5:.2 15:0",
                "BY 0:0 3:.9 5:-.45o 9:-.4 15:0",
                "LEAN 0:0 3:-.12 5:.25o 9:.2 15:0",
                "MV 0:0 3:0 5:.55o 9:.55 15:0",
                "RLX 0:0 3:.3 5:-.8o 12:-.4 15:0",
                "LLX 0:0 3:-.2 5:.6o 12:.3 15:0",
                "RLEN 0:.5 3:1.2 5:8o 9:8 13:1.2 15:.4",
                "RTEN 0:0 3:0 5:1o 9:.7 13:0 15:0");
        ALL[3] = lashR;
        ALL[4] = lashR.mirrored();

        // ---- tornado: jump + spin, both chains out, legs tucked
        ALL[5] = make(20,
                "RAX 0:-.9 2:-.3 15:-.3 20:-.12",
                "RAY 0:-.25 2:0 15:0 20:0",
                "RAZ 0:0 2:1.5 15:1.5 20:.22",
                "LAX 0:-.9 2:-.3 15:-.3 20:-.12",
                "LAY 0:.25 2:0 15:0 20:0",
                "LAZ 0:0 2:-1.5 15:-1.5 20:-.22",
                "SPIN 0:0 3:0 15:-12.566l 20:-12.566",
                "JUMP 0:0 3:0 7:.9o 13:.9 18:0i 20:0",
                "RLX 0:0 5:-.9 14:-.9 19:0", "LLX 0:0 5:-.9 14:-.9 19:0",
                "LEAN 0:0 3:.1 15:.1 20:0",
                "RLEN 0:.5 3:.5 5:6o 15:6 19:.4", "RTEN 0:0 4:0 5:1o 15:1 19:0",
                "LLEN 0:.5 3:.5 5:6o 15:6 19:.4", "LTEN 0:0 4:0 5:1o 15:1 19:0");

        // ---- front flip + chain slam finisher
        ALL[6] = make(26,
                "RAX 0:-.9 5:-3.0 16:-3.0 18:-.7o 22:-.7 26:-.12",
                "RAY 0:-.25 5:-.15 18:-.2 26:0",
                "LAX 0:-.9 5:-3.0 16:-3.0 18:-.7o 22:-.7 26:-.12",
                "LAY 0:.25 5:.15 18:.2 26:0",
                "JUMP 0:0 3:0 7:.8o 12:1.2 17:.3i 18:0 26:0",
                "LEAN 0:0 3:-.2 6:-.1 8:.2 17:6.283 26:6.283",
                "RLX 0:0 6:-1.2 16:-1.2 18:-.9o 22:-.9 26:0",
                "LLX 0:0 6:-1.2 16:-1.2 18:.5 22:.5 26:0",
                "RLEN 0:.5 14:.5 18:7o 23:7 26:.4", "RTEN 0:0 16:0 18:1o 23:.8 26:0",
                "LLEN 0:.5 14:.5 18:7o 23:7 26:.4", "LTEN 0:0 16:0 18:1o 23:.8 26:0");

        // ---- Z: rapid alternating hand strikes, chains fan out in front
        ALL[7] = make(42,
                "RAX 0:-.9 3:-1.75o 5:-0.65o 7:-1.75o 9:-0.65o 11:-1.75o 13:-0.65o 15:-1.75o 17:-0.65o 19:-1.75o 21:-0.65o 23:-1.75o 25:-0.65o 27:-1.75o 29:-0.65o 31:-1.75o 33:-0.65o 35:-1.75o 37:-0.65o 42:-.12",
                "RAY 0:-.25 3:-0.35o 5:0.55o 7:-0.35o 9:0.55o 11:-0.35o 13:0.55o 15:-0.35o 17:0.55o 19:-0.35o 21:0.55o 23:-0.35o 25:0.55o 27:-0.35o 29:0.55o 31:-0.35o 33:0.55o 35:-0.35o 37:0.55o 42:0",
                "LAX 0:-.9 3:-0.65o 5:-1.75o 7:-0.65o 9:-1.75o 11:-0.65o 13:-1.75o 15:-0.65o 17:-1.75o 19:-0.65o 21:-1.75o 23:-0.65o 25:-1.75o 27:-0.65o 29:-1.75o 31:-0.65o 33:-1.75o 35:-0.65o 37:-1.75o 42:-.12",
                "LAY 0:.25 3:0.35o 5:-0.55o 7:0.35o 9:-0.55o 11:0.35o 13:-0.55o 15:0.35o 17:-0.55o 19:0.35o 21:-0.55o 23:0.35o 25:-0.55o 27:0.35o 29:-0.55o 31:0.35o 33:-0.55o 35:0.35o 37:-0.55o 42:0",
                "BY 0:0 3:0.22 5:-0.22 7:0.22 9:-0.22 11:0.22 13:-0.22 15:0.22 17:-0.22 19:0.22 21:-0.22 23:0.22 25:-0.22 27:0.22 29:-0.22 31:0.22 33:-0.22 35:0.22 37:-0.22 42:0",
                "RAZ 0:.22 3:.15 40:.15 42:.22",
                "LAZ 0:-.22 3:-.15 40:-.15 42:-.22",
                "LEAN 0:0 3:.12 38:.12 42:0",
                "RLX 0:0 3:-.4 38:-.4 42:0", "LLX 0:0 3:.3 38:.3 42:0",
                "RLEN 0:.5 3:5o 38:6 42:.4", "RTEN 0:0 3:.85 38:.85 42:0",
                "LLEN 0:.5 3:5o 38:6 42:.4", "LTEN 0:0 3:.85 38:.85 42:0");

        // ---- X: shadow step, 6 cross cuts, return to the start point
        ALL[8] = make(24,
                "RAX 0:-.9 2:-1.4 17:-1.4 23:-.12",
                "RAY 0:-.25 2:.8o 5:-1.0o 8:.8o 11:-1.0o 14:.8o 17:-1.0o 23:0",
                "LAX 0:-.9 2:-1.4 17:-1.4 23:-.12",
                "LAY 0:.25 2:-.8o 5:1.0o 8:-.8o 11:1.0o 14:-.8o 17:1.0o 23:0",
                "BY 0:0 2:-.6o 5:.7o 8:-.6o 11:.7o 14:-.6o 17:.7o 22:0",
                "LEAN 0:0 2:.45 17:.45 22:0",
                "MV 0:0 2:.3 17:.3 20:0",
                "RLX 0:0 2:-.8 17:-.8 22:0", "LLX 0:0 2:.6 17:.6 22:0",
                "RLEN 0:.5 2:.6 19:.6 24:.4", "RTEN 0:0 2:1 19:1 22:0",
                "LLEN 0:.5 2:.6 19:.6 24:.4", "LTEN 0:0 2:1 19:1 22:0");

        // ---- C: draw, then two quick crossing cuts (the X)
        ALL[9] = make(40,
                "RAX 0:-.9 10:-.8 12:-1.5o 13:-1.55 15:-1.1o 17:-1.1 28:-1.3 40:-.12",
                "RAY 0:-.25 10:1.0 12:-1.25o 13:-1.3 15:.9o 17:.95 28:.6 40:0",
                "RAZ 0:0 10:.4 12:-.3o 15:.3o 28:0 40:.22",
                "LAX 0:-.9 10:-.9 12:-1.5o 13:-1.5 15:-1.1o 17:-1.1 28:-1.3 40:-.12",
                "LAY 0:.25 10:1.2 12:-.7o 13:-.75 15:1.0o 17:1.05 28:.6 40:0",
                "BY 0:0 10:.9 12:-.85o 13:-.9 15:.8o 17:.85 28:.3 40:0",
                "LEAN 0:0 10:-.12 12:.3o 15:.3 28:.2 40:0",
                "MV 0:0 10:0 12:.6o 28:.6 36:0",
                "RLX 0:0 10:.5 12:-.8o 28:-.8 40:0", "LLX 0:0 10:-.4 12:.6o 28:.6 40:0",
                "RLEN 0:.5 10:.6 36:.6 40:.4", "RTEN 0:0 10:1 30:1 40:0",
                "LLEN 0:.5 10:.6 36:.6 40:.4", "LTEN 0:0 10:1 30:1 40:0");

        // ---- idle show: after standing still, whirls the blades on the chains in vertical circles beside the body
        ALL[10] = make(90,
                "RAX 0:-0.45l 3:-0.379l 6:-0.35l 9:-0.379l 12:-0.45l 15:-0.521l 18:-0.55l 21:-0.521l 24:-0.45l 27:-0.379l 30:-0.35l 33:-0.379l 36:-0.45l 39:-0.521l 42:-0.55l 45:-0.521l 48:-0.45l 51:-0.379l 54:-0.35l 57:-0.379l 60:-0.45l 63:-0.521l 66:-0.55l 69:-0.521l 72:-0.45l 75:-0.379l 78:-0.35l 81:-0.379l 84:-0.45l 87:-0.521l 90:-.3",
                "LAX 0:-0.45l 3:-0.521l 6:-0.55l 9:-0.521l 12:-0.45l 15:-0.379l 18:-0.35l 21:-0.379l 24:-0.45l 27:-0.521l 30:-0.55l 33:-0.521l 36:-0.45l 39:-0.379l 42:-0.35l 45:-0.379l 48:-0.45l 51:-0.521l 54:-0.55l 57:-0.521l 60:-0.45l 63:-0.379l 66:-0.35l 69:-0.379l 72:-0.45l 75:-0.521l 78:-0.55l 81:-0.521l 84:-0.45l 87:-0.379l 90:-.3",
                "BY 0:0l 3:0.085l 6:0.12l 9:0.085l 12:0l 15:-0.085l 18:-0.12l 21:-0.085l 24:0l 27:0.085l 30:0.12l 33:0.085l 36:0l 39:-0.085l 42:-0.12l 45:-0.085l 48:0l 51:0.085l 54:0.12l 57:0.085l 60:0l 63:-0.085l 66:-0.12l 69:-0.085l 72:0l 75:0.085l 78:0.12l 81:0.085l 84:0l 87:-0.085l 90:0",
                "RAY 0:-.12 8:-.25 82:-.25 90:-.12", "LAY 0:.12 8:.25 82:.25 90:.12",
                "RAZ 0:.2 8:.3 82:.3 90:.2", "LAZ 0:-.2 8:-.3 82:-.3 90:-.2",
                "CSP 0:0 10:0 80:60l 90:60",
                "CAM 0:0 8:1 82:1 90:0",
                "RLEN 0:.25 8:2.6 82:2.6 90:.25", "RTEN 0:0 8:.95 82:.95 90:0",
                "LLEN 0:.25 8:2.6 82:2.6 90:.25", "LTEN 0:0 8:.95 82:.95 90:0");

        // ---- backflip, whips the chains forward on landing
        ALL[12] = make(24,
                "JUMP 0:0 3:0 8:1.3o 14:1.3 19:0i 24:0",
                "LEAN 0:0 3:-.25 6:-.25 17:-6.283 24:-6.283",
                "RAX 0:-.9 4:-2.6 15:-2.6 18:-1.55o 22:-.12",
                "RAY 0:-.25 4:.2 15:.2 18:-.1o 24:0",
                "LAX 0:-.9 4:-2.6 15:-2.6 18:-.5 22:-.12",
                "LAY 0:.25 4:-.2 15:-.2 18:.4 24:0",
                "RLX 0:0 4:-1.1 15:-1.1 19:0", "LLX 0:0 4:-1.1 15:-1.1 19:0",
                "RLEN 0:.5 15:.5 18:7o 21:7 24:.4", "RTEN 0:0 16:0 18:1o 21:.7 24:0");
    }
}
