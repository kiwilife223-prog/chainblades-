package com.chainblades;

/**
 * Keyframe animations for the player model (angles in radians, time in ticks).
 * Channels: right arm xyz, left arm xyz, body yaw/pitch, whole-body lean, forward move, whole-body spin.
 * Arm convention: x negative = raised forward, y positive = swing to the player's right, z positive (right arm) = outward.
 */
public class Anim {
    public static final int N = 11;
    public static final int RAX = 0, RAY = 1, RAZ = 2, LAX = 3, LAY = 4, LAZ = 5, BY = 6, BX = 7, LEAN = 8, MV = 9, SPIN = 10;
    /** Idle two-handed grip. */
    public static final float[] IDLE = {-0.9F, -0.25F, 0F, -0.9F, 0.25F, 0F, 0F, 0F, 0F, 0F, 0F};

    public final int length;
    private final float[][] times = new float[N][];
    private final float[][] vals = new float[N][];
    private final boolean[] linear = new boolean[N];

    private Anim(int length) { this.length = length; }

    private Anim set(int ch, boolean lin, float... kv) {
        int n = kv.length / 2;
        times[ch] = new float[n];
        vals[ch] = new float[n];
        for (int i = 0; i < n; i++) { times[ch][i] = kv[2 * i]; vals[ch][i] = kv[2 * i + 1]; }
        linear[ch] = lin;
        return this;
    }
    private Anim t(int ch, float... kv) { return set(ch, false, kv); }
    private Anim lin(int ch, float... kv) { return set(ch, true, kv); }

    public void sample(float time, float[] out) {
        for (int ch = 0; ch < N; ch++) {
            float[] ts = times[ch];
            if (ts == null) { out[ch] = IDLE[ch]; continue; }
            float[] vs = vals[ch];
            int n = ts.length;
            if (time <= ts[0]) { out[ch] = vs[0]; continue; }
            if (time >= ts[n - 1]) { out[ch] = vs[n - 1]; continue; }
            int i = 0;
            while (i < n - 2 && time > ts[i + 1]) i++;
            float s = (time - ts[i]) / (ts[i + 1] - ts[i]);
            if (!linear[ch]) s = s * s * (3 - 2 * s);
            out[ch] = vs[i] + (vs[i + 1] - vs[i]) * s;
        }
    }

    public Anim mirrored() {
        Anim m = new Anim(length);
        int[][] map = {{RAX, LAX, 1}, {RAY, LAY, -1}, {RAZ, LAZ, -1}, {LAX, RAX, 1}, {LAY, RAY, -1}, {LAZ, RAZ, -1},
                {BY, BY, -1}, {BX, BX, 1}, {LEAN, LEAN, 1}, {MV, MV, 1}, {SPIN, SPIN, -1}};
        for (int[] e : map) {
            int dst = e[0], src = e[1];
            if (times[src] == null) continue;
            m.times[dst] = times[src].clone();
            m.vals[dst] = new float[vals[src].length];
            for (int i = 0; i < vals[src].length; i++) m.vals[dst][i] = vals[src][i] * e[2];
            m.linear[dst] = linear[src];
        }
        return m;
    }

    /** 0-6 combo, 7 storm (Z), 8 shadow step (X), 9 dimension cut (C). */
    public static final Anim[] ALL = new Anim[10];

    static {
        Anim slashR = new Anim(12)
                .t(RAX, 0, -.9f, 3, -2.3f, 5, -1.35f, 12, -.9f)
                .t(RAY, 0, -.25f, 3, .95f, 5, -1.1f, 12, -.25f)
                .t(RAZ, 0, 0f, 3, .5f, 5, -.25f, 12, 0f)
                .t(LAX, 0, -.9f, 3, -1.7f, 5, -1.3f, 12, -.9f)
                .t(LAY, 0, .25f, 3, .75f, 5, -.9f, 12, .25f)
                .t(LAZ, 0, 0f, 3, .3f, 5, 0f, 12, 0f)
                .t(BY, 0, 0f, 3, .6f, 5, -.7f, 12, 0f)
                .t(LEAN, 0, 0f, 3, -.06f, 5, .18f, 12, 0f)
                .t(MV, 0, 0f, 3, 0f, 5, .3f, 12, 0f);
        ALL[0] = slashR;
        ALL[1] = slashR.mirrored();

        ALL[2] = new Anim(17)
                .t(RAX, 0, -.9f, 2, -2.2f, 4, -1.3f, 6, -2.0f, 9, -1.25f, 17, -.9f)
                .t(RAY, 0, -.25f, 2, .9f, 4, -1.1f, 6, -.9f, 9, 1.0f, 17, -.25f)
                .t(RAZ, 0, 0f, 2, .5f, 4, -.2f, 6, -.4f, 9, .3f, 17, 0f)
                .t(LAX, 0, -.9f, 2, -1.6f, 4, -1.3f, 6, -1.8f, 9, -1.3f, 17, -.9f)
                .t(LAY, 0, .25f, 2, .7f, 4, -.9f, 6, -.7f, 9, .9f, 17, .25f)
                .t(BY, 0, 0f, 2, .6f, 4, -.7f, 6, -.75f, 9, .8f, 17, 0f)
                .t(LEAN, 0, 0f, 4, .15f, 9, .2f, 17, 0f)
                .t(MV, 0, 0f, 4, .25f, 9, .5f, 17, 0f);

        Anim lashR = new Anim(15)
                .t(RAX, 0, -.9f, 3, -2.6f, 5, -1.55f, 9, -1.55f, 15, -.9f)
                .t(RAY, 0, -.25f, 3, .9f, 5, -.2f, 9, -.2f, 15, -.25f)
                .t(RAZ, 0, 0f, 3, .9f, 5, 0f, 15, 0f)
                .t(LAX, 0, -.9f, 3, -.5f, 5, -.4f, 9, -.5f, 15, -.9f)
                .t(LAY, 0, .25f, 3, .8f, 5, .5f, 9, .5f, 15, .25f)
                .t(LAZ, 0, 0f, 3, .3f, 5, .2f, 15, 0f)
                .t(BY, 0, 0f, 3, .9f, 5, -.45f, 9, -.4f, 15, 0f)
                .t(LEAN, 0, 0f, 3, -.12f, 5, .25f, 9, .2f, 15, 0f)
                .t(MV, 0, 0f, 3, 0f, 5, .55f, 9, .55f, 15, 0f);
        ALL[3] = lashR;
        ALL[4] = lashR.mirrored();

        ALL[5] = new Anim(18)
                .t(RAX, 0, -.9f, 2, -.3f, 14, -.3f, 18, -.9f)
                .t(RAY, 0, -.25f, 2, 0f, 14, 0f, 18, -.25f)
                .t(RAZ, 0, 0f, 2, 1.5f, 14, 1.5f, 18, 0f)
                .t(LAX, 0, -.9f, 2, -.3f, 14, -.3f, 18, -.9f)
                .t(LAY, 0, .25f, 2, 0f, 14, 0f, 18, .25f)
                .t(LAZ, 0, 0f, 2, -1.5f, 14, -1.5f, 18, 0f)
                .lin(SPIN, 0, 0f, 2, 0f, 14, -6.283f, 18, -6.283f)
                .t(LEAN, 0, 0f, 2, .12f, 14, .12f, 18, 0f);

        ALL[6] = new Anim(22)
                .t(RAX, 0, -.9f, 6, -3.0f, 8, -3.05f, 9, -.7f, 12, -.7f, 22, -.9f)
                .t(RAY, 0, -.25f, 6, -.15f, 9, -.2f, 22, -.25f)
                .t(LAX, 0, -.9f, 6, -3.0f, 8, -3.05f, 9, -.7f, 12, -.7f, 22, -.9f)
                .t(LAY, 0, .25f, 6, .15f, 9, .2f, 22, .25f)
                .t(LEAN, 0, 0f, 6, -.22f, 8, -.22f, 9, .5f, 12, .45f, 22, 0f)
                .t(MV, 0, 0f, 8, 0f, 9, .45f, 22, 0f);

        ALL[7] = new Anim(42)
                .t(RAX, 0, -.9f, 3, -.5f, 8, -1.2f, 13, -.4f, 18, -1.2f, 23, -.4f, 28, -1.2f, 33, -.4f, 38, -.6f, 42, -.9f)
                .t(RAY, 0, -.25f, 3, 0f, 38, 0f, 42, -.25f)
                .t(RAZ, 0, 0f, 3, 1.4f, 38, 1.4f, 42, 0f)
                .t(LAX, 0, -.9f, 3, -.5f, 8, -.4f, 13, -1.2f, 18, -.4f, 23, -1.2f, 28, -.4f, 33, -1.2f, 38, -.6f, 42, -.9f)
                .t(LAY, 0, .25f, 3, 0f, 38, 0f, 42, .25f)
                .t(LAZ, 0, 0f, 3, -1.4f, 38, -1.4f, 42, 0f)
                .lin(SPIN, 0, 0f, 3, 0f, 38, -25.13f, 42, -25.13f)
                .t(LEAN, 0, 0f, 3, .1f, 38, .1f, 42, 0f);

        ALL[8] = new Anim(30)
                .t(RAX, 0, -.9f, 2, -1.4f, 20, -1.4f, 30, -.9f)
                .t(RAY, 0, -.25f, 2, .8f, 5, -1.0f, 8, .8f, 11, -1.0f, 14, .8f, 17, -1.0f, 20, .8f, 30, -.25f)
                .t(LAX, 0, -.9f, 2, -1.4f, 20, -1.4f, 30, -.9f)
                .t(LAY, 0, .25f, 2, -.8f, 5, 1.0f, 8, -.8f, 11, 1.0f, 14, -.8f, 17, 1.0f, 20, -.8f, 30, .25f)
                .t(BY, 0, 0f, 2, -.6f, 5, .7f, 8, -.6f, 11, .7f, 14, -.6f, 17, .7f, 20, -.6f, 30, 0f)
                .t(LEAN, 0, 0f, 2, .45f, 20, .45f, 30, 0f)
                .t(MV, 0, 0f, 2, .3f, 20, .3f, 30, 0f);

        ALL[9] = new Anim(40)
                .t(RAX, 0, -.9f, 10, -.8f, 12, -1.5f, 26, -1.4f, 40, -.9f)
                .t(RAY, 0, -.25f, 10, 1.0f, 12, -1.25f, 26, -1.2f, 40, -.25f)
                .t(RAZ, 0, 0f, 10, .4f, 12, -.3f, 26, -.3f, 40, 0f)
                .t(LAX, 0, -.9f, 10, -.9f, 12, -1.5f, 26, -1.4f, 40, -.9f)
                .t(LAY, 0, .25f, 10, 1.2f, 12, -.7f, 26, -.6f, 40, .25f)
                .t(BY, 0, 0f, 10, .9f, 12, -.85f, 26, -.8f, 40, 0f)
                .t(LEAN, 0, 0f, 10, -.12f, 12, .3f, 26, .25f, 40, 0f)
                .t(MV, 0, 0f, 10, 0f, 12, .6f, 26, .6f, 40, 0f);
    }
}
