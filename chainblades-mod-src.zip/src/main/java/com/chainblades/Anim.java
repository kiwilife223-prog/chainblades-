package com.chainblades;

/**
 * Keyframe animations (angles in radians, time in ticks), authored with a tiny text DSL:
 *   "RAX 0:-.9 3:-2.3 5:-1.35o 12:-.9"   (time:value[ease])
 * ease suffix applies to the segment that ENDS at that key: o = fast-out, i = accelerate, l = linear, b = overshoot, none = smooth.
 * Arm convention: x negative = raised forward, y positive = swing to the player's right, z positive (right arm) = outward.
 * Chain channels: LEN = chain length in blocks, TEN = tension (0 = loose and hanging, 1 = taut/straight).
 */
public class Anim {
    public static final int N = 19;
    public static final int RAX = 0, RAY = 1, RAZ = 2, LAX = 3, LAY = 4, LAZ = 5, BY = 6, BX = 7, LEAN = 8, MV = 9, SPIN = 10,
            RLX = 11, LLX = 12, RLY = 13, LLY = 14, RLEN = 15, RTEN = 16, LLEN = 17, LTEN = 18;
    private static final String[] NAMES = {"RAX", "RAY", "RAZ", "LAX", "LAY", "LAZ", "BY", "BX", "LEAN", "MV", "SPIN",
            "RLX", "LLX", "RLY", "LLY", "RLEN", "RTEN", "LLEN", "LTEN"};
    private static final int[] PARTNER = {3, 4, 5, 0, 1, 2, 6, 7, 8, 9, 10, 12, 11, 14, 13, 17, 18, 15, 16};
    private static final float[] SIGN = {1, -1, -1, 1, -1, -1, -1, 1, 1, 1, -1, 1, 1, -1, -1, 1, 1, 1, 1};

    /** Idle two-handed grip, blades dangling on short chains. */
    public static final float[] IDLE = {-0.9F, -0.25F, 0F, -0.9F, 0.25F, 0F, 0F, 0F, 0F, 0F, 0F,
            0F, 0F, 0F, 0F, 0.5F, 0F, 0.5F, 0F};

    public final int length;
    private final float[][] times = new float[N][];
    private final float[][] vals = new float[N][];
    private final byte[][] ease = new byte[N][];

    private Anim(int length) { this.length = length; }

    private static int index(String name) {
        for (int i = 0; i < N; i++) if (NAMES[i].equals(name)) return i;
        throw new IllegalArgumentException("Unknown channel " + name);
    }

    private static Anim make(int length, String... lines) {
        Anim a = new Anim(length);
        for (String line : lines) {
            String[] tk = line.trim().split("\\s+");
            int ch = index(tk[0]);
            int n = tk.length - 1;
            a.times[ch] = new float[n];
            a.vals[ch] = new float[n];
            a.ease[ch] = new byte[n];
            for (int i = 0; i < n; i++) {
                String s = tk[i + 1];
                int c = s.indexOf(':');
                a.times[ch][i] = Float.parseFloat(s.substring(0, c));
                String vs = s.substring(c + 1);
                char last = vs.charAt(vs.length() - 1);
                byte e = 0;
                if (Character.isLetter(last)) {
                    e = (byte) (last == 'o' ? 1 : last == 'i' ? 2 : last == 'l' ? 3 : last == 'b' ? 4 : 0);
                    vs = vs.substring(0, vs.length() - 1);
                }
                a.vals[ch][i] = Float.parseFloat(vs);
                a.ease[ch][i] = e;
            }
        }
        return a;
    }

    private static float ease(int type, float s) {
        switch (type) {
            case 1: { float u = 1 - s; return 1 - u * u * u; }
            case 2: return s * s * s;
            case 3: return s;
            case 4: { float u = s - 1; return 1 + 2.2F * u * u * u + 1.2F * u * u; }
            default: return s * s * (3 - 2 * s);
        }
    }

    public void sample(float time, float[] out) {
        for (int ch = 0; ch < N; ch++) {
            float[] ts = times[ch];
            if (ts == null) { out[ch] = IDLE[ch]; continue; }
            float[] vs = vals[ch];
            int n = ts.length;
            if (time <= ts[0]) { out[ch] = vs[0]; continue; }
            if (time >= ts[n - 1]) { out[ch] = vs[n - 1]; continue; }
            int i = 0;
            while (i < n - 2 && time > ts[i + 1]) i++;
            float s = (time - ts[i]) / (ts[i + 1] - ts[i]);
            s = ease(ease[ch][i + 1], s);
            out[ch] = vs[i] + (vs[i + 1] - vs[i]) * s;
        }
    }

    public Anim mirrored() {
        Anim m = new Anim(length);
        for (int dst = 0; dst < N; dst++) {
            int src = PARTNER[dst];
            if (times[src] == null) continue;
            m.times[dst] = times[src].clone();
            m.ease[dst] = ease[src].clone();
            m.vals[dst] = new float[vals[src].length];
            for (int i = 0; i < vals[src].length; i++) m.vals[dst][i] = vals[src][i] * SIGN[dst];
        }
        return m;
    }

    /** 0-6 combo, 7 storm (Z), 8 shadow step (X), 9 dimension cut (C). */
    public static final Anim[] ALL = new Anim[10];

    static {
        // ---- close combo: blades held rigid like swords (tension 1, short chain)
        Anim slashR = make(12,
                "RAX 0:-.9 3:-2.3 5:-1.35o 7:-1.3 12:-.9",
                "RAY 0:-.25 3:.95 5:-1.1o 7:-1.15 12:-.25",
                "RAZ 0:0 3:.5 5:-.25o 12:0",
                "LAX 0:-.9 3:-1.7 5:-1.3o 7:-1.25 12:-.9",
                "LAY 0:.25 3:.75 5:-.9o 7:-.95 12:.25",
                "LAZ 0:0 3:.3 5:0 12:0",
                "BY 0:0 3:.6 5:-.7o 7:-.75 12:0",
                "LEAN 0:0 3:-.06 5:.18o 12:0",
                "MV 0:0 3:0 5:.3o 12:0",
                "RLX 0:0 3:.2 5:-.7o 12:0",
                "LLX 0:0 3:-.15 5:.5o 12:0",
                "RLEN 0:.5 2:.6 10:.6 12:.5", "RTEN 0:0 3:1 8:1 12:0",
                "LLEN 0:.5 2:.6 10:.6 12:.5", "LTEN 0:0 3:1 8:1 12:0");
        ALL[0] = slashR;
        ALL[1] = slashR.mirrored();

        ALL[2] = make(17,
                "RAX 0:-.9 2:-2.2 4:-1.3o 6:-2.0 9:-1.25o 11:-1.2 17:-.9",
                "RAY 0:-.25 2:.9 4:-1.1o 6:-.9 9:1.0o 11:1.05 17:-.25",
                "RAZ 0:0 2:.5 4:-.2o 6:-.4 9:.3o 17:0",
                "LAX 0:-.9 2:-1.6 4:-1.3o 6:-1.8 9:-1.3o 17:-.9",
                "LAY 0:.25 2:.7 4:-.9o 6:-.7 9:.9o 11:.95 17:.25",
                "BY 0:0 2:.6 4:-.7o 6:-.75 9:.8o 11:.85 17:0",
                "LEAN 0:0 4:.15 9:.2 17:0",
                "MV 0:0 4:.25o 9:.5o 17:0",
                "RLX 0:0 4:-.6o 9:.3 17:0",
                "LLX 0:0 4:.4o 9:-.5 17:0",
                "RLEN 0:.5 2:.6 15:.6 17:.5", "RTEN 0:0 2:1 15:1 17:0",
                "LLEN 0:.5 2:.6 15:.6 17:.5", "LTEN 0:0 2:1 15:1 17:0");

        // ---- chain whip: right hand throws, left holds
        Anim lashR = make(15,
                "RAX 0:-.9 3:-2.6 5:-1.55o 9:-1.55 15:-.9",
                "RAY 0:-.25 3:.9 5:-.2o 9:-.2 15:-.25",
                "RAZ 0:0 3:.9 5:0o 15:0",
                "LAX 0:-.9 3:-.5 5:-.4 9:-.5 15:-.9",
                "LAY 0:.25 3:.8 5:.5 9:.5 15:.25",
                "LAZ 0:0 3:.3 5:.2 15:0",
                "BY 0:0 3:.9 5:-.45o 9:-.4 15:0",
                "LEAN 0:0 3:-.12 5:.25o 9:.2 15:0",
                "MV 0:0 3:0 5:.55o 9:.55 15:0",
                "RLX 0:0 3:.3 5:-.8o 12:-.4 15:0",
                "LLX 0:0 3:-.2 5:.6o 12:.3 15:0",
                "RLEN 0:.5 3:1.2 5:8o 9:8 13:1.2 15:.5",
                "RTEN 0:0 3:0 5:1o 9:.7 13:0 15:0");
        ALL[3] = lashR;
        ALL[4] = lashR.mirrored();

        // ---- chain spin: arms out, both chains taut, whole body spins
        ALL[5] = make(18,
                "RAX 0:-.9 2:-.3 14:-.3 18:-.9",
                "RAY 0:-.25 2:0 14:0 18:-.25",
                "RAZ 0:0 2:1.5 14:1.5 18:0",
                "LAX 0:-.9 2:-.3 14:-.3 18:-.9",
                "LAY 0:.25 2:0 14:0 18:.25",
                "LAZ 0:0 2:-1.5 14:-1.5 18:0",
                "SPIN 0:0 2:0 14:-6.283l 18:-6.283",
                "LEAN 0:0 2:.12 14:.12 18:0",
                "RLEN 0:.5 2:.5 4:6o 14:6 17:.5", "RTEN 0:0 3:0 4:1o 14:1 17:0",
                "LLEN 0:.5 2:.5 4:6o 14:6 17:.5", "LTEN 0:0 3:0 4:1o 14:1 17:0");

        // ---- slam finisher: chains swing overhead, then crash down
        ALL[6] = make(22,
                "RAX 0:-.9 6:-3.0 8:-3.05 9:-.7o 12:-.7 22:-.9",
                "RAY 0:-.25 6:-.15 9:-.2 22:-.25",
                "LAX 0:-.9 6:-3.0 8:-3.05 9:-.7o 12:-.7 22:-.9",
                "LAY 0:.25 6:.15 9:.2 22:.25",
                "LEAN 0:0 6:-.22 8:-.22 9:.5o 12:.45 22:0",
                "MV 0:0 8:0 9:.45o 22:0",
                "RLX 0:0 8:.3 9:-.9o 14:-.9 22:0",
                "LLX 0:0 8:-.3 9:.5o 14:.5 22:0",
                "RLEN 0:.5 6:2.5 8:3 9:7o 12:7 18:.5", "RTEN 0:0 8:0 9:1o 12:.8 18:0",
                "LLEN 0:.5 6:2.5 8:3 9:7o 12:7 18:.5", "LTEN 0:0 8:0 9:1o 12:.8 18:0");

        // ---- Z: blade storm
        ALL[7] = make(42,
                "RAX 0:-.9 3:-.5 8:-1.2 13:-.4 18:-1.2 23:-.4 28:-1.2 33:-.4 38:-.6 42:-.9",
                "RAY 0:-.25 3:0 38:0 42:-.25",
                "RAZ 0:0 3:1.4 38:1.4 42:0",
                "LAX 0:-.9 3:-.5 8:-.4 13:-1.2 18:-.4 23:-1.2 28:-.4 33:-1.2 38:-.6 42:-.9",
                "LAY 0:.25 3:0 38:0 42:.25",
                "LAZ 0:0 3:-1.4 38:-1.4 42:0",
                "SPIN 0:0 3:0 38:-25.13l 42:-25.13",
                "LEAN 0:0 3:.1 38:.1 42:0",
                "RLEN 0:.5 3:5o 38:6 42:.5", "RTEN 0:0 3:.9 38:.9 42:0",
                "LLEN 0:.5 3:5o 38:6 42:.5", "LTEN 0:0 3:.9 38:.9 42:0");

        // ---- X: shadow step, 7 alternating cross cuts
        ALL[8] = make(30,
                "RAX 0:-.9 2:-1.4 20:-1.4 30:-.9",
                "RAY 0:-.25 2:.8o 5:-1.0o 8:.8o 11:-1.0o 14:.8o 17:-1.0o 20:.8o 30:-.25",
                "LAX 0:-.9 2:-1.4 20:-1.4 30:-.9",
                "LAY 0:.25 2:-.8o 5:1.0o 8:-.8o 11:1.0o 14:-.8o 17:1.0o 20:-.8o 30:.25",
                "BY 0:0 2:-.6o 5:.7o 8:-.6o 11:.7o 14:-.6o 17:.7o 20:-.6o 30:0",
                "LEAN 0:0 2:.45 20:.45 30:0",
                "MV 0:0 2:.3 20:.3 30:0",
                "RLX 0:0 2:-.8 20:-.8 30:0", "LLX 0:0 2:.6 20:.6 30:0",
                "RLEN 0:.5 2:.6 22:.6 30:.5", "RTEN 0:0 2:1 22:1 30:0",
                "LLEN 0:.5 2:.6 22:.6 30:.5", "LTEN 0:0 2:1 22:1 30:0");

        // ---- C: dimension cut, iaido-style draw across the body
        ALL[9] = make(40,
                "RAX 0:-.9 10:-.8 12:-1.5o 26:-1.4 40:-.9",
                "RAY 0:-.25 10:1.0 12:-1.25o 26:-1.2 40:-.25",
                "RAZ 0:0 10:.4 12:-.3o 26:-.3 40:0",
                "LAX 0:-.9 10:-.9 12:-1.5o 26:-1.4 40:-.9",
                "LAY 0:.25 10:1.2 12:-.7o 26:-.6 40:.25",
                "BY 0:0 10:.9 12:-.85o 26:-.8 40:0",
                "LEAN 0:0 10:-.12 12:.3o 26:.25 40:0",
                "MV 0:0 10:0 12:.6o 26:.6 40:0",
                "RLX 0:0 10:.5 12:-.8o 28:-.8 40:0", "LLX 0:0 10:-.4 12:.6o 28:.6 40:0",
                "RLEN 0:.5 10:.6 36:.6 40:.5", "RTEN 0:0 10:1 30:1 40:0",
                "LLEN 0:.5 10:.6 36:.6 40:.5", "LTEN 0:0 10:1 30:1 40:0");
    }
}
