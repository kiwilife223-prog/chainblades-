package com.chainblades;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

public class ChainBladesItem extends SwordItem {
    public ChainBladesItem(Properties props) {
        super(Tiers.NETHERITE, 5, -2.4F, props);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        tip.add(Component.translatable("tooltip.chainblades.combo").withStyle(ChatFormatting.GRAY));
        tip.add(Component.translatable("tooltip.chainblades.z").withStyle(ChatFormatting.DARK_PURPLE));
        tip.add(Component.translatable("tooltip.chainblades.x").withStyle(ChatFormatting.DARK_PURPLE));
        tip.add(Component.translatable("tooltip.chainblades.c").withStyle(ChatFormatting.DARK_PURPLE));
    }
}
