package com.chainblades;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class Network {
    private static final String VERSION = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ChainBladesMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        int id = 0;
        CH.registerMessage(id++, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle);
        CH.registerMessage(id++, BWPacket.class, BWPacket::encode, BWPacket::decode, BWPacket::handle);
        CH.registerMessage(id++, AnimPacket.class, AnimPacket::encode, AnimPacket::decode, AnimPacket::handle);
        CH.registerMessage(id++, RibbonPacket.class, RibbonPacket::encode, RibbonPacket::decode, RibbonPacket::handle);
        CH.registerMessage(id++, WhipPacket.class, WhipPacket::encode, WhipPacket::decode, WhipPacket::handle);
        CH.registerMessage(id++, HitStopPacket.class, HitStopPacket::encode, HitStopPacket::decode, HitStopPacket::handle);
    }

    public static void hitStop(ServerPlayer p, int ticks) {
        CH.send(PacketDistributor.PLAYER.with(() -> p), new HitStopPacket(ticks));
    }

    private static void writeVec(FriendlyByteBuf b, Vec3 v) { b.writeDouble(v.x); b.writeDouble(v.y); b.writeDouble(v.z); }
    private static Vec3 readVec(FriendlyByteBuf b) { return new Vec3(b.readDouble(), b.readDouble(), b.readDouble()); }

    /** Server -> client: freeze own animation for a few ticks on impact */
    public static class HitStopPacket {
        public final int ticks;
        public HitStopPacket(int ticks) { this.ticks = ticks; }
        public static void encode(HitStopPacket m, FriendlyByteBuf b) { b.writeVarInt(m.ticks); }
        public static HitStopPacket decode(FriendlyByteBuf b) { return new HitStopPacket(b.readVarInt()); }
        public static void handle(HitStopPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.chainblades.client.ClientAnim.hitStop(m.ticks)));
            ctx.setPacketHandled(true);
        }
    }

    /** Server -> client: glowing ribbon (slash / streak / beam) along points */
    public static class RibbonPacket {
        public final int style, life, grow, delay;
        public final float width;
        public final Vec3[] pts;
        public RibbonPacket(int style, int life, int grow, int delay, float width, Vec3[] pts) {
            this.style = style; this.life = life; this.grow = grow; this.delay = delay; this.width = width; this.pts = pts;
        }
        public static void encode(RibbonPacket m, FriendlyByteBuf b) {
            b.writeVarInt(m.style); b.writeVarInt(m.life); b.writeVarInt(m.grow); b.writeVarInt(m.delay);
            b.writeFloat(m.width); b.writeVarInt(m.pts.length);
            for (Vec3 v : m.pts) writeVec(b, v);
        }
        public static RibbonPacket decode(FriendlyByteBuf b) {
            int style = b.readVarInt(), life = b.readVarInt(), grow = b.readVarInt(), delay = b.readVarInt();
            float w = b.readFloat();
            int n = b.readVarInt();
            Vec3[] pts = new Vec3[n];
            for (int i = 0; i < n; i++) pts[i] = readVec(b);
            return new RibbonPacket(style, life, grow, delay, w, pts);
        }
        public static void handle(RibbonPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                    com.chainblades.client.FxRender.addRibbon(m.style, m.life, m.grow, m.delay, m.width, m.pts)));
            ctx.setPacketHandled(true);
        }
    }

    /** Server -> client: a chain with a blade on its end (kind 0 = bezier whip, 1 = orbit around the owner) */
    public static class WhipPacket {
        public final int kind, owner, delay, life, hold, retract;
        public final boolean right;
        public final Vec3 p0, ctrl, p1;
        public final double radius, a0, a1, height;
        public WhipPacket(int kind, int owner, boolean right, Vec3 p0, Vec3 ctrl, Vec3 p1,
                          double radius, double a0, double a1, double height, int delay, int life, int hold, int retract) {
            this.kind = kind; this.owner = owner; this.right = right; this.p0 = p0; this.ctrl = ctrl; this.p1 = p1;
            this.radius = radius; this.a0 = a0; this.a1 = a1; this.height = height;
            this.delay = delay; this.life = life; this.hold = hold; this.retract = retract;
        }
        public static void encode(WhipPacket m, FriendlyByteBuf b) {
            b.writeVarInt(m.kind); b.writeVarInt(m.owner); b.writeBoolean(m.right);
            writeVec(b, m.p0); writeVec(b, m.ctrl); writeVec(b, m.p1);
            b.writeDouble(m.radius); b.writeDouble(m.a0); b.writeDouble(m.a1); b.writeDouble(m.height);
            b.writeVarInt(m.delay); b.writeVarInt(m.life); b.writeVarInt(m.hold); b.writeVarInt(m.retract);
        }
        public static WhipPacket decode(FriendlyByteBuf b) {
            int kind = b.readVarInt(), owner = b.readVarInt();
            boolean right = b.readBoolean();
            Vec3 p0 = readVec(b), ctrl = readVec(b), p1 = readVec(b);
            double radius = b.readDouble(), a0 = b.readDouble(), a1 = b.readDouble(), height = b.readDouble();
            return new WhipPacket(kind, owner, right, p0, ctrl, p1, radius, a0, a1, height,
                    b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt());
        }
        public static void handle(WhipPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                    com.chainblades.client.FxRender.addWhip(m)));
            ctx.setPacketHandled(true);
        }
    }

    /** Tell everyone who sees this player to play an animation. */
    public static void anim(ServerPlayer p, int animId) {
        CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new AnimPacket(p.getId(), animId));
    }

    /** Server -> client: play animation animId on entity entityId */
    public static class AnimPacket {
        public final int entityId, animId;
        public AnimPacket(int entityId, int animId) { this.entityId = entityId; this.animId = animId; }
        public static void encode(AnimPacket m, FriendlyByteBuf b) { b.writeVarInt(m.entityId); b.writeVarInt(m.animId); }
        public static AnimPacket decode(FriendlyByteBuf b) { return new AnimPacket(b.readVarInt(), b.readVarInt()); }
        public static void handle(AnimPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.chainblades.client.ClientAnim.play(m.entityId, m.animId)));
            ctx.setPacketHandled(true);
        }
    }

    /** Client -> server: -1 = attack, 0/1/2 = skills Z/X/C */
    public static class ActionPacket {
        public final int action;
        public ActionPacket(int action) { this.action = action; }
        public static void encode(ActionPacket m, FriendlyByteBuf b) { b.writeVarInt(m.action + 1); }
        public static ActionPacket decode(FriendlyByteBuf b) { return new ActionPacket(b.readVarInt() - 1); }
        public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> {
                ServerPlayer p = ctx.getSender();
                if (p == null) return;
                if (m.action == -1) Combat.attack(p);
                else SkillManager.start(p, m.action);
            });
            ctx.setPacketHandled(true);
        }
    }

    /** Server -> client: black & white screen for N ticks */
    public static class BWPacket {
        public final int ticks;
        public BWPacket(int ticks) { this.ticks = ticks; }
        public static void encode(BWPacket m, FriendlyByteBuf b) { b.writeVarInt(m.ticks); }
        public static BWPacket decode(FriendlyByteBuf b) { return new BWPacket(b.readVarInt()); }
        public static void handle(BWPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.startBW(m.ticks)));
            ctx.setPacketHandled(true);
        }
    }
}
