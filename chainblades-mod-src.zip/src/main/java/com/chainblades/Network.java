package com.chainblades;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class Network {
    private static final String VERSION = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ChainBladesMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        int id = 0;
        CH.registerMessage(id++, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle);
        CH.registerMessage(id++, BWPacket.class, BWPacket::encode, BWPacket::decode, BWPacket::handle);
        CH.registerMessage(id++, AnimPacket.class, AnimPacket::encode, AnimPacket::decode, AnimPacket::handle);
    }

    /** Tell everyone who sees this player to play an animation. */
    public static void anim(ServerPlayer p, int animId) {
        CH.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> p), new AnimPacket(p.getId(), animId));
    }

    /** Server -> client: play animation animId on entity entityId */
    public static class AnimPacket {
        public final int entityId, animId;
        public AnimPacket(int entityId, int animId) { this.entityId = entityId; this.animId = animId; }
        public static void encode(AnimPacket m, FriendlyByteBuf b) { b.writeVarInt(m.entityId); b.writeVarInt(m.animId); }
        public static AnimPacket decode(FriendlyByteBuf b) { return new AnimPacket(b.readVarInt(), b.readVarInt()); }
        public static void handle(AnimPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.chainblades.client.ClientAnim.play(m.entityId, m.animId)));
            ctx.setPacketHandled(true);
        }
    }

    /** Client -> server: -1 = attack, 0/1/2 = skills Z/X/C */
    public static class ActionPacket {
        public final int action;
        public ActionPacket(int action) { this.action = action; }
        public static void encode(ActionPacket m, FriendlyByteBuf b) { b.writeVarInt(m.action + 1); }
        public static ActionPacket decode(FriendlyByteBuf b) { return new ActionPacket(b.readVarInt() - 1); }
        public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> {
                ServerPlayer p = ctx.getSender();
                if (p == null) return;
                if (m.action == -1) Combat.attack(p);
                else SkillManager.start(p, m.action);
            });
            ctx.setPacketHandled(true);
        }
    }

    /** Server -> client: black & white screen for N ticks */
    public static class BWPacket {
        public final int ticks;
        public BWPacket(int ticks) { this.ticks = ticks; }
        public static void encode(BWPacket m, FriendlyByteBuf b) { b.writeVarInt(m.ticks); }
        public static BWPacket decode(FriendlyByteBuf b) { return new BWPacket(b.readVarInt()); }
        public static void handle(BWPacket m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientState.startBW(m.ticks)));
            ctx.setPacketHandled(true);
        }
    }
}
