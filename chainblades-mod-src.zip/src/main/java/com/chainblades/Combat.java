package com.chainblades;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Basic attack combo (8 steps): 0-2 close slashes, 3-4 chain lashes, 5 tornado jump-spin, 6 backflip, 7 front-flip slam.
 */
public class Combat {
    private static class State { int step; long last; long busyUntil; }
    private static final Map<UUID, State> STATES = new HashMap<>();

    public static void attack(ServerPlayer p) {
        if (!(p.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (SkillManager.isBusy(p) || p.isUsingItem()) return;
        ServerLevel l = p.serverLevel();
        long now = l.getGameTime();
        State s = STATES.computeIfAbsent(p.getUUID(), k -> new State());
        if (now < s.busyUntil || now - s.last < 7) return;
        if (now - s.last > 30) s.step = 0;
        s.last = now;
        int step = s.step;
        s.step = (step + 1) % 8;
        Network.anim(p, step < 6 ? step : (step == 6 ? 12 : 6));

        switch (step) {
            case 0 -> grip(p, 3.6, 7F, -70, 70, 0.9, 3);
            case 1 -> grip(p, 3.6, 7.5F, 70, -70, -0.9, 3);
            case 2 -> {
                grip(p, 3.8, 6F, -75, 75, 1.2, 3);
                grip(p, 3.8, 9F, 75, -75, -1.2, 9);
            }
            case 3 -> lash(p, 8.0, 9F, 1);
            case 4 -> lash(p, 9.0, 10F, -1);
            case 5 -> { s.busyUntil = now + 18; tornado(p); }
            case 6 -> { s.busyUntil = now + 22; backflip(p); }
            default -> { s.busyUntil = now + 24; flipSlam(p); }
        }
    }

    /** Hit + sweep arcs happen at 'delay' ticks, matching the strike frame of the animation. */
    private static void grip(ServerPlayer p, double range, float dmg, double from, double to, double tilt, int delay) {
        ServerLevel l = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Scheduler.later(delay, () -> {
            Vec3 center = p.position().add(0, p.getEyeHeight() * 0.7, 0);
            FX.sound(l, center, SoundEvents.PLAYER_ATTACK_SWEEP, 1F, 0.7F + l.random.nextFloat() * 0.3F);
            Util.lunge(p, 0.18);
            for (LivingEntity e : Util.cone(p, range, 0.3)) Util.hit(p, e, dmg, 0.5F);
            for (int k = 0; k < 4; k++) {
                final int kk = k;
                Scheduler.later(k, () -> {
                    double a0 = from + (to - from) * kk / 4.0;
                    double a1 = from + (to - from) * (kk + 1) / 4.0;
                    for (double r = range - 1.4; r <= range - 0.2; r += 0.6) FX.arc(l, center, look, r, a0, a1, tilt);
                });
            }
        });
    }

    private static void lash(ServerPlayer p, double range, float dmg, int side) {
        ServerLevel l = p.serverLevel();
        Scheduler.later(3, () -> {
            Vec3 look = p.getLookAngle();
            Vec3 eye = p.getEyePosition();
            Vec3 hand = eye.add(look.scale(0.4)).add(Util.right(look).scale(0.45 * side)).add(0, -0.45, 0);
            FX.sound(l, eye, SoundEvents.CHAIN_BREAK, 1.2F, 0.6F);
            FX.sound(l, eye, SoundEvents.PLAYER_ATTACK_STRONG, 1F, 0.8F);
            Util.lunge(p, 0.35);
            for (LivingEntity e : Util.cone(p, range, 0.55)) Util.hit(p, e, dmg, 0.9F);
            for (int k = 0; k < 4; k++) {
                final int kk = k;
                Scheduler.later(k, () -> {
                    double ang = side * (45 - kk * 30);
                    Vec3 d = look.yRot((float) Math.toRadians(ang));
                    FX.chain(l, hand, eye.add(d.scale(range * (0.4 + 0.2 * kk))));
                });
            }
        });
    }

    private static void tornado(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        Scheduler.later(3, () -> {
            p.setDeltaMovement(p.getDeltaMovement().add(0, 0.45, 0));
            p.hurtMarked = true;
        });
        for (int k = 0; k < 3; k++) {
            final int kk = k;
            Scheduler.later(6 + kk * 3, () -> {
                Vec3 c = p.position().add(0, 1.0, 0);
                FX.sound(l, c, SoundEvents.CHAIN_BREAK, 1.2F, 0.5F + kk * 0.1F);
                FX.sound(l, c, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2F, 0.5F);
                for (LivingEntity e : Util.around(p, 6)) Util.hit(p, e, 6F, 0.8F);
                for (int d = 0; d < 8; d++) {
                    double a = Math.toRadians(d * 45 + kk * 15);
                    Vec3 end = c.add(Math.cos(a) * 6.5, 0.1, Math.sin(a) * 6.5);
                    FX.ribbon(l, FX.straight(c, end, 8), 0.18F, 6, 3, 1, 0);
                    FX.blade(l, end);
                }
                FX.ring(l, p.position().add(0, 0.3, 0), 4 + kk, 28, FX.PURPLE);
            });
        }
    }

    private static void backflip(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        Vec3 back = Util.flat(p.getLookAngle()).scale(-1);
        Scheduler.later(3, () -> {
            p.setDeltaMovement(back.x * 0.6, 0.5, back.z * 0.6);
            p.hurtMarked = true;
            FX.sound(l, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1F, 0.5F);
        });
        Scheduler.later(18, () -> {
            Vec3 look = p.getLookAngle();
            Vec3 eye = p.getEyePosition();
            Vec3 right = Util.right(look);
            FX.sound(l, eye, SoundEvents.CHAIN_BREAK, 1.4F, 0.5F);
            FX.sound(l, eye, SoundEvents.PLAYER_ATTACK_STRONG, 1F, 0.7F);
            for (LivingEntity e : Util.cone(p, 8.0, 0.5)) Util.hit(p, e, 11F, 1.3F);
            for (int s = -1; s <= 1; s += 2) {
                Vec3 hand = eye.add(look.scale(0.4)).add(right.scale(0.4 * s)).add(0, -0.45, 0);
                Vec3 end = eye.add(look.scale(8)).add(right.scale(1.2 * s));
                FX.ribbon(l, FX.straight(hand, end, 10), 0.22F, 8, 3, 1, 0);
                FX.blade(l, end);
            }
            FX.ring(l, p.position().add(0, 0.2, 0), 2.5, 24, FX.PURPLE);
        });
    }

    private static void flipSlam(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        LivingEntity t = Util.findTarget(p, 10);
        Scheduler.later(3, () -> {
            Vec3 dir = t != null && t.isAlive() ? Util.flat(Util.center(t).subtract(p.position())) : Util.flat(p.getLookAngle());
            double dist = t != null && t.isAlive() ? Math.min(6, p.distanceTo(t)) : 4;
            double sp = Math.min(0.55, dist * 0.12);
            p.setDeltaMovement(dir.x * sp, 0.5, dir.z * sp);
            p.hurtMarked = true;
            FX.sound(l, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1F, 0.6F);
        });
        Scheduler.later(18, () -> {
            Vec3 imp = p.position().add(Util.flat(p.getLookAngle()).scale(2.2));
            FX.sound(l, imp, SoundEvents.GENERIC_EXPLODE, 1F, 1.2F);
            FX.sound(l, imp, SoundEvents.ANVIL_LAND, 1F, 0.5F);
            FX.sound(l, imp, SoundEvents.CHAIN_BREAK, 1.5F, 0.4F);
            for (LivingEntity e : Util.aoe(p, imp, 4.0)) {
                Util.hit(p, e, 16F, 0.8F);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.7, 0));
                e.hurtMarked = true;
            }
            FX.shockwave(l, imp, 6.0);
            l.sendParticles(ParticleTypes.FLASH, imp.x, imp.y + 0.6, imp.z, 1, 0, 0, 0, 0);
            l.sendParticles(ParticleTypes.EXPLOSION, imp.x, imp.y + 0.5, imp.z, 3, 1.0, 0.3, 1.0, 0);
            FX.p(l, ParticleTypes.REVERSE_PORTAL, imp.add(0, 1, 0), 30, 1.2, 0.3);
        });
    }
}
