package com.chainblades;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Basic attack combo (7 steps, each has its own client animation with the same id):
 * 0-2: blades gripped by the handles, 3-4: chain lashes, 5: chain spin, 6: chain slam finisher.
 */
public class Combat {
    private static class State { int step; long last; }
    private static final Map<UUID, State> STATES = new HashMap<>();

    public static void attack(ServerPlayer p) {
        if (!(p.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (SkillManager.isBusy(p)) return;
        ServerLevel l = p.serverLevel();
        long now = l.getGameTime();
        State s = STATES.computeIfAbsent(p.getUUID(), k -> new State());
        if (now - s.last < 7) return;
        if (now - s.last > 26) s.step = 0;
        s.last = now;
        int step = s.step;
        s.step = (step + 1) % 7;
        Network.anim(p, step);

        switch (step) {
            case 0 -> grip(p, 3.6, 7F, -70, 70, 0.9, 3);
            case 1 -> grip(p, 3.6, 7.5F, 70, -70, -0.9, 3);
            case 2 -> {
                grip(p, 3.8, 6F, -75, 75, 1.2, 3);
                grip(p, 3.8, 9F, 75, -75, -1.2, 9);
            }
            case 3 -> lash(p, 8.0, 9F, 1);
            case 4 -> lash(p, 9.0, 10F, -1);
            case 5 -> spin(p);
            default -> slam(p);
        }
    }

    /** Hit + sweep arcs happen at 'delay' ticks, matching the strike frame of the animation. */
    private static void grip(ServerPlayer p, double range, float dmg, double from, double to, double tilt, int delay) {
        ServerLevel l = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Scheduler.later(delay, () -> {
            Vec3 center = p.position().add(0, p.getEyeHeight() * 0.7, 0);
            FX.sound(l, center, SoundEvents.PLAYER_ATTACK_SWEEP, 1F, 0.7F + l.random.nextFloat() * 0.3F);
            Util.lunge(p, 0.18);
            for (LivingEntity e : Util.cone(p, range, 0.3)) Util.hit(p, e, dmg, 0.5F);
            for (int k = 0; k < 4; k++) {
                final int kk = k;
                Scheduler.later(k, () -> {
                    double a0 = from + (to - from) * kk / 4.0;
                    double a1 = from + (to - from) * (kk + 1) / 4.0;
                    for (double r = range - 1.4; r <= range - 0.2; r += 0.6) FX.arc(l, center, look, r, a0, a1, tilt);
                });
            }
        });
    }

    private static void lash(ServerPlayer p, double range, float dmg, int side) {
        ServerLevel l = p.serverLevel();
        Scheduler.later(3, () -> {
            Vec3 look = p.getLookAngle();
            Vec3 eye = p.getEyePosition();
            Vec3 hand = eye.add(look.scale(0.4)).add(Util.right(look).scale(0.45 * side)).add(0, -0.45, 0);
            FX.sound(l, eye, SoundEvents.CHAIN_BREAK, 1.2F, 0.6F);
            FX.sound(l, eye, SoundEvents.PLAYER_ATTACK_STRONG, 1F, 0.8F);
            Util.lunge(p, 0.35);
            for (LivingEntity e : Util.cone(p, range, 0.55)) Util.hit(p, e, dmg, 0.9F);
            for (int k = 0; k < 4; k++) {
                final int kk = k;
                Scheduler.later(k, () -> {
                    double ang = side * (45 - kk * 30);
                    Vec3 d = look.yRot((float) Math.toRadians(ang));
                    FX.chain(l, hand, eye.add(d.scale(range * (0.4 + 0.2 * kk))));
                });
            }
        });
    }

    private static void spin(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        Scheduler.later(2, () -> {
            Vec3 c = p.position().add(0, 1.0, 0);
            FX.sound(l, c, SoundEvents.CHAIN_BREAK, 1.3F, 0.5F);
            FX.sound(l, c, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2F, 0.5F);
            for (LivingEntity e : Util.around(p, 6)) Util.hit(p, e, 9F, 1.0F);
            for (int k = 0; k < 12; k++) {
                final int kk = k;
                Scheduler.later(k, () -> {
                    Vec3 cc = p.position().add(0, 1.0, 0);
                    double a = Math.toRadians(kk * 30 + 20);
                    FX.chain(l, cc, cc.add(Math.cos(a) * 6, 0.2, Math.sin(a) * 6));
                    FX.chain(l, cc, cc.add(Math.cos(a + Math.PI) * 6, 0.2, Math.sin(a + Math.PI) * 6));
                    FX.ring(l, p.position().add(0, 0.3, 0), 1.5 + kk * 0.4, 24, FX.PURPLE);
                });
            }
        });
    }

    private static void slam(ServerPlayer p) {
        ServerLevel l = p.serverLevel();
        LivingEntity t = Util.findTarget(p, 9);
        Vec3 pt = t != null ? t.position() : p.position().add(Util.flat(p.getLookAngle()).scale(7));
        Vec3 hand = p.getEyePosition().add(0, 0.2, 0);
        FX.sound(l, hand, SoundEvents.CHAIN_BREAK, 1.5F, 0.4F);
        FX.chain(l, hand, hand.add(0, 3.5, 0));
        Scheduler.later(6, () -> FX.chain(l, p.getEyePosition().add(0, 0.2, 0), p.getEyePosition().add(0, 3.5, 0)));
        Scheduler.later(9, () -> {
            Util.lunge(p, 0.5);
            Vec3 h = p.getEyePosition().add(0, 0.2, 0);
            FX.chain(l, h, pt.add(0, 0.5, 0));
            FX.sound(l, pt, SoundEvents.GENERIC_EXPLODE, 0.9F, 1.3F);
            FX.sound(l, pt, SoundEvents.ANVIL_LAND, 1F, 0.5F);
            for (LivingEntity e : Util.aoe(p, pt, 3.5)) {
                Util.hit(p, e, 14F, 0.8F);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.7, 0));
                e.hurtMarked = true;
            }
            l.sendParticles(ParticleTypes.EXPLOSION, pt.x, pt.y + 0.5, pt.z, 3, 1.0, 0.3, 1.0, 0);
            for (int i = 1; i <= 4; i++) FX.ring(l, pt.add(0, 0.2, 0), i * 0.9, 28, i % 2 == 0 ? FX.BLACK : FX.PURPLE);
            FX.p(l, ParticleTypes.REVERSE_PORTAL, pt.add(0, 1, 0), 40, 1.2, 0.3);
        });
    }
}
