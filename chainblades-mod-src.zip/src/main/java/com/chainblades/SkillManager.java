package com.chainblades;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

/** Skills: 0 = Z Blade Storm, 1 = X Shadow Step, 2 = C Dimension Cut. */
@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID)
public class SkillManager {
    private static class Active {
        final ServerPlayer p;
        final int id;
        int t = 0;
        int hits = 0;
        LivingEntity target;
        Vec3 last, origin, dir;
        float yaw, pitch;
        final Set<Integer> hit = new HashSet<>();
        Active(ServerPlayer p, int id) { this.p = p; this.id = id; }
    }

    private static final Map<UUID, Active> ACTIVE = new HashMap<>();
    private static final Map<UUID, long[]> CD = new HashMap<>();
    private static final int[] COOLDOWN = {300, 220, 500};
    private static final Random RNG = new Random();

    public static boolean isBusy(ServerPlayer p) { return ACTIVE.containsKey(p.getUUID()); }

    public static void start(ServerPlayer p, int id) {
        if (id < 0 || id > 2) return;
        if (!(p.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (ACTIVE.containsKey(p.getUUID()) || p.isUsingItem()) return;
        long now = p.level().getGameTime();
        long[] cd = CD.computeIfAbsent(p.getUUID(), k -> new long[3]);
        if (now < cd[id]) {
            p.displayClientMessage(Component.literal("Перезарядка: " + ((cd[id] - now) / 20 + 1) + " с"), true);
            return;
        }
        Active a = new Active(p, id);
        if (id == 1) {
            a.target = Util.findTarget(p, 20);
            if (a.target == null) {
                p.displayClientMessage(Component.literal("Немає цілі поблизу"), true);
                return;
            }
        }
        cd[id] = now + COOLDOWN[id];
        ACTIVE.put(p.getUUID(), a);
        Network.anim(p, 7 + id);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || ACTIVE.isEmpty()) return;
        Iterator<Active> it = ACTIVE.values().iterator();
        while (it.hasNext()) {
            Active a = it.next();
            if (a.p.isRemoved() || !a.p.isAlive()) { it.remove(); continue; }
            boolean done;
            try {
                done = switch (a.id) {
                    case 0 -> tickStorm(a);
                    case 1 -> tickShadow(a);
                    default -> tickCut(a);
                };
            } catch (Exception ex) {
                ex.printStackTrace();
                done = true;
            }
            a.t++;
            if (done) it.remove();
        }
    }

    // ---------- Z: Blade Storm (radius 7, 2 seconds of non-stop chain strikes) ----------
    private static boolean tickStorm(Active a) {
        ServerPlayer p = a.p;
        ServerLevel l = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 flat = Util.flat(look);
        Vec3 right = Util.right(look);
        Vec3 c = p.position().add(0, 1.0, 0);
        if (a.t == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 44, 4, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 45, 2, false, false));
            FX.sound(l, c, SoundEvents.WITHER_SHOOT, 1.2F, 0.6F);
        }
        if (a.t >= 3 && a.t <= 38 && a.t % 2 == 1) {
            // half-circle in front of the player
            for (LivingEntity e : Util.cone(p, 7, 0.0)) Util.hit(p, e, 3.2F, 0.15F);
            double r = 2 + (a.t % 12) * 0.45;
            FX.arc(l, p.position().add(0, 0.9, 0), look, r, -90, 90, 0.3);
            for (int k = 0; k < 3; k++) {
                double ang = Math.toRadians(-80 + RNG.nextDouble() * 160);
                double d = 3.5 + RNG.nextDouble() * 3.5;
                Vec3 end = c.add(flat.yRot((float) ang).scale(d)).add(0, RNG.nextDouble() * 1.6 - 0.8, 0);
                Vec3 hand = c.add(right.scale(k % 2 == 0 ? 0.4 : -0.4)).add(look.scale(0.4)).add(0, 0.2, 0);
                FX.ribbon(l, FX.straight(hand, end, 8), 0.14F, 6, 3, 1, 0);
                FX.blade(l, end);
            }
            if (a.t % 4 == 3) {
                FX.sound(l, c, SoundEvents.PLAYER_ATTACK_SWEEP, 1F, 0.6F + RNG.nextFloat() * 0.5F);
                FX.sound(l, c, SoundEvents.CHAIN_HIT, 1F, 0.7F);
            }
        }
        if (a.t == 40) {
            for (LivingEntity e : Util.cone(p, 7.5, 0.0)) {
                Util.hit(p, e, 9F, 1.5F);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.5, 0));
                e.hurtMarked = true;
            }
            for (int i = 3; i <= 7; i += 2) FX.arc(l, p.position().add(0, 0.9, 0), look, i, -90, 90, 0.2);
            l.sendParticles(ParticleTypes.FLASH, c.x + flat.x * 3, c.y, c.z + flat.z * 3, 1, 0, 0, 0, 0);
            FX.sound(l, c, SoundEvents.GENERIC_EXPLODE, 1F, 1.2F);
        }
        return a.t >= 40;
    }

    // ---------- X: Shadow Step (vanish, 7 lightning strikes, only black streaks are visible) ----------
    private static boolean tickShadow(Active a) {
        ServerPlayer p = a.p;
        ServerLevel l = p.serverLevel();
        if (a.t == 0) {
            a.last = p.position();
            a.origin = p.position();
            a.yaw = p.getYRot();
            a.pitch = p.getXRot();
            p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 26, 0, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 28, 4, false, false));
            FX.p(l, ParticleTypes.LARGE_SMOKE, p.position().add(0, 1, 0), 12, 0.4, 0.05);
            FX.p(l, ParticleTypes.REVERSE_PORTAL, p.position().add(0, 1, 0), 25, 0.5, 0.2);
            FX.sound(l, p.position(), SoundEvents.ENDERMAN_TELEPORT, 1F, 0.5F);
        }
        // 6 cuts, all on the same target while it is alive
        if (a.t >= 2 && (a.t - 2) % 3 == 0 && a.hits < 6) {
            if (a.target == null || !a.target.isAlive()) a.target = Util.findTarget(p, 12);
            if (a.target == null) {
                a.hits = 6;
            } else {
                LivingEntity tg = a.target;
                double ang = RNG.nextDouble() * Math.PI * 2;
                double cx = Math.cos(ang), cz = Math.sin(ang);
                Vec3 np = tg.position().add(cx * 2.2, 0, cz * 2.2);
                Vec3 through = tg.position().add(-cx * 2.2, 0, -cz * 2.2);
                FX.streak(l, a.last.add(0, 1, 0), np.add(0, 1, 0));
                float yaw = (float) Math.toDegrees(Math.atan2(cx, -cz));
                p.teleportTo(l, np.x, np.y, np.z, yaw, 0F);
                FX.streak(l, np.add(0, 1, 0), through.add(0, 1, 0));
                Vec3 tc = Util.center(tg);
                FX.blade(l, tc);
                boolean last = a.hits == 5;
                Util.hit(p, tg, last ? 14F : 6.5F, last ? 1.5F : 0.2F);
                FX.sound(l, tc, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2F, 1.4F);
                FX.sound(l, tc, SoundEvents.PLAYER_ATTACK_CRIT, 1F, 0.8F);
                a.last = np;
                a.hits++;
            }
        }
        // return to where the skill started
        if (a.t == 20) {
            Vec3 back = a.origin;
            FX.streak(l, p.position().add(0, 1, 0), back.add(0, 1, 0));
            p.teleportTo(l, back.x, back.y, back.z, a.yaw, a.pitch);
            p.removeEffect(MobEffects.INVISIBILITY);
            FX.p(l, ParticleTypes.LARGE_SMOKE, back.add(0, 1, 0), 15, 0.4, 0.05);
            FX.p(l, ParticleTypes.END_ROD, back.add(0, 1, 0), 12, 0.5, 0.15);
            FX.sound(l, back, SoundEvents.ENDERMAN_TELEPORT, 1F, 1.3F);
        }
        return a.t >= 24;
    }

    // ---------- C: Dimension Cut (charge, huge long-range slash, B&W screen for 2 seconds) ----------
    private static boolean tickCut(Active a) {
        ServerPlayer p = a.p;
        ServerLevel l = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 hand = p.getEyePosition().add(look.scale(0.6)).add(0, -0.5, 0);
        if (a.t == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 14, 9, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 70, 4, false, false));
            FX.sound(l, hand, SoundEvents.WARDEN_SONIC_CHARGE, 1.5F, 0.8F);
        }
        if (a.t < 12) {
            FX.p(l, ParticleTypes.REVERSE_PORTAL, hand, 5, 0.6, 0.08);
            FX.p(l, ParticleTypes.END_ROD, hand, 1, 0.3, 0.02);
        }
        if (a.t == 12) {
            a.origin = p.getEyePosition().add(0, -0.25, 0);
            a.dir = look;
            Network.CH.send(PacketDistributor.NEAR.with(() ->
                    new PacketDistributor.TargetPoint(p.getX(), p.getY(), p.getZ(), 64, l.dimension())), new Network.BWPacket(20));
            FX.sound(l, hand, SoundEvents.WARDEN_SONIC_BOOM, 2F, 0.7F);
            FX.sound(l, hand, SoundEvents.LIGHTNING_BOLT_THUNDER, 2F, 0.6F);
            FX.sound(l, hand, SoundEvents.GENERIC_EXPLODE, 1.5F, 0.6F);
            l.sendParticles(ParticleTypes.FLASH, hand.x, hand.y, hand.z, 1, 0, 0, 0, 0);
            xCut(l, a, 1);
        }
        if (a.t == 15 && a.dir != null) {
            FX.sound(l, hand, SoundEvents.PLAYER_ATTACK_SWEEP, 2F, 0.5F);
            xCut(l, a, 2);
        }
        if (a.t >= 12 && a.t < 20) {
            double s = 6.0 * (a.t - 12), e = s + 6.0;
            Vec3 A = a.origin.add(a.dir.scale(s));
            Vec3 B = a.origin.add(a.dir.scale(e));
            FX.crescent(l, B, a.dir, 4.5, 0.25);
            FX.line(l, A, B, 1.2, ParticleTypes.END_ROD);
            FX.p(l, ParticleTypes.SWEEP_ATTACK, B, 1, 0, 0);
            AABB box = new AABB(A, B).inflate(4);
            for (LivingEntity en : l.getEntitiesOfClass(LivingEntity.class, box, x -> Util.valid(p, x))) {
                if (a.hit.contains(en.getId())) continue;
                if (Util.distToSegment(Util.center(en), A, B) <= 3.5) {
                    a.hit.add(en.getId());
                    Util.hit(p, en, 30F, 1.5F);
                    en.setDeltaMovement(en.getDeltaMovement().add(0, 0.6, 0));
                    en.hurtMarked = true;
                    FX.blade(l, Util.center(en));
                }
            }
            if (a.t == 19) {
                FX.p(l, ParticleTypes.EXPLOSION, B, 3, 1.5, 0);
                FX.sound(l, B, SoundEvents.GENERIC_EXPLODE, 2F, 0.5F);
            }
        }
        if (a.t == 20) {
            Vec3 end = a.origin.add(a.dir.scale(48));
            FX.ribbon(l, FX.straight(a.origin, end, 24), 0.5F, 28, 6, 1, 0);
            for (int d = 6; d < 48; d += 6) {
                Vec3 pt = a.origin.add(a.dir.scale(d));
                FX.ribbon(l, FX.straight(pt.add(0, -1.6, 0), pt.add(0, 1.6, 0), 6), 0.2F, 24, 3, 0, d / 12);
            }
        }
        if (a.t >= 20 && a.t < 46 && a.t % 6 == 0) {
            Vec3 end = a.origin.add(a.dir.scale(48));
            AABB box = new AABB(a.origin, end).inflate(3);
            for (LivingEntity en : l.getEntitiesOfClass(LivingEntity.class, box, x -> Util.valid(p, x))) {
                if (Util.distToSegment(Util.center(en), a.origin, end) <= 2.5) Util.hit(p, en, 4F, 0F);
            }
        }
        return a.t >= 46;
    }

    /** Big glowing X cuts hanging in the air along the slash direction (which: 1 = first diagonal, 2 = second). */
    private static void xCut(ServerLevel l, Active a, int which) {
        Vec3 right = Util.right(a.dir);
        Vec3 up = right.cross(a.dir).normalize();
        double[] dist = {5, 12, 22, 34};
        double[] size = {2.6, 4.2, 6.2, 8.5};
        double sg = which == 1 ? 1 : -1;
        for (int i = 0; i < dist.length; i++) {
            Vec3 c = a.origin.add(a.dir.scale(dist[i]));
            double s = size[i];
            Vec3 p1 = c.add(right.scale(-s)).add(up.scale(-s * 0.8 * sg));
            Vec3 p2 = c.add(right.scale(s)).add(up.scale(s * 0.8 * sg));
            FX.ribbon(l, FX.straight(p1, p2, 14), 0.9F, 16, 3, 0, i * 2);
            FX.ribbon(l, FX.straight(p1, p2, 14), 0.3F, 16, 3, 1, i * 2);
            FX.p(l, ParticleTypes.END_ROD, c, 5, 0.5, 0.1);
        }
    }
}
