package com.chainblades;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

/** Skills: 0 = Z Blade Storm, 1 = X Shadow Step, 2 = C Dimension Cut. */
@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID)
public class SkillManager {
    private static class Active {
        final ServerPlayer p;
        final int id;
        int t = 0;
        int hits = 0;
        LivingEntity target;
        Vec3 last, origin, dir;
        final Set<Integer> hit = new HashSet<>();
        Active(ServerPlayer p, int id) { this.p = p; this.id = id; }
    }

    private static final Map<UUID, Active> ACTIVE = new HashMap<>();
    private static final Map<UUID, long[]> CD = new HashMap<>();
    private static final int[] COOLDOWN = {300, 220, 500};
    private static final Random RNG = new Random();

    public static boolean isBusy(ServerPlayer p) { return ACTIVE.containsKey(p.getUUID()); }

    public static void start(ServerPlayer p, int id) {
        if (id < 0 || id > 2) return;
        if (!(p.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (ACTIVE.containsKey(p.getUUID())) return;
        long now = p.level().getGameTime();
        long[] cd = CD.computeIfAbsent(p.getUUID(), k -> new long[3]);
        if (now < cd[id]) {
            p.displayClientMessage(Component.literal("Перезарядка: " + ((cd[id] - now) / 20 + 1) + " с"), true);
            return;
        }
        Active a = new Active(p, id);
        if (id == 1) {
            a.target = Util.findTarget(p, 20);
            if (a.target == null) {
                p.displayClientMessage(Component.literal("Немає цілі поблизу"), true);
                return;
            }
        }
        cd[id] = now + COOLDOWN[id];
        ACTIVE.put(p.getUUID(), a);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || ACTIVE.isEmpty()) return;
        Iterator<Active> it = ACTIVE.values().iterator();
        while (it.hasNext()) {
            Active a = it.next();
            if (a.p.isRemoved() || !a.p.isAlive()) { it.remove(); continue; }
            boolean done;
            try {
                done = switch (a.id) {
                    case 0 -> tickStorm(a);
                    case 1 -> tickShadow(a);
                    default -> tickCut(a);
                };
            } catch (Exception ex) {
                ex.printStackTrace();
                done = true;
            }
            a.t++;
            if (done) it.remove();
        }
    }

    // ---------- Z: Blade Storm (radius 7, 2 seconds of non-stop chain strikes) ----------
    private static boolean tickStorm(Active a) {
        ServerPlayer p = a.p;
        ServerLevel l = p.serverLevel();
        Vec3 c = p.position().add(0, 1.0, 0);
        if (a.t == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 45, 2, false, false));
            FX.sound(l, c, SoundEvents.WITHER_SHOOT, 1.2F, 0.6F);
        }
        if (a.t % 2 == 0) {
            List<LivingEntity> list = Util.around(p, 7);
            for (LivingEntity e : list) Util.hit(p, e, 3.5F, 0.15F);
            for (int k = 0; k < 5; k++) {
                double ang = a.t * 0.9 + k * 1.256;
                Vec3 hand = c.add(Math.cos(ang) * 0.5, 0.3, Math.sin(ang) * 0.5);
                Vec3 end;
                if (!list.isEmpty() && RNG.nextInt(10) < 7) {
                    end = Util.center(list.get(RNG.nextInt(list.size())));
                } else {
                    double ra = RNG.nextDouble() * Math.PI * 2;
                    double d = 3 + RNG.nextDouble() * 4;
                    end = c.add(Math.cos(ra) * d, RNG.nextDouble() * 2 - 0.8, Math.sin(ra) * d);
                }
                FX.chain(l, hand, end);
            }
            FX.ring(l, p.position().add(0, 0.2, 0), 1 + (a.t % 10) * 0.65, 28, FX.PURPLE);
            if (a.t % 4 == 0) {
                FX.sound(l, c, SoundEvents.PLAYER_ATTACK_SWEEP, 1F, 0.6F + RNG.nextFloat() * 0.5F);
                FX.sound(l, c, SoundEvents.CHAIN_HIT, 1F, 0.7F);
            }
        }
        if (a.t == 40) {
            for (LivingEntity e : Util.around(p, 7)) {
                Util.hit(p, e, 10F, 1.6F);
                e.setDeltaMovement(e.getDeltaMovement().add(0, 0.5, 0));
                e.hurtMarked = true;
            }
            for (int i = 1; i <= 7; i++) FX.ring(l, p.position().add(0, 0.2, 0), i, 40, i % 2 == 0 ? FX.BLACK : FX.PURPLE);
            l.sendParticles(ParticleTypes.EXPLOSION, c.x, c.y, c.z, 4, 2.5, 0.5, 2.5, 0);
            FX.sound(l, c, SoundEvents.GENERIC_EXPLODE, 1F, 1.2F);
        }
        return a.t >= 40;
    }

    // ---------- X: Shadow Step (vanish, 7 lightning strikes, only black streaks are visible) ----------
    private static boolean tickShadow(Active a) {
        ServerPlayer p = a.p;
        ServerLevel l = p.serverLevel();
        if (a.t == 0) {
            a.last = p.position();
            p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 40, 0, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 45, 4, false, false));
            FX.p(l, ParticleTypes.LARGE_SMOKE, p.position().add(0, 1, 0), 25, 0.4, 0.05);
            FX.p(l, ParticleTypes.REVERSE_PORTAL, p.position().add(0, 1, 0), 30, 0.5, 0.2);
            FX.sound(l, p.position(), SoundEvents.ENDERMAN_TELEPORT, 1F, 0.5F);
        }
        if (a.t >= 2 && (a.t - 2) % 3 == 0 && a.hits < 7) {
            if (a.target == null || !a.target.isAlive()) a.target = Util.findTarget(p, 12);
            if (a.target == null) return true;
            LivingEntity tg = a.target;
            double ang = RNG.nextDouble() * Math.PI * 2;
            double cx = Math.cos(ang), cz = Math.sin(ang);
            Vec3 np = tg.position().add(cx * 2.2, 0, cz * 2.2);
            Vec3 through = tg.position().add(-cx * 2.2, 0, -cz * 2.2);
            FX.streak(l, a.last.add(0, 1, 0), np.add(0, 1, 0));
            float yaw = (float) Math.toDegrees(Math.atan2(cx, -cz));
            p.teleportTo(l, np.x, np.y, np.z, yaw, 0F);
            FX.streak(l, np.add(0, 1, 0), through.add(0, 1, 0));
            Vec3 tc = Util.center(tg);
            FX.blade(l, tc);
            float dmg = a.hits == 6 ? 14F : 6.5F;
            Util.hit(p, tg, dmg, a.hits == 6 ? 1.5F : 0.2F);
            FX.sound(l, tc, SoundEvents.PLAYER_ATTACK_SWEEP, 1.2F, 1.4F);
            FX.sound(l, tc, SoundEvents.PLAYER_ATTACK_CRIT, 1F, 0.8F);
            a.last = np;
            a.hits++;
            if (a.hits >= 7) {
                p.removeEffect(MobEffects.INVISIBILITY);
                FX.p(l, ParticleTypes.LARGE_SMOKE, p.position().add(0, 1, 0), 20, 0.4, 0.05);
                FX.p(l, ParticleTypes.END_ROD, tc, 20, 0.6, 0.2);
                return true;
            }
        }
        return a.t > 40;
    }

    // ---------- C: Dimension Cut (charge, huge long-range slash, B&W screen for 2 seconds) ----------
    private static boolean tickCut(Active a) {
        ServerPlayer p = a.p;
        ServerLevel l = p.serverLevel();
        Vec3 look = p.getLookAngle();
        Vec3 hand = p.getEyePosition().add(look.scale(0.6)).add(0, -0.5, 0);
        if (a.t == 0) {
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 14, 9, false, false));
            p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 70, 4, false, false));
            FX.sound(l, hand, SoundEvents.WARDEN_SONIC_CHARGE, 1.5F, 0.8F);
        }
        if (a.t < 12) {
            FX.p(l, ParticleTypes.REVERSE_PORTAL, hand, 8, 0.7, 0.08);
            FX.p(l, FX.PURPLE, hand, 6, 0.5, 0);
            FX.line(l, hand, hand.add(look.scale(a.t * 4.0)), 0.6, FX.PURPLE, FX.BLACK);
        }
        if (a.t == 12) {
            a.origin = p.getEyePosition().add(0, -0.25, 0);
            a.dir = look;
            Network.CH.send(PacketDistributor.NEAR.with(() ->
                    new PacketDistributor.TargetPoint(p.getX(), p.getY(), p.getZ(), 64, l.dimension())), new Network.BWPacket(40));
            FX.sound(l, hand, SoundEvents.WARDEN_SONIC_BOOM, 2F, 0.7F);
            FX.sound(l, hand, SoundEvents.LIGHTNING_BOLT_THUNDER, 2F, 0.6F);
            FX.sound(l, hand, SoundEvents.GENERIC_EXPLODE, 1.5F, 0.6F);
            l.sendParticles(ParticleTypes.FLASH, hand.x, hand.y, hand.z, 1, 0, 0, 0, 0);
        }
        if (a.t >= 12 && a.t < 20) {
            double s = 6.0 * (a.t - 12), e = s + 6.0;
            Vec3 A = a.origin.add(a.dir.scale(s));
            Vec3 B = a.origin.add(a.dir.scale(e));
            FX.crescent(l, B, a.dir, 4.5, 0.25);
            FX.crescent(l, B, a.dir, 3.0, -0.25);
            FX.line(l, A, B, 0.4, ParticleTypes.END_ROD, FX.BLACK);
            FX.p(l, ParticleTypes.SWEEP_ATTACK, B, 1, 0, 0);
            AABB box = new AABB(A, B).inflate(4);
            for (LivingEntity en : l.getEntitiesOfClass(LivingEntity.class, box, x -> Util.valid(p, x))) {
                if (a.hit.contains(en.getId())) continue;
                if (Util.distToSegment(Util.center(en), A, B) <= 3.5) {
                    a.hit.add(en.getId());
                    Util.hit(p, en, 30F, 1.5F);
                    en.setDeltaMovement(en.getDeltaMovement().add(0, 0.6, 0));
                    en.hurtMarked = true;
                    FX.blade(l, Util.center(en));
                }
            }
            if (a.t == 19) {
                FX.p(l, ParticleTypes.EXPLOSION, B, 3, 1.5, 0);
                FX.sound(l, B, SoundEvents.GENERIC_EXPLODE, 2F, 0.5F);
            }
        }
        if (a.t >= 20 && a.t < 46) {
            Vec3 end = a.origin.add(a.dir.scale(48));
            if (a.t % 2 == 0) {
                FX.line(l, a.origin, end, 0.5, ParticleTypes.END_ROD, FX.BLACK, FX.PURPLE);
                for (int d = 4; d < 48; d += 4) {
                    Vec3 pt = a.origin.add(a.dir.scale(d));
                    FX.line(l, pt.add(0, -1.5, 0), pt.add(0, 1.5, 0), 0.5, FX.BLACK, FX.PURPLE);
                }
            }
            if (a.t % 6 == 0) {
                AABB box = new AABB(a.origin, end).inflate(3);
                for (LivingEntity en : l.getEntitiesOfClass(LivingEntity.class, box, x -> Util.valid(p, x))) {
                    if (Util.distToSegment(Util.center(en), a.origin, end) <= 2.5) Util.hit(p, en, 4F, 0F);
                }
            }
        }
        return a.t >= 46;
    }
}
