package com.chainblades.client;

import com.chainblades.Anim;
import com.chainblades.ChainBladesItem;
import com.chainblades.ChainBladesMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

/**
 * Draws the off-hand handle, and for BOTH hands a real 3D chain (curved, sagging when loose, straight when taut)
 * with a blade at its end. Also feeds blade positions to the slash-trail renderer.
 */
public class ChainBladesLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation TEX = new ResourceLocation(ChainBladesMod.MODID, "textures/item/chain_blades.png");
    /** Distance along the forearm from the shoulder pivot to where the chain leaves the handle. Tweak if the chain starts off the handle. */
    private static final float HANDLE_Y = 0.95F;
    private final float[] v = new float[Anim.N];

    public ChainBladesLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer pl, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        ItemStack stack = pl.getMainHandItem();
        if (!(stack.getItem() instanceof ChainBladesItem) || pl.isInvisible()) return;

        // off-hand handle
        HumanoidArm off = pl.getMainArm().getOpposite();
        boolean left = off == HumanoidArm.LEFT;
        ps.pushPose();
        this.getParentModel().translateToHand(off, ps);
        ps.mulPose(Axis.XP.rotationDegrees(-90F));
        ps.mulPose(Axis.YP.rotationDegrees(180F));
        ps.translate((left ? -1 : 1) / 16.0F, 0.125F, -0.625F);
        Minecraft.getInstance().getItemRenderer().renderStatic(pl, stack,
                left ? ItemDisplayContext.THIRD_PERSON_LEFT_HAND : ItemDisplayContext.THIRD_PERSON_RIGHT_HAND,
                left, ps, buf, pl.level(), light, OverlayTexture.NO_OVERLAY, pl.getId());
        ps.popPose();

        boolean active = ClientAnim.sample(pl.getId(), v);
        PlayerModel<AbstractClientPlayer> m = this.getParentModel();
        drawChain(ps, buf, light, m.rightArm, HumanoidArm.RIGHT, v[Anim.RLEN], v[Anim.RTEN], pl.getId() * 2L, active);
        drawChain(ps, buf, light, m.leftArm, HumanoidArm.LEFT, v[Anim.LLEN], v[Anim.LTEN], pl.getId() * 2L + 1, active);
    }

    private void drawChain(PoseStack ps, MultiBufferSource buf, int light, ModelPart armPart, HumanoidArm arm,
                           float len, float ten, long key, boolean active) {
        ps.pushPose();
        this.getParentModel().translateToHand(arm, ps);

        // gravity ("down" in model space is +y) expressed in the arm's local frame
        Quaternionf q = new Quaternionf().rotationZYX(armPart.zRot, armPart.yRot, armPart.xRot);
        Vector3f g = new Vector3f(0, 1, 0);
        new Quaternionf(q).invert().transform(g);

        Vector3f p0 = new Vector3f(0, HANDLE_Y, 0);
        float reach = len * (0.35F + 0.65F * ten);
        float sagTip = (1F - ten) * len * 0.35F;
        Vector3f p2 = new Vector3f(0, HANDLE_Y + reach, 0).add(new Vector3f(g).mul(sagTip));
        float sag = (1F - ten) * len * 0.5F;
        Vector3f p1 = new Vector3f(p0).add(p2).mul(0.5F).add(new Vector3f(g).mul(sag));

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        float chainLen = p0.distance(p1) + p1.distance(p2);
        int n = Math.max(2, Math.min(70, (int) (chainLen / 0.14F)));
        for (int i = 0; i < n; i++) {
            float t = (i + 0.5F) / n;
            Vector3f pos = bez(p0, p1, p2, t);
            Vector3f tg = tangent(p0, p1, p2, t);
            ps.pushPose();
            ps.translate(pos.x, pos.y, pos.z);
            ps.mulPose(new Quaternionf().rotationTo(0, 0, 1, tg.x, tg.y, tg.z));
            if ((i & 1) == 1) ps.mulPose(Axis.ZP.rotationDegrees(90F));
            box(vc, ps.last(), light, -0.045F, -0.014F, -0.085F, 0.045F, 0.014F, 0.085F, 0F, 0.5F, 0.5F, 1F);
            ps.popPose();
        }

        // blade at the end of the chain, pointing along the chain's last segment
        Vector3f tg = tangent(p0, p1, p2, 1F);
        ps.pushPose();
        ps.translate(p2.x, p2.y, p2.z);
        ps.mulPose(new Quaternionf().rotationTo(0, 0, 1, tg.x, tg.y, tg.z));
        PoseStack.Pose pose = ps.last();
        int glow = LightTexture.FULL_BRIGHT;
        box(vc, pose, light, -0.075F, -0.02F, -0.01F, 0.075F, 0.02F, 0.04F, 0.5F, 0.5F, 1F, 1F);           // guard
        box(vc, pose, light, -0.04F, -0.012F, 0.04F, 0.04F, 0.012F, 0.36F, 0F, 0F, 0.5F, 0.5F);            // blade
        quad(vc, pose, light, -0.04F, 0.012F, 0.36F, 0.04F, 0.012F, 0.36F, 0F, 0.003F, 0.58F, 0F, 0.003F, 0.58F, 0F, 0F, 0.5F, 0.5F, 0, 1, 0.3F);
        quad(vc, pose, light, -0.04F, -0.012F, 0.36F, 0.04F, -0.012F, 0.36F, 0F, -0.003F, 0.58F, 0F, -0.003F, 0.58F, 0F, 0F, 0.5F, 0.5F, 0, -1, 0.3F);
        quad(vc, pose, light, -0.04F, -0.012F, 0.36F, -0.04F, 0.012F, 0.36F, 0F, 0F, 0.58F, 0F, 0F, 0.58F, 0F, 0F, 0.5F, 0.5F, -1, 0, 0.3F);
        quad(vc, pose, light, 0.04F, -0.012F, 0.36F, 0.04F, 0.012F, 0.36F, 0F, 0F, 0.58F, 0F, 0F, 0.58F, 0F, 0F, 0.5F, 0.5F, 1, 0, 0.3F);
        box(vc, pose, glow, -0.012F, -0.016F, 0.05F, 0.012F, 0.016F, 0.42F, 0.5F, 0F, 1F, 0.5F);          // glowing edge
        box(vc, pose, glow, -0.07F, -0.008F, 0.08F, 0.07F, 0.008F, 0.12F, 0.5F, 0F, 1F, 0.5F);            // barbs

        if (active || len > 1.5F) {
            Vec3 tip = toWorld(pose, new Vector3f(0, 0, 0.6F));
            Vec3 base = toWorld(pose, new Vector3f(0, 0, 0.05F));
            ClientTrails.add(key, tip, base);
        }
        ps.popPose();
        ps.popPose();
    }

    private static Vec3 toWorld(PoseStack.Pose pose, Vector3f p) {
        Vector4f e = new Vector4f(p.x, p.y, p.z, 1F);
        e.mul(pose.pose());
        Vector3f w = new Vector3f(e.x, e.y, e.z);
        var cam = Minecraft.getInstance().gameRenderer.getMainCamera();
        w.rotate(cam.rotation());
        Vec3 cp = cam.getPosition();
        return new Vec3(cp.x + w.x, cp.y + w.y, cp.z + w.z);
    }

    private static Vector3f bez(Vector3f a, Vector3f b, Vector3f c, float t) {
        float u = 1F - t;
        return new Vector3f(
                u * u * a.x + 2 * u * t * b.x + t * t * c.x,
                u * u * a.y + 2 * u * t * b.y + t * t * c.y,
                u * u * a.z + 2 * u * t * b.z + t * t * c.z);
    }

    private static Vector3f tangent(Vector3f a, Vector3f b, Vector3f c, float t) {
        Vector3f d = new Vector3f(
                2 * (1 - t) * (b.x - a.x) + 2 * t * (c.x - b.x),
                2 * (1 - t) * (b.y - a.y) + 2 * t * (c.y - b.y),
                2 * (1 - t) * (b.z - a.z) + 2 * t * (c.z - b.z));
        if (d.lengthSquared() < 1.0E-6F) return new Vector3f(0, 1, 0);
        return d.normalize();
    }

    private static void box(VertexConsumer vc, PoseStack.Pose pose, int light, float x0, float y0, float z0,
                            float x1, float y1, float z1, float u0, float v0, float u1, float v1) {
        quad(vc, pose, light, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, u0, v0, u1, v1, 0, 0, 1);
        quad(vc, pose, light, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, u0, v0, u1, v1, 0, 0, -1);
        quad(vc, pose, light, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, u0, v0, u1, v1, 1, 0, 0);
        quad(vc, pose, light, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, u0, v0, u1, v1, -1, 0, 0);
        quad(vc, pose, light, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, u0, v0, u1, v1, 0, 1, 0);
        quad(vc, pose, light, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, u0, v0, u1, v1, 0, -1, 0);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float u0, float v0, float u1, float v1, float nx, float ny, float nz) {
        vtx(vc, pose, light, ax, ay, az, u0, v0, nx, ny, nz);
        vtx(vc, pose, light, bx, by, bz, u1, v0, nx, ny, nz);
        vtx(vc, pose, light, cx, cy, cz, u1, v1, nx, ny, nz);
        vtx(vc, pose, light, dx, dy, dz, u0, v1, nx, ny, nz);
    }

    private static void vtx(VertexConsumer vc, PoseStack.Pose pose, int light, float x, float y, float z,
                            float u, float v, float nx, float ny, float nz) {
        vc.vertex(pose.pose(), x, y, z).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }
}
