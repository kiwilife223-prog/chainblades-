package com.chainblades.client;

import com.chainblades.Anim;
import com.chainblades.ChainBladesItem;
import com.chainblades.ChainBladesMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

/**
 * Draws the off-hand handle, and for BOTH hands a real 3D chain (curved, sagging when loose, straight when taut)
 * with a blade at its end. Also feeds blade positions to the slash-trail renderer.
 */
public class ChainBladesLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation TEX = new ResourceLocation(ChainBladesMod.MODID, "textures/item/chain_blades.png");
    /** Distance along the forearm from the shoulder pivot to where the chain leaves the handle. Tweak if the chain starts off the handle. */
    private static final float HANDLE_Y = 0.95F;
    private final float[] v = new float[Anim.N];

    public ChainBladesLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer pl, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        ItemStack stack = pl.getMainHandItem();
        if (!(stack.getItem() instanceof ChainBladesItem) || pl.isInvisible()) return;

        // off-hand handle
        HumanoidArm off = pl.getMainArm().getOpposite();
        boolean left = off == HumanoidArm.LEFT;
        ps.pushPose();
        this.getParentModel().translateToHand(off, ps);
        ps.mulPose(Axis.XP.rotationDegrees(-90F));
        ps.mulPose(Axis.YP.rotationDegrees(180F));
        ps.translate((left ? -1 : 1) / 16.0F, 0.125F, -0.625F);
        Minecraft.getInstance().getItemRenderer().renderStatic(pl, stack,
                left ? ItemDisplayContext.THIRD_PERSON_LEFT_HAND : ItemDisplayContext.THIRD_PERSON_RIGHT_HAND,
                left, ps, buf, pl.level(), light, OverlayTexture.NO_OVERLAY, pl.getId());
        ps.popPose();

        boolean active = ClientAnim.sample(pl.getId(), v);
        PlayerModel<AbstractClientPlayer> m = this.getParentModel();
        float sway = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount * 0.5F;
        drawChain(ps, buf, light, m.rightArm, HumanoidArm.RIGHT, v[Anim.RLEN], v[Anim.RTEN], pl.getId() * 2L, active, ageInTicks, sway, v[Anim.CAM], v[Anim.CSP]);
        drawChain(ps, buf, light, m.leftArm, HumanoidArm.LEFT, v[Anim.LLEN], v[Anim.LTEN], pl.getId() * 2L + 1, active, ageInTicks, -sway, v[Anim.CAM], v[Anim.CSP] + Mth.PI);
    }

    private void drawChain(PoseStack ps, MultiBufferSource buf, int light, ModelPart armPart, HumanoidArm arm,
                           float len, float ten, long key, boolean active, float swayTime, float sway, float cam, float phase) {
        ps.pushPose();
        this.getParentModel().translateToHand(arm, ps);

        // gravity ("down" in model space is +y) expressed in the arm's local frame
        Quaternionf q = new Quaternionf().rotationZYX(armPart.zRot, armPart.yRot, armPart.xRot);
        Vector3f g = new Vector3f(0, 1, 0);
        new Quaternionf(q).invert().transform(g);
        // chain direction: along the arm, or (idle show) orbiting the hand in a vertical circle
        Vector3f d = new Vector3f(0, 1, 0);
        if (cam > 0.01F) {
            Vector3f ds = new Vector3f(0, Mth.cos(phase), -Mth.sin(phase));
            d.lerp(ds, Math.min(1F, cam)).normalize();
        }

        Vector3f p0 = new Vector3f(0, HANDLE_Y, 0);
        float reach = len * (0.35F + 0.65F * ten);
        float sagTip = (1F - ten) * len * 0.35F;
        Vector3f p2 = new Vector3f(p0).add(new Vector3f(d).mul(reach)).add(new Vector3f(g).mul(sagTip));
        float sag = (1F - ten) * len * 0.5F;
        Vector3f p1 = new Vector3f(p0).add(p2).mul(0.5F).add(new Vector3f(g).mul(sag));
        // loose chains sway with time and walking
        float loose = 1F - ten;
        float sw = (float) Math.sin(swayTime * 0.13F + key) * 0.10F * loose + sway * loose;
        p1.x += sw * len;
        p2.x += sw * len * 0.7F;
        p2.z += (float) Math.cos(swayTime * 0.11F + key) * 0.06F * loose * len;

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        float chainLen = p0.distance(p1) + p1.distance(p2);
        int n = Math.max(2, Math.min(60, (int) (chainLen / 0.24F)));
        for (int i = 0; i < n; i++) {
            float t = (i + 0.5F) / n;
            Vector3f pos = bez(p0, p1, p2, t);
            Vector3f tg = tangent(p0, p1, p2, t);
            ps.pushPose();
            ps.translate(pos.x, pos.y, pos.z);
            ps.mulPose(new Quaternionf().rotationTo(0, 0, 1, tg.x, tg.y, tg.z));
            if ((i & 1) == 1) ps.mulPose(Axis.ZP.rotationDegrees(90F));
            if (i % 2 == 1) box(vc, ps.last(), LightTexture.FULL_BRIGHT, -0.06F, -0.024F, -0.12F, 0.06F, 0.024F, 0.12F, 0.5F, 0F, 1F, 0.5F);
            else box(vc, ps.last(), light, -0.085F, -0.028F, -0.14F, 0.085F, 0.028F, 0.14F, 0F, 0.5F, 0.5F, 1F);
            ps.popPose();
        }

        // blade at the end of the chain, pointing along the chain's last segment
        Vector3f tg = tangent(p0, p1, p2, 1F);
        ps.pushPose();
        ps.translate(p2.x, p2.y, p2.z);
        ps.mulPose(new Quaternionf().rotationTo(0, 0, 1, tg.x, tg.y, tg.z));
        float bs = 0.95F + 0.85F * Math.max(ten, Mth.clamp((len - 0.8F) / 1.5F, 0F, 1F));
        ps.scale(bs, bs, bs);
        PoseStack.Pose pose = ps.last();
        int glow = LightTexture.FULL_BRIGHT;
        // ---- dagger like the concept art: flat ring for the chain, wrapped grip, winged guard with gem, serrated glowing blade
        box(vc, pose, light, -0.08F, -0.02F, -0.07F, 0.08F, 0.02F, -0.04F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, -0.08F, -0.02F, 0.04F, 0.08F, 0.02F, 0.07F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, -0.08F, -0.02F, -0.07F, -0.05F, 0.02F, 0.07F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, 0.05F, -0.02F, -0.07F, 0.08F, 0.02F, 0.07F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, -0.026F, -0.026F, 0.07F, 0.026F, 0.026F, 0.32F, 0.5F, 0.5F, 1F, 1F);          // grip
        for (int b = 0; b < 4; b++) {                                                                       // purple wraps
            float z0 = 0.10F + b * 0.065F;
            box(vc, pose, glow, -0.031F, -0.031F, z0, 0.031F, 0.031F, z0 + 0.028F, 0.5F, 0F, 1F, 0.5F);
        }
        box(vc, pose, light, -0.12F, -0.032F, 0.32F, 0.12F, 0.032F, 0.38F, 0F, 0.5F, 0.5F, 1F);            // guard
        box(vc, pose, glow, -0.15F, -0.02F, 0.30F, -0.12F, 0.02F, 0.36F, 0.5F, 0F, 1F, 0.5F);              // swept wings
        box(vc, pose, glow, 0.12F, -0.02F, 0.30F, 0.15F, 0.02F, 0.36F, 0.5F, 0F, 1F, 0.5F);
        box(vc, pose, glow, -0.13F, -0.02F, 0.38F, -0.10F, 0.02F, 0.44F, 0.5F, 0F, 1F, 0.5F);
        box(vc, pose, glow, 0.10F, -0.02F, 0.38F, 0.13F, 0.02F, 0.44F, 0.5F, 0F, 1F, 0.5F);
        box(vc, pose, glow, -0.024F, -0.045F, 0.325F, 0.024F, 0.045F, 0.375F, 0.5F, 0F, 1F, 0.5F);          // gem
        float[][] seg = {{0.38F, 0.52F, 0.07F}, {0.52F, 0.68F, 0.062F}, {0.68F, 0.82F, 0.048F}, {0.82F, 0.92F, 0.03F}};
        for (float[] s : seg) box(vc, pose, light, -s[2], -0.014F, s[0], s[2], 0.014F, s[1], 0F, 0F, 0.5F, 0.5F);
        box(vc, pose, light, -0.013F, -0.022F, 0.38F, 0.013F, 0.022F, 0.93F, 0F, 0F, 0.5F, 0.5F);          // ridge
        for (int i = 0; i < 6; i++) {                                                                       // serrated glowing edges
            float z0 = 0.40F + i * 0.085F;
            float wd = 0.07F - i * 0.007F;
            float tooth = 0.032F - i * 0.0035F;
            box(vc, pose, glow, -wd - tooth, -0.012F, z0, -wd + 0.012F, 0.012F, z0 + 0.05F, 0.5F, 0F, 1F, 0.5F);
            box(vc, pose, glow, wd - 0.012F, -0.012F, z0, wd + tooth, 0.012F, z0 + 0.05F, 0.5F, 0F, 1F, 0.5F);
        }
        quad(vc, pose, glow, -0.03F, 0.014F, 0.92F, 0.03F, 0.014F, 0.92F, 0F, 0.003F, 1.04F, 0F, 0.003F, 1.04F, 0.5F, 0F, 1F, 0.5F, 0, 1, 0.3F);
        quad(vc, pose, glow, -0.03F, -0.014F, 0.92F, 0.03F, -0.014F, 0.92F, 0F, -0.003F, 1.04F, 0F, -0.003F, 1.04F, 0.5F, 0F, 1F, 0.5F, 0, -1, 0.3F);
        quad(vc, pose, glow, -0.03F, -0.014F, 0.92F, -0.03F, 0.014F, 0.92F, 0F, 0F, 1.04F, 0F, 0F, 1.04F, 0.5F, 0F, 1F, 0.5F, -1, 0, 0.3F);
        quad(vc, pose, glow, 0.03F, -0.014F, 0.92F, 0.03F, 0.014F, 0.92F, 0F, 0F, 1.04F, 0F, 0F, 1.04F, 0.5F, 0F, 1F, 0.5F, 1, 0, 0.3F);

        if (active || len > 1.5F) {
            Vec3 tip = toWorld(pose, new Vector3f(0, 0, 1.04F));
            Vec3 base = toWorld(pose, new Vector3f(0, 0, 0.38F));
            ClientTrails.add(key, tip, base);
        }
        // violet aura around the blades
        var lvl = Minecraft.getInstance().level;
        if (lvl != null && Math.random() < (active ? 0.5 : 0.12)) {
            Vec3 pp = toWorld(pose, new Vector3f(0, 0, 0.6F));
            lvl.addParticle(net.minecraft.core.particles.ParticleTypes.REVERSE_PORTAL, pp.x, pp.y, pp.z, 0, 0.03, 0);
        }
        ps.popPose();
        ps.popPose();
    }

    private static Vec3 toWorld(PoseStack.Pose pose, Vector3f p) {
        Vector4f e = new Vector4f(p.x, p.y, p.z, 1F);
        e.mul(pose.pose());
        Vector3f w = new Vector3f(e.x, e.y, e.z);
        var cam = Minecraft.getInstance().gameRenderer.getMainCamera();
        w.rotate(cam.rotation());
        Vec3 cp = cam.getPosition();
        return new Vec3(cp.x + w.x, cp.y + w.y, cp.z + w.z);
    }

    private static Vector3f bez(Vector3f a, Vector3f b, Vector3f c, float t) {
        float u = 1F - t;
        return new Vector3f(
                u * u * a.x + 2 * u * t * b.x + t * t * c.x,
                u * u * a.y + 2 * u * t * b.y + t * t * c.y,
                u * u * a.z + 2 * u * t * b.z + t * t * c.z);
    }

    private static Vector3f tangent(Vector3f a, Vector3f b, Vector3f c, float t) {
        Vector3f d = new Vector3f(
                2 * (1 - t) * (b.x - a.x) + 2 * t * (c.x - b.x),
                2 * (1 - t) * (b.y - a.y) + 2 * t * (c.y - b.y),
                2 * (1 - t) * (b.z - a.z) + 2 * t * (c.z - b.z));
        if (d.lengthSquared() < 1.0E-6F) return new Vector3f(0, 1, 0);
        return d.normalize();
    }

    private static void box(VertexConsumer vc, PoseStack.Pose pose, int light, float x0, float y0, float z0,
                            float x1, float y1, float z1, float u0, float v0, float u1, float v1) {
        quad(vc, pose, light, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, u0, v0, u1, v1, 0, 0, 1);
        quad(vc, pose, light, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, u0, v0, u1, v1, 0, 0, -1);
        quad(vc, pose, light, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, u0, v0, u1, v1, 1, 0, 0);
        quad(vc, pose, light, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, u0, v0, u1, v1, -1, 0, 0);
        quad(vc, pose, light, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, u0, v0, u1, v1, 0, 1, 0);
        quad(vc, pose, light, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, u0, v0, u1, v1, 0, -1, 0);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float u0, float v0, float u1, float v1, float nx, float ny, float nz) {
        vtx(vc, pose, light, ax, ay, az, u0, v0, nx, ny, nz);
        vtx(vc, pose, light, bx, by, bz, u1, v0, nx, ny, nz);
        vtx(vc, pose, light, cx, cy, cz, u1, v1, nx, ny, nz);
        vtx(vc, pose, light, dx, dy, dz, u0, v1, nx, ny, nz);
    }

    private static void vtx(VertexConsumer vc, PoseStack.Pose pose, int light, float x, float y, float z,
                            float u, float v, float nx, float ny, float nz) {
        vc.vertex(pose.pose(), x, y, z).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }
}
