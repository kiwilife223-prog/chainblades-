package com.chainblades.client;

import com.chainblades.Anim;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;

/** Two-handed grip pose + animated arm/body/leg rotations. */
public class ClientPose {
    public static final HumanoidModel.ArmPose POSE =
            HumanoidModel.ArmPose.create("CHAIN_BLADES", true, ClientPose::transform);

    private static final float[] V = new float[Anim.N];

    public static void transform(HumanoidModel<?> m, LivingEntity entity, HumanoidArm arm) {
        if (arm != entity.getMainArm()) return;
        float[] v = V;
        ClientAnim.sample(entity.getId(), v);
        float by = v[Anim.BY];
        float c = Mth.cos(by), s = Mth.sin(by);

        m.body.yRot = by;
        m.body.xRot = v[Anim.BX];

        // shoulders follow the torso twist
        m.rightArm.x = -5F * c;
        m.rightArm.z = 5F * s;
        m.leftArm.x = 5F * c;
        m.leftArm.z = -5F * s;

        m.rightArm.xRot = v[Anim.RAX];
        m.rightArm.yRot = v[Anim.RAY] + by;
        m.rightArm.zRot = v[Anim.RAZ];
        m.leftArm.xRot = v[Anim.LAX];
        m.leftArm.yRot = v[Anim.LAY] + by;
        m.leftArm.zRot = v[Anim.LAZ];

        // legs: additive on top of the vanilla walk cycle (stance, lunge steps)
        m.rightLeg.xRot += v[Anim.RLX];
        m.leftLeg.xRot += v[Anim.LLX];
        m.rightLeg.yRot += v[Anim.RLY];
        m.leftLeg.yRot += v[Anim.LLY];
    }
}
