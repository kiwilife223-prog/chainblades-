package com.chainblades.client;

import com.chainblades.Anim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;

/** Combat stance (relaxed, staggered feet, breathing), natural walk/run, and animated arm/body/leg rotations. */
public class ClientPose {
    public static final HumanoidModel.ArmPose POSE =
            HumanoidModel.ArmPose.create("CHAIN_BLADES", true, ClientPose::transform);

    private static final float[] V = new float[Anim.N];

    public static void transform(HumanoidModel<?> m, LivingEntity entity, HumanoidArm arm) {
        if (arm != entity.getMainArm()) return;
        float[] v = V;
        boolean act = ClientAnim.sample(entity.getId(), v);
        float t = entity.tickCount + Minecraft.getInstance().getFrameTime();
        float breath = Mth.sin(t * 0.09F);
        float by = v[Anim.BY];
        float rSwing = m.rightArm.xRot, lSwing = m.leftArm.xRot; // vanilla walk swing
        // 0 = standing, 1 = full run (derived from the vanilla arm swing amplitude)
        float spd = Math.min(1F, (Math.abs(rSwing) + Math.abs(lSwing)) * 0.7F);

        if (!act) {
            float stance = 1F - spd;
            // arms: ready stance when still, bent and pumping when running
            m.rightArm.xRot = rSwing * 0.85F + v[Anim.RAX] * stance - 0.65F * spd;
            m.rightArm.yRot = v[Anim.RAY] * stance - 0.28F * spd;
            m.rightArm.zRot = v[Anim.RAZ] * stance + 0.08F * spd + breath * 0.03F;
            m.leftArm.xRot = lSwing * 0.85F + v[Anim.LAX] * stance - 0.65F * spd;
            m.leftArm.yRot = v[Anim.LAY] * stance + 0.28F * spd;
            m.leftArm.zRot = v[Anim.LAZ] * stance - 0.08F * spd - breath * 0.03F;
            // torso: breathing, forward lean and counter-twist while running
            m.body.xRot += breath * 0.015F + 0.2F * spd;
            m.body.yRot = (lSwing - rSwing) * 0.12F;
            m.head.xRot -= 0.12F * spd;
            // staggered stance only while standing; walk cycle takes over when moving
            m.rightLeg.xRot += v[Anim.RLX] * stance;
            m.leftLeg.xRot += v[Anim.LLX] * stance;
            return;
        }

        float c = Mth.cos(by), s = Mth.sin(by);
        m.body.yRot = by;
        m.body.xRot = v[Anim.BX];
        // shoulders follow the torso twist
        m.rightArm.x = -5F * c;
        m.rightArm.z = 5F * s;
        m.leftArm.x = 5F * c;
        m.leftArm.z = -5F * s;

        m.rightArm.xRot = v[Anim.RAX] + rSwing * 0.2F;
        m.rightArm.yRot = v[Anim.RAY] + by;
        m.rightArm.zRot = v[Anim.RAZ];
        m.leftArm.xRot = v[Anim.LAX] + lSwing * 0.2F;
        m.leftArm.yRot = v[Anim.LAY] + by;
        m.leftArm.zRot = v[Anim.LAZ];

        // legs: additive on top of the vanilla walk cycle (stance, lunge steps, tuck in the air)
        m.rightLeg.xRot += v[Anim.RLX];
        m.leftLeg.xRot += v[Anim.LLX];
        m.rightLeg.yRot += v[Anim.RLY];
        m.leftLeg.yRot += v[Anim.LLY];
    }
}
