package com.chainblades.client;

import com.chainblades.ChainBladesMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientModEvents {
    public static final KeyMapping Z = key("key.chainblades.skill_z", GLFW.GLFW_KEY_Z);
    public static final KeyMapping X = key("key.chainblades.skill_x", GLFW.GLFW_KEY_X);
    public static final KeyMapping C = key("key.chainblades.skill_c", GLFW.GLFW_KEY_C);

    private static KeyMapping key(String name, int code) {
        return new KeyMapping(name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, code, "key.categories.chainblades");
    }

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(Z);
        e.register(X);
        e.register(C);
    }

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers e) {
        for (String skin : e.getSkins()) {
            PlayerRenderer renderer = e.getSkin(skin);
            if (renderer != null) renderer.addLayer(new SecondBladeLayer(renderer));
        }
    }
}
