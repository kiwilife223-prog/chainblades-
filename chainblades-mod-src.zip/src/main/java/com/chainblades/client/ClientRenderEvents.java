package com.chainblades.client;

import com.chainblades.Anim;
import com.chainblades.ChainBladesItem;
import com.chainblades.ChainBladesMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraft.client.gui.GuiGraphics;
import com.chainblades.ClientState;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID, value = Dist.CLIENT)
public class ClientRenderEvents {
    private static final float[] V = new float[Anim.N];
    private static final Random RNG = new Random();

    /** Whole-body motion: lunge forward, lean, spin. */
    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre e) {
        Player p = e.getEntity();
        if (!(p.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (!ClientAnim.sample(p.getId(), V)) return;
        float lean = V[Anim.LEAN], mv = V[Anim.MV], spin = V[Anim.SPIN], jump = V[Anim.JUMP];
        PoseStack ps = e.getPoseStack();
        float yaw = Mth.rotLerp(e.getPartialTick(), p.yBodyRotO, p.yBodyRot);
        double r = Math.toRadians(yaw);
        if (Math.abs(jump) > 1.0E-3F) ps.translate(0, jump, 0);
        if (Math.abs(mv) > 1.0E-3F) ps.translate(-Math.sin(r) * mv, 0, Math.cos(r) * mv);
        if (Math.abs(lean) > 1.0E-3F) {
            ps.translate(0, 0.9, 0);
            ps.mulPose(Axis.YP.rotationDegrees(-yaw));
            ps.mulPose(Axis.XP.rotation(lean));
            ps.mulPose(Axis.YP.rotationDegrees(yaw));
            ps.translate(0, -0.9, 0);
        }
        if (Math.abs(spin) > 1.0E-3F) ps.mulPose(Axis.YP.rotation(spin));
    }

    /** Simple first-person motion of the held blades. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(mc.player.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (!ClientAnim.sample(mc.player.getId(), V)) return;
        PoseStack ps = e.getPoseStack();
        float dx = (V[Anim.RAY] + 0.25F) * 0.4F;
        float dy = -(V[Anim.RAX] + 0.9F) * 0.22F;
        ps.translate(dx, dy, -V[Anim.MV] * 0.8F);
        ps.mulPose(Axis.ZP.rotation(-(V[Anim.RAY] + 0.25F) * 0.3F));
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        float s = ClientAnim.shakeValue();
        if (s <= 0F) return;
        e.setPitch(e.getPitch() + (RNG.nextFloat() - 0.5F) * 2F * s);
        e.setYaw(e.getYaw() + (RNG.nextFloat() - 0.5F) * 2F * s);
        e.setRoll(e.getRoll() + (RNG.nextFloat() - 0.5F) * 3F * s);
    }

    @SubscribeEvent
    public static void onLevelStage(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES) return;
        ClientTrails.render(e.getPoseStack(), e.getCamera());
        FxRender.render(e.getPoseStack(), e.getCamera());
    }

    /** Cinematic bars + white X slashes over the screen during the Dimension Cut. */
    @SubscribeEvent
    public static void onGui(RenderGuiEvent.Post e) {
        float t = ClientState.age(e.getPartialTick());
        if (t < 0F) return;
        float total = ClientState.total();
        GuiGraphics g = e.getGuiGraphics();
        int w = g.guiWidth(), h = g.guiHeight();
        float in = Math.min(1F, t / 3F), out = Math.min(1F, (total - t) / 5F);
        int bar = (int) (h * 0.11F * Math.max(0F, Math.min(in, out)));
        if (bar > 0) {
            g.fill(0, 0, w, bar, 0xFF000000);
            g.fill(0, h - bar, w, h, 0xFF000000);
        }
        if (t < 8F) {
            float k = Math.min(1F, t / 2.5F);
            int alpha = (int) (255 * (1F - t / 8F));
            int col = (alpha << 24) | 0xFFFFFF;
            int half = (int) (Math.max(w, h) * 0.75F * k);
            for (int sign = -1; sign <= 1; sign += 2) {
                PoseStack ps = g.pose();
                ps.pushPose();
                ps.translate(w / 2F, h / 2F, 0);
                ps.mulPose(Axis.ZP.rotationDegrees(sign * 32F));
                g.fill(-half, -3, half, 3, col);
                ps.popPose();
            }
        }
    }
}
