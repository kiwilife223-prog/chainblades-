package com.chainblades.client;

import com.chainblades.Anim;
import com.chainblades.ChainBladesItem;
import com.chainblades.ChainBladesMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID, value = Dist.CLIENT)
public class ClientRenderEvents {
    private static final float[] V = new float[Anim.N];
    private static final Random RNG = new Random();

    /** Whole-body motion: lunge forward, lean, spin. */
    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre e) {
        Player p = e.getEntity();
        if (!(p.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (!ClientAnim.sample(p.getId(), V)) return;
        float lean = V[Anim.LEAN], mv = V[Anim.MV], spin = V[Anim.SPIN];
        PoseStack ps = e.getPoseStack();
        float yaw = Mth.rotLerp(e.getPartialTick(), p.yBodyRotO, p.yBodyRot);
        double r = Math.toRadians(yaw);
        if (Math.abs(mv) > 1.0E-3F) ps.translate(-Math.sin(r) * mv, 0, Math.cos(r) * mv);
        if (Math.abs(lean) > 1.0E-3F) {
            ps.translate(0, 0.9, 0);
            ps.mulPose(Axis.YP.rotationDegrees(-yaw));
            ps.mulPose(Axis.XP.rotation(lean));
            ps.mulPose(Axis.YP.rotationDegrees(yaw));
            ps.translate(0, -0.9, 0);
        }
        if (Math.abs(spin) > 1.0E-3F) ps.mulPose(Axis.YP.rotation(spin));
    }

    /** Simple first-person motion of the held blades. */
    @SubscribeEvent
    public static void onRenderHand(RenderHandEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(mc.player.getMainHandItem().getItem() instanceof ChainBladesItem)) return;
        if (!ClientAnim.sample(mc.player.getId(), V)) return;
        PoseStack ps = e.getPoseStack();
        float dx = (V[Anim.RAY] + 0.25F) * 0.4F;
        float dy = -(V[Anim.RAX] + 0.9F) * 0.22F;
        ps.translate(dx, dy, -V[Anim.MV] * 0.8F);
        ps.mulPose(Axis.ZP.rotation(-(V[Anim.RAY] + 0.25F) * 0.3F));
    }

    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles e) {
        float s = ClientAnim.shakeValue();
        if (s <= 0F) return;
        e.setPitch(e.getPitch() + (RNG.nextFloat() - 0.5F) * 2F * s);
        e.setYaw(e.getYaw() + (RNG.nextFloat() - 0.5F) * 2F * s);
        e.setRoll(e.getRoll() + (RNG.nextFloat() - 0.5F) * 3F * s);
    }
}
