package com.chainblades.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/** Glowing slash ribbons behind the flying blades (world-space, drawn after particles). */
public class ClientTrails {
    private static class S {
        final Vec3 tip, base;
        final float t;
        S(Vec3 tip, Vec3 base, float t) { this.tip = tip; this.base = base; this.t = t; }
    }

    private static final Map<Long, ArrayDeque<S>> MAP = new HashMap<>();
    private static final float LIFE = 7F;

    public static void add(long key, Vec3 tip, Vec3 base) {
        float now = ClientAnim.now();
        ArrayDeque<S> d = MAP.computeIfAbsent(key, k -> new ArrayDeque<>());
        if (!d.isEmpty() && d.peekLast().t == now) return;
        d.addLast(new S(tip, base, now));
        while (d.size() > 60) d.removeFirst();
    }

    public static void render(PoseStack ps, Camera cam) {
        if (MAP.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        VertexConsumer vc = bs.getBuffer(RenderType.lightning());
        Matrix4f m = ps.last().pose();
        Vec3 cp = cam.getPosition();
        float now = ClientAnim.now();
        Iterator<Map.Entry<Long, ArrayDeque<S>>> it = MAP.entrySet().iterator();
        while (it.hasNext()) {
            ArrayDeque<S> d = it.next().getValue();
            while (!d.isEmpty() && now - d.peekFirst().t > LIFE) d.removeFirst();
            if (d.isEmpty()) { it.remove(); continue; }
            S prev = null;
            for (S s : d) {
                if (prev != null && prev.tip.distanceToSqr(s.tip) < 36.0) {
                    float pa = fade(now - prev.t), sa = fade(now - s.t);
                    vert(vc, m, cp, prev.base, 90, 25, 170, pa * 0.55F);
                    vert(vc, m, cp, prev.tip, 190, 110, 255, pa);
                    vert(vc, m, cp, s.tip, 190, 110, 255, sa);
                    vert(vc, m, cp, s.base, 90, 25, 170, sa * 0.55F);
                }
                prev = s;
            }
        }
        bs.endBatch(RenderType.lightning());
    }

    private static float fade(float age) {
        float f = Math.max(0F, 1F - age / LIFE);
        return f * f;
    }

    private static void vert(VertexConsumer vc, Matrix4f m, Vec3 cp, Vec3 p, int r, int g, int b, float a) {
        vc.vertex(m, (float) (p.x - cp.x), (float) (p.y - cp.y), (float) (p.z - cp.z))
                .color(r, g, b, (int) (Math.min(1F, a) * 255)).endVertex();
    }
}
