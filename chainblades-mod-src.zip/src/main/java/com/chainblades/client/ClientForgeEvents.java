package com.chainblades.client;

import com.chainblades.ChainBladesItem;
import com.chainblades.ChainBladesMod;
import com.chainblades.ClientState;
import com.chainblades.Network;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    private static boolean holding(Minecraft mc) {
        return mc.player != null && mc.player.getMainHandItem().getItem() instanceof ChainBladesItem;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (holding(mc) && mc.screen == null) {
            while (ClientModEvents.Z.consumeClick()) Network.CH.sendToServer(new Network.ActionPacket(0));
            while (ClientModEvents.X.consumeClick()) Network.CH.sendToServer(new Network.ActionPacket(1));
            while (ClientModEvents.C.consumeClick()) Network.CH.sendToServer(new Network.ActionPacket(2));
        } else {
            while (ClientModEvents.Z.consumeClick()) { }
            while (ClientModEvents.X.consumeClick()) { }
            while (ClientModEvents.C.consumeClick()) { }
        }
        ClientAnim.tick();
        ClientState.tick();
    }

    /** Left click with the blades -> custom server-side combo instead of vanilla attack. */
    @SubscribeEvent
    public static void onAttack(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (e.isAttack() && holding(mc)) {
            e.setCanceled(true);
            e.setSwingHand(false);
            Network.CH.sendToServer(new Network.ActionPacket(-1));
        }
    }
}
