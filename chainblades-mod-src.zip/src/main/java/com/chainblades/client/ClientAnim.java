package com.chainblades.client;

import com.chainblades.Anim;
import net.minecraft.client.Minecraft;

import java.util.HashMap;
import java.util.Map;

/** Client-side animation playback + camera shake. */
public class ClientAnim {
    private static class Play {
        final Anim a;
        final float start;
        Play(Anim a, float start) { this.a = a; this.start = start; }
    }

    private static final Map<Integer, Play> PLAYING = new HashMap<>();
    private static float shakeStart, shakeEnd, shakeAmp;

    private static float now() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? 0F : mc.level.getGameTime() + mc.getFrameTime();
    }

    public static void play(int entityId, int animId) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || animId < 0 || animId >= Anim.ALL.length) return;
        PLAYING.put(entityId, new Play(Anim.ALL[animId], mc.level.getGameTime()));
        if (mc.player != null && mc.player.getId() == entityId) {
            switch (animId) {
                case 3, 4 -> shake(3, 4, 0.5F);
                case 5 -> shake(2, 12, 0.5F);
                case 6 -> shake(9, 9, 1.6F);
                case 7 -> shake(3, 36, 0.45F);
                case 9 -> shake(12, 14, 3.0F);
                default -> { }
            }
        }
    }

    /** Fills 'out' with channel values. Returns true if an animation is currently playing for this entity. */
    public static boolean sample(int entityId, float[] out) {
        Play p = PLAYING.get(entityId);
        if (p != null) {
            float t = now() - p.start;
            if (t >= p.a.length) {
                PLAYING.remove(entityId);
            } else {
                p.a.sample(Math.max(0F, t), out);
                return true;
            }
        }
        System.arraycopy(Anim.IDLE, 0, out, 0, Anim.N);
        return false;
    }

    public static void shake(int delay, int duration, float amp) {
        float n = now();
        shakeStart = n + delay;
        shakeEnd = shakeStart + duration;
        shakeAmp = amp;
    }

    public static float shakeValue() {
        float n = now();
        if (n < shakeStart || n >= shakeEnd) return 0F;
        return shakeAmp * (1F - (n - shakeStart) / (shakeEnd - shakeStart));
    }
}
