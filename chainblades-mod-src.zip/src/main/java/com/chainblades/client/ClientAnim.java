package com.chainblades.client;

import com.chainblades.Anim;
import com.chainblades.ChainBladesItem;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;

/** Client-side animation playback, block pose, idle show, camera shake. */
public class ClientAnim {
    private static class Play {
        final Anim a;
        final int id;
        float start;
        float holdFrom = -1, holdTicks;
        Play(Anim a, int id, float start) { this.a = a; this.id = id; this.start = start; }
    }

    private static final Map<Integer, Play> PLAYING = new HashMap<>();
    private static final Map<Integer, Integer> IDLE_TICKS = new HashMap<>();
    private static final float[] TMP = new float[Anim.N];
    /** Both blades crossed in front of the chest. */
    private static final float[] BLOCK = {-1.4F, -0.75F, 0.1F, -1.4F, 0.75F, -0.1F, 0F, 0.1F, -0.05F, 0F, 0F,
            0.15F, -0.15F, 0F, 0F, 0.6F, 1F, 0.6F, 1F, 0F, 0F, 0F};
    private static float shakeStart, shakeEnd, shakeAmp;

    public static float now() {
        Minecraft mc = Minecraft.getInstance();
        return mc.level == null ? 0F : mc.level.getGameTime() + mc.getFrameTime();
    }

    public static void play(int entityId, int animId) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || animId < 0 || animId >= Anim.ALL.length || Anim.ALL[animId] == null) return;
        PLAYING.put(entityId, new Play(Anim.ALL[animId], animId, mc.level.getGameTime()));
        IDLE_TICKS.put(entityId, 0);
        if (mc.player != null && mc.player.getId() == entityId) {
            switch (animId) {
                case 3, 4 -> shake(3, 4, 0.5F);
                case 5 -> shake(6, 10, 0.5F);
                case 6 -> shake(18, 9, 1.6F);
                case 12 -> shake(18, 6, 1.0F);
                case 7 -> shake(3, 36, 0.45F);
                case 9 -> shake(12, 14, 3.0F);
                default -> { }
            }
        }
    }

    private static float blockWeight(int entityId) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return 0F;
        Entity e = mc.level.getEntity(entityId);
        if (!(e instanceof LivingEntity le) || !le.isUsingItem() || !(le.getUseItem().getItem() instanceof ChainBladesItem)) return 0F;
        return Math.min(1F, (le.getTicksUsingItem() + mc.getFrameTime()) / 4F);
    }

    /** Fills 'out' with channel values. Returns true if an animation (or the block pose) is active for this entity. */
    public static boolean sample(int entityId, float[] out) {
        boolean active = false;
        System.arraycopy(Anim.IDLE, 0, out, 0, Anim.N);
        Play p = PLAYING.get(entityId);
        if (p != null) {
            float n = now();
            float t = n - p.start;
            if (p.holdFrom >= 0) {
                if (n < p.holdFrom + p.holdTicks) t = p.holdFrom - p.start;
                else { p.start += p.holdTicks; p.holdFrom = -1; t = n - p.start; }
            }
            if (t >= p.a.length) {
                PLAYING.remove(entityId);
            } else {
                p.a.sample(Math.max(0F, t), TMP);
                float in = p.id == 10 ? 10F : 2F, outT = p.id == 10 ? 10F : 3F;
                float w = Math.max(0F, Math.min(1F, Math.min(Math.max(0F, t) / in, (p.a.length - t) / outT)));
                w = w * w * (3 - 2 * w);
                for (int ch = 0; ch < Anim.N; ch++) {
                    // root transforms (flips/spins/jumps) are not blended, they end at a full turn
                    if (ch == Anim.LEAN || ch == Anim.MV || ch == Anim.SPIN || ch == Anim.JUMP || ch == Anim.CSP) out[ch] = TMP[ch];
                    else out[ch] = Anim.IDLE[ch] + (TMP[ch] - Anim.IDLE[ch]) * w;
                }
                active = true;
            }
        }
        float bw = blockWeight(entityId);
        if (bw > 0F) {
            for (int ch = 0; ch < Anim.N; ch++) out[ch] += (BLOCK[ch] - out[ch]) * bw;
            active = true;
        }
        return active;
    }

    /** Called every client tick: starts the idle chain-spin show after ~10 s of standing still. */
    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        for (var pl : mc.level.players()) {
            int id = pl.getId();
            if (!(pl.getMainHandItem().getItem() instanceof ChainBladesItem)) { IDLE_TICKS.remove(id); continue; }
            boolean moving = pl.position().distanceToSqr(pl.xo, pl.yo, pl.zo) > 1.0E-4 || pl.isUsingItem() || pl.swinging;
            Play p = PLAYING.get(id);
            if (moving) {
                IDLE_TICKS.put(id, 0);
                if (p != null && p.id == 10) PLAYING.remove(id);
                continue;
            }
            if (p != null && p.id != 10) { IDLE_TICKS.put(id, 0); continue; }
            int n = IDLE_TICKS.merge(id, 1, Integer::sum);
            if (p == null && n >= 200) play(id, 10);
        }
    }

    /** Freeze the local player's animation for a moment on impact. */
    public static void hitStop(int ticks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        Play p = PLAYING.get(mc.player.getId());
        if (p != null && p.holdFrom < 0) { p.holdFrom = now(); p.holdTicks = ticks; }
        shake(0, 4, 0.6F);
    }

    public static void shake(int delay, int duration, float amp) {
        float n = now();
        shakeStart = n + delay;
        shakeEnd = shakeStart + duration;
        shakeAmp = amp;
    }

    public static float shakeValue() {
        float n = now();
        if (n < shakeStart || n >= shakeEnd) return 0F;
        return shakeAmp * (1F - (n - shakeStart) / (shakeEnd - shakeStart));
    }
}
