package com.chainblades.client;

import com.chainblades.ChainBladesItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Draws the second blade in the off hand so both hands hold a weapon. */
public class SecondBladeLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public SecondBladeLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer pl, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        ItemStack stack = pl.getMainHandItem();
        if (!(stack.getItem() instanceof ChainBladesItem)) return;
        HumanoidArm arm = pl.getMainArm().getOpposite();
        boolean left = arm == HumanoidArm.LEFT;
        ps.pushPose();
        this.getParentModel().translateToHand(arm, ps);
        ps.mulPose(Axis.XP.rotationDegrees(-90F));
        ps.mulPose(Axis.YP.rotationDegrees(180F));
        ps.translate((left ? -1 : 1) / 16.0F, 0.125F, -0.625F);
        Minecraft.getInstance().getItemRenderer().renderStatic(pl, stack,
                left ? ItemDisplayContext.THIRD_PERSON_LEFT_HAND : ItemDisplayContext.THIRD_PERSON_RIGHT_HAND,
                left, ps, buf, pl.level(), light, OverlayTexture.NO_OVERLAY, pl.getId());
        ps.popPose();
    }
}
