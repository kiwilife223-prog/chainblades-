package com.chainblades.client;

import com.chainblades.Network;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Client-side glowing ribbons (slashes, streaks, beams) and whip/orbit chains sent by the server. */
public class FxRender {
    private static class Ribbon {
        int style;
        float life, grow, start, width;
        Vec3[] pts;
    }

    private static final List<Ribbon> RIBBONS = new ArrayList<>();

    public static void addRibbon(int style, int life, int grow, int delay, float width, Vec3[] pts) {
        if (pts == null || pts.length < 2) return;
        Ribbon r = new Ribbon();
        r.style = style;
        r.life = Math.max(1, life);
        r.grow = Math.max(0, grow);
        r.start = ClientAnim.now() + delay;
        r.width = width;
        r.pts = pts;
        RIBBONS.add(r);
        if (RIBBONS.size() > 200) RIBBONS.remove(0);
    }

    public static void addWhip(Network.WhipPacket m) {
        Vec3[] pts;
        if (m.kind == 0) {
            pts = new Vec3[13];
            for (int i = 0; i <= 12; i++) {
                double t = i / 12.0, u = 1 - t;
                pts[i] = m.p0.scale(u * u).add(m.ctrl.scale(2 * u * t)).add(m.p1.scale(t * t));
            }
        } else {
            Minecraft mc = Minecraft.getInstance();
            Entity o = mc.level == null ? null : mc.level.getEntity(m.owner);
            if (o == null) return;
            Vec3 c = o.position().add(0, m.height, 0);
            pts = new Vec3[17];
            for (int i = 0; i <= 16; i++) {
                double a = m.a0 + (m.a1 - m.a0) * i / 16.0;
                pts[i] = c.add(Math.cos(a) * m.radius, 0, Math.sin(a) * m.radius);
            }
        }
        addRibbon(1, m.life + m.hold + m.retract, m.life, m.delay, 0.12F, pts);
    }

    public static void render(PoseStack ps, Camera cam) {
        if (RIBBONS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        VertexConsumer vc = bs.getBuffer(RenderType.lightning());
        Matrix4f m = ps.last().pose();
        Vec3 cp = cam.getPosition();
        float now = ClientAnim.now();
        Iterator<Ribbon> it = RIBBONS.iterator();
        while (it.hasNext()) {
            Ribbon r = it.next();
            float age = now - r.start;
            if (age < 0) continue;
            if (age > r.life) { it.remove(); continue; }
            float growF = r.grow <= 0 ? 1F : Math.min(1F, age / r.grow);
            int visible = Math.max(2, (int) Math.ceil(r.pts.length * growF));
            float fade = 1F - age / r.life;
            fade *= fade;
            int cr = r.style == 1 ? 210 : 150, cg = r.style == 1 ? 150 : 70, cb = 255;
            for (int i = 0; i < visible - 1 && i < r.pts.length - 1; i++) {
                Vec3 a = r.pts[i], b = r.pts[i + 1];
                Vec3 d = b.subtract(a);
                Vec3 side = d.cross(new Vec3(0, 1, 0));
                side = side.lengthSqr() < 1.0E-6 ? new Vec3(1, 0, 0) : side.normalize();
                float w = r.width;
                float taper = 0.35F + 0.65F * (i + 1F) / r.pts.length;
                quad(vc, m, cp, a.add(0, -w * taper, 0), a.add(0, w * taper, 0), b.add(0, w * taper, 0), b.add(0, -w * taper, 0), cr, cg, cb, fade);
                quad(vc, m, cp, a.add(side.scale(-w * taper)), a.add(side.scale(w * taper)), b.add(side.scale(w * taper)), b.add(side.scale(-w * taper)), cr, cg, cb, fade);
            }
        }
        bs.endBatch(RenderType.lightning());
    }

    private static void quad(VertexConsumer vc, Matrix4f m, Vec3 cp, Vec3 a, Vec3 b, Vec3 c, Vec3 d,
                             int r, int g, int bl, float alpha) {
        vert(vc, m, cp, a, r, g, bl, alpha * 0.4F);
        vert(vc, m, cp, b, r, g, bl, alpha);
        vert(vc, m, cp, c, r, g, bl, alpha);
        vert(vc, m, cp, d, r, g, bl, alpha * 0.4F);
    }

    private static void vert(VertexConsumer vc, Matrix4f m, Vec3 cp, Vec3 p, int r, int g, int b, float a) {
        vc.vertex(m, (float) (p.x - cp.x), (float) (p.y - cp.y), (float) (p.z - cp.z))
                .color(r, g, b, (int) (Math.min(1F, Math.max(0F, a)) * 255)).endVertex();
    }
}
