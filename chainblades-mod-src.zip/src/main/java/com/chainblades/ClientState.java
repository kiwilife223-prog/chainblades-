package com.chainblades;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

/** Client-only: black & white screen effect. Only touched through DistExecutor / client events. */
public class ClientState {
    private static int bw = 0;

    public static void startBW(int ticks) {
        Minecraft mc = Minecraft.getInstance();
        bw = ticks;
        mc.gameRenderer.loadEffect(new ResourceLocation(ChainBladesMod.MODID, "shaders/post/bw.json"));
    }

    public static void tick() {
        if (bw > 0 && --bw == 0) {
            Minecraft.getInstance().gameRenderer.shutdownEffect();
        }
    }
}
