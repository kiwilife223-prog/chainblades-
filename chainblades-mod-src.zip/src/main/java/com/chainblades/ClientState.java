package com.chainblades;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

/** Client-only: negative flash, then black & white screen. Only touched through DistExecutor / client events. */
public class ClientState {
    private static int bw = 0, total = 1, flash = 0;

    public static void startBW(int ticks) {
        Minecraft mc = Minecraft.getInstance();
        bw = ticks;
        total = Math.max(1, ticks);
        flash = 3;
        mc.gameRenderer.loadEffect(new ResourceLocation("shaders/post/invert.json"));
    }

    public static void tick() {
        if (bw <= 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (flash > 0 && --flash == 0) {
            mc.gameRenderer.loadEffect(new ResourceLocation(ChainBladesMod.MODID, "shaders/post/bw.json"));
        }
        if (--bw == 0) mc.gameRenderer.shutdownEffect();
    }

    /** Ticks since the effect started (with partial tick), or -1 when inactive. */
    public static float age(float partial) {
        return bw <= 0 ? -1F : (total - bw) + partial;
    }

    public static int total() { return total; }
}
