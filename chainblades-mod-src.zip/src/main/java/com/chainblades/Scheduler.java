package com.chainblades;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Mod.EventBusSubscriber(modid = ChainBladesMod.MODID)
public class Scheduler {
    private static class Task { int t; Runnable r; }
    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<Task> ADD = new ArrayList<>();

    public static void later(int ticks, Runnable r) {
        if (ticks <= 0) { r.run(); return; }
        Task k = new Task();
        k.t = ticks;
        k.r = r;
        ADD.add(k);
    }

    @SubscribeEvent
    public static void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        TASKS.addAll(ADD);
        ADD.clear();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task k = it.next();
            if (--k.t <= 0) {
                it.remove();
                try { k.r.run(); } catch (Exception ex) { ex.printStackTrace(); }
            }
        }
    }
}
