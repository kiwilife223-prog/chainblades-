package com.chainblades.client;

import com.chainblades.Anim;
import com.chainblades.ChainBladesItem;
import com.chainblades.ChainBladesMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.PlayerModelPart;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

/**
 * While the blades are held, this layer replaces the straight vanilla arms and legs with bendable ones
 * (shoulder + forearm, thigh + shin, drawn with the player's own skin), and draws both daggers with their chains.
 *
 * Dagger grip = 1: the dagger is held by its handle in the fist, the chain hangs loose from the pommel ring.
 * Dagger grip = 0: the hand holds the chain end and the dagger flies on the chain.
 */
public class ChainBladesLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation TEX = new ResourceLocation(ChainBladesMod.MODID, "textures/item/chain_blades.png");
    /** Centre of the fist along the forearm (blocks from the elbow). */
    private static final float HAND_Y = 0.3F;
    private final float[] v = new float[Anim.N];

    public ChainBladesLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer pl, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        ItemStack stack = pl.getMainHandItem();
        if (!(stack.getItem() instanceof ChainBladesItem) || pl.isInvisible()) return;

        boolean active = ClientAnim.sample(pl.getId(), v);
        PlayerModel<AbstractClientPlayer> m = this.getParentModel();
        ResourceLocation skin = pl.getSkinTextureLocation();
        boolean slim = "slim".equals(pl.getModelName());
        int overlay = LivingEntityRenderer.getOverlayCoords(pl, 0F);
        float run = Math.min(1F, limbSwingAmount * 1.3F);
        float sway = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount * 0.5F;

        // legs: knees bend backwards as the leg swings back
        drawLeg(ps, buf, skin, light, overlay, pl, m.rightLeg, true,
                knee(v[Anim.RKNE], m.rightLeg.xRot, run), pl.isModelPartShown(PlayerModelPart.RIGHT_PANTS_LEG));
        drawLeg(ps, buf, skin, light, overlay, pl, m.leftLeg, false,
                knee(v[Anim.LKNE], m.leftLeg.xRot, run), pl.isModelPartShown(PlayerModelPart.LEFT_PANTS_LEG));

        // arms with elbows + daggers
        float eR = elbow(v[Anim.RELB], m.rightArm.xRot, run, active);
        float eL = elbow(v[Anim.LELB], m.leftArm.xRot, run, active);
        drawArm(ps, buf, skin, slim, light, overlay, pl, m.rightArm, true, eR, pl.isModelPartShown(PlayerModelPart.RIGHT_SLEEVE),
                v[Anim.RLEN], v[Anim.RTEN], v[Anim.RGR], v[Anim.WR], pl.getId() * 2L, active, ageInTicks, sway, v[Anim.CAM], v[Anim.CSP]);
        drawArm(ps, buf, skin, slim, light, overlay, pl, m.leftArm, false, eL, pl.isModelPartShown(PlayerModelPart.LEFT_SLEEVE),
                v[Anim.LLEN], v[Anim.LTEN], v[Anim.LGR], v[Anim.WR], pl.getId() * 2L + 1, active, ageInTicks, -sway, v[Anim.CAM], v[Anim.CSP] + Mth.PI);
    }

    private static float elbow(float chan, float armSwing, float run, boolean active) {
        float e = chan;
        if (!active) e += 0.5F * run + 0.4F * Math.max(0F, -armSwing);
        return Mth.clamp(e, 0F, 2.4F);
    }

    private static float knee(float chan, float legSwing, float run) {
        return Mth.clamp(chan + Math.max(0F, legSwing) * 0.9F + 0.15F * run, 0F, 2.5F);
    }

    // ------------------------------------------------------------------ legs / arms (skin)

    private void drawLeg(PoseStack ps, MultiBufferSource buf, ResourceLocation skin, int light, int overlay,
                         AbstractClientPlayer pl, ModelPart leg, boolean right, float knee, boolean pants) {
        ps.pushPose();
        leg.translateAndRotate(ps);
        float u = right ? 0F : 16F, vv = right ? 16F : 48F;
        float ou = right ? 0F : 0F, ov = right ? 32F : 48F;
        // thigh: rows 0..6.6 (slight overlap hides the gap at the knee)
        skinBox(buf.getBuffer(RenderType.entityCutoutNoCull(skin)), ps.last(), light, overlay, u, vv, 4, 12, 4, -2, -2, 0, 0, 6.6F, 0F);
        if (pants) skinBox(buf.getBuffer(RenderType.entityTranslucent(skin)), ps.last(), light, overlay, ou, ov, 4, 12, 4, -2, -2, 0, 0, 6.6F, 0.25F);
        ps.translate(0, 6 / 16F, 0);
        ps.mulPose(new Quaternionf().rotationX(knee));
        skinBox(buf.getBuffer(RenderType.entityCutoutNoCull(skin)), ps.last(), light, overlay, u, vv, 4, 12, 4, -2, -2, 0, 6F, 12F, 0F);
        if (pants) skinBox(buf.getBuffer(RenderType.entityTranslucent(skin)), ps.last(), light, overlay, ou, ov, 4, 12, 4, -2, -2, 0, 6F, 12F, 0.25F);
        ps.popPose();
    }

    private void drawArm(PoseStack ps, MultiBufferSource buf, ResourceLocation skin, boolean slim, int light, int overlay,
                         AbstractClientPlayer pl, ModelPart armPart, boolean right, float elbow, boolean sleeve,
                         float len, float ten, float gr, float wrist, long key, boolean active,
                         float swayTime, float sway, float cam, float phase) {
        gr = Mth.clamp(gr, 0F, 1F);
        float w = slim ? 3F : 4F;
        float bx = right ? (slim ? -2F : -3F) : -1F;
        float u = right ? 40F : 32F, vv = right ? 16F : 48F;
        float ou = right ? 40F : 48F, ov = right ? 32F : 48F;

        ps.pushPose();
        armPart.translateAndRotate(ps);
        // upper arm: rows 0..6.6 of the 12-row arm. Box origin y = -2 px relative to the shoulder pivot.
        skinBox(buf.getBuffer(RenderType.entityCutoutNoCull(skin)), ps.last(), light, overlay, u, vv, w, 12, 4, bx, -2, -2, 0, 6.6F, 0F);
        if (sleeve) skinBox(buf.getBuffer(RenderType.entityTranslucent(skin)), ps.last(), light, overlay, ou, ov, w, 12, 4, bx, -2, -2, 0, 6.6F, 0.25F);
        // elbow joint at row 6 (y = 4 px)
        ps.translate(0, 4 / 16F, 0);
        ps.mulPose(new Quaternionf().rotationX(-elbow));
        skinBox(buf.getBuffer(RenderType.entityCutoutNoCull(skin)), ps.last(), light, overlay, u, vv, w, 12, 4, bx, -2, 0, 6F, 12F, 0F);
        if (sleeve) skinBox(buf.getBuffer(RenderType.entityTranslucent(skin)), ps.last(), light, overlay, ou, ov, w, 12, 4, bx, -2, 0, 6F, 12F, 0.25F);

        // ---------- weapon, in the forearm frame
        // gravity ("down" in model space is +y) expressed in the forearm's local frame
        Quaternionf q = new Quaternionf().rotationZYX(armPart.zRot, armPart.yRot, armPart.xRot).mul(new Quaternionf().rotationX(-elbow));
        Vector3f g = new Vector3f(0, 1, 0);
        new Quaternionf(q).invert().transform(g);

        // chain mode: hand holds the chain end, dagger flies along the forearm (or orbits the hand in the idle show)
        Vector3f d = new Vector3f(0, 1, 0);
        if (cam > 0.01F) {
            Vector3f ds = new Vector3f(0, Mth.cos(phase), -Mth.sin(phase));
            d.lerp(ds, Math.min(1F, cam)).normalize();
        }
        Vector3f hand = new Vector3f(0, HAND_Y, 0);
        float reach = len * (0.35F + 0.65F * ten);
        Vector3f rc = new Vector3f(hand).add(new Vector3f(d).mul(reach)).add(new Vector3f(g).mul((1F - ten) * len * 0.35F));

        // handle mode: dagger gripped in the fist at the wrist angle, pommel ring behind the grip, chain hangs from the ring
        Vector3f b = new Vector3f(0, Mth.cos(wrist), -Mth.sin(wrist)).normalize();
        Vector3f rh = new Vector3f(hand).sub(new Vector3f(b).mul(0.2F));
        Vector3f free = new Vector3f(rh).add(new Vector3f(g).mul(0.6F));

        Vector3f a = new Vector3f(hand).lerp(free, gr);
        Vector3f r = new Vector3f(rc).lerp(rh, gr);
        float tenE = ten * (1F - gr);
        float dist = a.distance(r);
        float sagAmt = (1F - tenE) * dist * 0.5F + gr * 0.1F;
        Vector3f mid = new Vector3f(a).add(r).mul(0.5F).add(new Vector3f(g).mul(sagAmt));
        float sw = ((float) Math.sin(swayTime * 0.13F + key) * 0.10F + sway) * (1F - tenE);
        float span = Math.max(dist, 0.4F);
        mid.x += sw * span;
        r.x += sw * span * 0.7F * (1F - gr);
        a.x += sw * span * 0.9F * gr;
        r.z += (float) Math.cos(swayTime * 0.11F + key) * 0.06F * (1F - tenE) * len * (1F - gr);

        VertexConsumer vc = buf.getBuffer(RenderType.entityCutoutNoCull(TEX));
        float chainLen = a.distance(mid) + mid.distance(r);
        int n = Math.max(2, Math.min(60, (int) (chainLen / 0.24F)));
        for (int i = 0; i < n; i++) {
            float t = (i + 0.5F) / n;
            Vector3f pos = bez(a, mid, r, t);
            Vector3f tg = tangent(a, mid, r, t);
            ps.pushPose();
            ps.translate(pos.x, pos.y, pos.z);
            ps.mulPose(new Quaternionf().rotationTo(0, 0, 1, tg.x, tg.y, tg.z));
            if ((i & 1) == 1) ps.mulPose(com.mojang.math.Axis.ZP.rotationDegrees(90F));
            if (i % 2 == 1) box(vc, ps.last(), LightTexture.FULL_BRIGHT, -0.06F, -0.024F, -0.12F, 0.06F, 0.024F, 0.12F, 0.5F, 0F, 1F, 0.5F);
            else box(vc, ps.last(), light, -0.085F, -0.028F, -0.14F, 0.085F, 0.028F, 0.14F, 0F, 0.5F, 0.5F, 1F);
            ps.popPose();
        }

        // dagger orientation: along the chain's end tangent when thrown, along the grip when held
        Vector3f tgc = tangent(a, mid, r, 1F);
        Vector3f tg = new Vector3f(tgc).lerp(b, gr);
        if (tg.lengthSquared() < 1.0E-6F) tg.set(b);
        tg.normalize();
        float amt = Math.max(ten, Mth.clamp((len - 0.8F) / 1.5F, 0F, 1F));
        float bs = 0.95F + 0.85F * amt * (1F - gr);

        ps.pushPose();
        ps.translate(r.x, r.y, r.z);
        ps.mulPose(new Quaternionf().rotationTo(0, 0, 1, tg.x, tg.y, tg.z));
        ps.scale(bs, bs, bs);
        PoseStack.Pose pose = ps.last();
        drawDagger(buf.getBuffer(RenderType.entityCutoutNoCull(TEX)), pose, light, LightTexture.FULL_BRIGHT);

        if (active || len * (1F - gr) > 1.5F) {
            Vec3 tip = toWorld(pose, new Vector3f(0, 0, 1.04F));
            Vec3 base = toWorld(pose, new Vector3f(0, 0, 0.38F));
            ClientTrails.add(key, tip, base);
        }
        var lvl = Minecraft.getInstance().level;
        if (lvl != null && Math.random() < (active ? 0.5 : 0.12)) {
            Vec3 pp = toWorld(pose, new Vector3f(0, 0, 0.6F));
            lvl.addParticle(net.minecraft.core.particles.ParticleTypes.REVERSE_PORTAL, pp.x, pp.y, pp.z, 0, 0.03, 0);
        }
        ps.popPose();
        ps.popPose();
    }

    /**
     * One segment (rows r0..r1 of the box height) of a vanilla-style skin cuboid, UV-mapped exactly like ModelPart.Cube.
     * (u,v) = texture origin, (w,h,d) = box size in px, (bx,by,bz) = box origin in px, yTop = y (px) where row r0 sits in the current frame.
     */
    private static void skinBox(VertexConsumer vc, PoseStack.Pose pose, int light, int overlay,
                                float u, float v, float w, float h, float d,
                                float bx, float by, float bz, float r0, float r1, float inf) {
        float yTop = by + r0;
        float x0 = bx - inf, x1 = bx + w + inf, z0 = bz - inf, z1 = bz + d + inf;
        float ya = yTop - (r0 == 0F ? inf : 0F), yb = yTop + (r1 - r0) + (r1 >= h ? inf : 0F);
        float[] v0 = {x0, ya, z0}, v1 = {x1, ya, z0}, v2 = {x1, yb, z0}, v3 = {x0, yb, z0};
        float[] v4 = {x0, ya, z1}, v5 = {x1, ya, z1}, v6 = {x1, yb, z1}, v7 = {x0, yb, z1};
        float f9 = u + d, f10 = u + d + w, f11 = u + d + w + w, f12 = u + d + w + d, f13 = u + d + w + d + w;
        float f14 = v, f15 = v + d;
        float s0 = f15 + r0, s1 = f15 + r1;
        if (r0 == 0F) sk(vc, pose, light, overlay, v5, v4, v0, v1, f9, f14, f10, f15, 0, -1, 0);        // top
        if (r1 >= h) sk(vc, pose, light, overlay, v2, v3, v7, v6, f10, f15, f11, f14, 0, 1, 0);         // bottom
        sk(vc, pose, light, overlay, v0, v4, v7, v3, u, s0, f9, s1, -1, 0, 0);                         // west
        sk(vc, pose, light, overlay, v1, v0, v3, v2, f9, s0, f10, s1, 0, 0, -1);                       // north
        sk(vc, pose, light, overlay, v5, v1, v2, v6, f10, s0, f12, s1, 1, 0, 0);                       // east
        sk(vc, pose, light, overlay, v4, v5, v6, v7, f12, s0, f13, s1, 0, 0, 1);                       // south
    }

    /** vertex order and UV corner assignment as in ModelPart.Polygon: [0]=(u2,v1) [1]=(u1,v1) [2]=(u1,v2) [3]=(u2,v2). */
    private static void sk(VertexConsumer vc, PoseStack.Pose pose, int light, int overlay,
                           float[] a, float[] b, float[] c, float[] d,
                           float u1, float v1, float u2, float v2, float nx, float ny, float nz) {
        sv(vc, pose, light, overlay, a, u2, v1, nx, ny, nz);
        sv(vc, pose, light, overlay, b, u1, v1, nx, ny, nz);
        sv(vc, pose, light, overlay, c, u1, v2, nx, ny, nz);
        sv(vc, pose, light, overlay, d, u2, v2, nx, ny, nz);
    }

    private static void sv(VertexConsumer vc, PoseStack.Pose pose, int light, int overlay, float[] p,
                           float tu, float tv, float nx, float ny, float nz) {
        vc.vertex(pose.pose(), p[0] / 16F, p[1] / 16F, p[2] / 16F).color(255, 255, 255, 255).uv(tu / 64F, tv / 64F)
                .overlayCoords(overlay).uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }

    // ------------------------------------------------------------------ dagger

    /** Dagger like the concept art: flat ring for the chain, wrapped grip, winged guard with gem, serrated glowing blade. */
    private static void drawDagger(VertexConsumer vc, PoseStack.Pose pose, int light, int glow) {
        box(vc, pose, light, -0.08F, -0.02F, -0.07F, 0.08F, 0.02F, -0.04F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, -0.08F, -0.02F, 0.04F, 0.08F, 0.02F, 0.07F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, -0.08F, -0.02F, -0.07F, -0.05F, 0.02F, 0.07F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, 0.05F, -0.02F, -0.07F, 0.08F, 0.02F, 0.07F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, light, -0.026F, -0.026F, 0.07F, 0.026F, 0.026F, 0.32F, 0.5F, 0.5F, 1F, 1F);
        for (int b = 0; b < 4; b++) {
            float z0 = 0.10F + b * 0.065F;
            box(vc, pose, glow, -0.031F, -0.031F, z0, 0.031F, 0.031F, z0 + 0.028F, 0.5F, 0F, 1F, 0.5F);
        }
        box(vc, pose, light, -0.12F, -0.032F, 0.32F, 0.12F, 0.032F, 0.38F, 0F, 0.5F, 0.5F, 1F);
        box(vc, pose, glow, -0.15F, -0.02F, 0.30F, -0.12F, 0.02F, 0.36F, 0.5F, 0F, 1F, 0.5F);
        box(vc, pose, glow, 0.12F, -0.02F, 0.30F, 0.15F, 0.02F, 0.36F, 0.5F, 0F, 1F, 0.5F);
        box(vc, pose, glow, -0.13F, -0.02F, 0.38F, -0.10F, 0.02F, 0.44F, 0.5F, 0F, 1F, 0.5F);
        box(vc, pose, glow, 0.10F, -0.02F, 0.38F, 0.13F, 0.02F, 0.44F, 0.5F, 0F, 1F, 0.5F);
        box(vc, pose, glow, -0.024F, -0.045F, 0.325F, 0.024F, 0.045F, 0.375F, 0.5F, 0F, 1F, 0.5F);
        float[][] seg = {{0.38F, 0.52F, 0.07F}, {0.52F, 0.68F, 0.062F}, {0.68F, 0.82F, 0.048F}, {0.82F, 0.92F, 0.03F}};
        for (float[] s : seg) box(vc, pose, light, -s[2], -0.014F, s[0], s[2], 0.014F, s[1], 0F, 0F, 0.5F, 0.5F);
        box(vc, pose, light, -0.013F, -0.022F, 0.38F, 0.013F, 0.022F, 0.93F, 0F, 0F, 0.5F, 0.5F);
        for (int i = 0; i < 6; i++) {
            float z0 = 0.40F + i * 0.085F;
            float wd = 0.07F - i * 0.007F;
            float tooth = 0.032F - i * 0.0035F;
            box(vc, pose, glow, -wd - tooth, -0.012F, z0, -wd + 0.012F, 0.012F, z0 + 0.05F, 0.5F, 0F, 1F, 0.5F);
            box(vc, pose, glow, wd - 0.012F, -0.012F, z0, wd + tooth, 0.012F, z0 + 0.05F, 0.5F, 0F, 1F, 0.5F);
        }
        quad(vc, pose, glow, -0.03F, 0.014F, 0.92F, 0.03F, 0.014F, 0.92F, 0F, 0.003F, 1.04F, 0F, 0.003F, 1.04F, 0.5F, 0F, 1F, 0.5F, 0, 1, 0.3F);
        quad(vc, pose, glow, -0.03F, -0.014F, 0.92F, 0.03F, -0.014F, 0.92F, 0F, -0.003F, 1.04F, 0F, -0.003F, 1.04F, 0.5F, 0F, 1F, 0.5F, 0, -1, 0.3F);
        quad(vc, pose, glow, -0.03F, -0.014F, 0.92F, -0.03F, 0.014F, 0.92F, 0F, 0F, 1.04F, 0F, 0F, 1.04F, 0.5F, 0F, 1F, 0.5F, -1, 0, 0.3F);
        quad(vc, pose, glow, 0.03F, -0.014F, 0.92F, 0.03F, 0.014F, 0.92F, 0F, 0F, 1.04F, 0F, 0F, 1.04F, 0.5F, 0F, 1F, 0.5F, 1, 0, 0.3F);
    }

    private static Vec3 toWorld(PoseStack.Pose pose, Vector3f p) {
        Vector4f e = new Vector4f(p.x, p.y, p.z, 1F);
        e.mul(pose.pose());
        Vector3f w = new Vector3f(e.x, e.y, e.z);
        var cam = Minecraft.getInstance().gameRenderer.getMainCamera();
        w.rotate(cam.rotation());
        Vec3 cp = cam.getPosition();
        return new Vec3(cp.x + w.x, cp.y + w.y, cp.z + w.z);
    }

    private static Vector3f bez(Vector3f a, Vector3f b, Vector3f c, float t) {
        float u = 1F - t;
        return new Vector3f(
                u * u * a.x + 2 * u * t * b.x + t * t * c.x,
                u * u * a.y + 2 * u * t * b.y + t * t * c.y,
                u * u * a.z + 2 * u * t * b.z + t * t * c.z);
    }

    private static Vector3f tangent(Vector3f a, Vector3f b, Vector3f c, float t) {
        Vector3f d = new Vector3f(
                2 * (1 - t) * (b.x - a.x) + 2 * t * (c.x - b.x),
                2 * (1 - t) * (b.y - a.y) + 2 * t * (c.y - b.y),
                2 * (1 - t) * (b.z - a.z) + 2 * t * (c.z - b.z));
        if (d.lengthSquared() < 1.0E-6F) return new Vector3f(0, 1, 0);
        return d.normalize();
    }

    private static void box(VertexConsumer vc, PoseStack.Pose pose, int light, float x0, float y0, float z0,
                            float x1, float y1, float z1, float u0, float v0, float u1, float v1) {
        quad(vc, pose, light, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1, u0, v0, u1, v1, 0, 0, 1);
        quad(vc, pose, light, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0, u0, v0, u1, v1, 0, 0, -1);
        quad(vc, pose, light, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1, u0, v0, u1, v1, 1, 0, 0);
        quad(vc, pose, light, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0, u0, v0, u1, v1, -1, 0, 0);
        quad(vc, pose, light, x0, y1, z1, x1, y1, z1, x1, y1, z0, x0, y1, z0, u0, v0, u1, v1, 0, 1, 0);
        quad(vc, pose, light, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1, u0, v0, u1, v1, 0, -1, 0);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float u0, float v0, float u1, float v1, float nx, float ny, float nz) {
        vtx(vc, pose, light, ax, ay, az, u0, v0, nx, ny, nz);
        vtx(vc, pose, light, bx, by, bz, u1, v0, nx, ny, nz);
        vtx(vc, pose, light, cx, cy, cz, u1, v1, nx, ny, nz);
        vtx(vc, pose, light, dx, dy, dz, u0, v1, nx, ny, nz);
    }

    private static void vtx(VertexConsumer vc, PoseStack.Pose pose, int light, float x, float y, float z,
                            float u, float v, float nx, float ny, float nz) {
        vc.vertex(pose.pose(), x, y, z).color(255, 255, 255, 255).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }
}
