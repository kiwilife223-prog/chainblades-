package com.chainblades.client;

import com.chainblades.Anim;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;

/**
 * Combat stance (relaxed, staggered feet, breathing, weight shift, idle glance), natural walk/run,
 * and the animated arm/body/leg/head rotations from Anim.
 */
public class ClientPose {
    public static final HumanoidModel.ArmPose POSE =
            HumanoidModel.ArmPose.create("CHAIN_BLADES", true, ClientPose::transform);

    private static final float[] V = new float[Anim.N];

    public static void transform(HumanoidModel<?> m, LivingEntity entity, HumanoidArm arm) {
        if (arm != entity.getMainArm()) return;
        float[] v = V;
        boolean act = ClientAnim.sample(entity.getId(), v);
        float t = entity.tickCount + Minecraft.getInstance().getFrameTime();
        float breath = Mth.sin(t * 0.09F);
        float rSwing = m.rightArm.xRot, lSwing = m.leftArm.xRot; // vanilla walk swing
        // 0 = standing, 1 = full run (derived from the vanilla arm swing amplitude)
        float spd = Math.min(1F, (Math.abs(rSwing) + Math.abs(lSwing)) * 0.7F);
        float by;

        if (!act) {
            float stance = 1F - spd;
            float shift = Mth.sin(t * 0.045F) * 0.05F * stance;       // slow weight shift
            by = (lSwing - rSwing) * 0.12F + shift;                    // counter-twist while running
            m.rightArm.xRot = rSwing * 0.85F + v[Anim.RAX] * stance - 0.65F * spd;
            m.rightArm.yRot = v[Anim.RAY] * stance - 0.28F * spd;
            m.rightArm.zRot = v[Anim.RAZ] * stance + 0.08F * spd + breath * 0.03F;
            m.leftArm.xRot = lSwing * 0.85F + v[Anim.LAX] * stance - 0.65F * spd;
            m.leftArm.yRot = v[Anim.LAY] * stance + 0.28F * spd;
            m.leftArm.zRot = v[Anim.LAZ] * stance - 0.08F * spd - breath * 0.03F;
            m.body.xRot += breath * 0.015F + 0.2F * spd;
            m.head.xRot -= 0.12F * spd;
            m.head.yRot += Mth.sin(t * 0.031F) * 0.12F * stance;       // idle glance
            m.rightLeg.xRot += v[Anim.RLX] * stance;
            m.leftLeg.xRot += v[Anim.LLX] * stance;
        } else {
            by = v[Anim.BY];
            m.body.xRot = v[Anim.BX];
            m.rightArm.xRot = v[Anim.RAX] + rSwing * 0.2F;
            m.rightArm.yRot = v[Anim.RAY];
            m.rightArm.zRot = v[Anim.RAZ];
            m.leftArm.xRot = v[Anim.LAX] + lSwing * 0.2F;
            m.leftArm.yRot = v[Anim.LAY];
            m.leftArm.zRot = v[Anim.LAZ];
            m.head.yRot += v[Anim.HY];
            m.head.xRot += v[Anim.HX];
            m.rightLeg.xRot += v[Anim.RLX];
            m.leftLeg.xRot += v[Anim.LLX];
            m.rightLeg.yRot += v[Anim.RLY];
            m.leftLeg.yRot += v[Anim.LLY];
        }

        // torso twist: shoulders swing around with it and the arms turn together with the torso
        float c = Mth.cos(by), s = Mth.sin(by);
        m.body.yRot = by;
        m.rightArm.x = -5F * c;
        m.rightArm.z = 5F * s;
        m.leftArm.x = 5F * c;
        m.leftArm.z = -5F * s;
        m.rightArm.yRot += by;
        m.leftArm.yRot += by;

        // the straight vanilla limbs are hidden; ChainBladesLayer draws bendable arms and legs (elbows, knees) with the player's skin
        m.rightArm.visible = false;
        m.leftArm.visible = false;
        m.rightLeg.visible = false;
        m.leftLeg.visible = false;
        if (m instanceof PlayerModel<?> pm) {
            pm.rightSleeve.visible = false;
            pm.leftSleeve.visible = false;
            pm.rightPants.visible = false;
            pm.leftPants.visible = false;
        }
    }
}
